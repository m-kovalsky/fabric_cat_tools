import sempy
import sempy.fabric as fabric
import pandas as pd
from tqdm.auto import tqdm
from pyspark.sql import SparkSession
from delta import DeltaTable

def optimize_lakehouse_tables(tables = None, lakehouse = None, workspace = None):

    """
    
    This function optimizes tables in a lakehouse by running the OPTIMIZE function.

    Parameters:
        
        tables: A string or list of lakehouse delta tables to optimize. If no tables are specified, OPTIMIZE will run over all the tables in the lakehouse.
        lakehouse: The name of the lakehouse.
        workspace: The name of the workspace in which the lakehouse resides.

    Returns:

        This function returns a printout stating the success/failure of the operation.

    Examples:

        optimize_lakehouse_tables(
            tables = ['Sales', 'Calendar']
            ,lakehouse = None
            ,workspace = None
        )

        optimize_lakehouse_tables(
            tables = None
            ,lakehouse = 'MyLakehouse'
            ,workspace = 'MyNewWorkspace'
        )
    """
    
    from .GetLakehouseTables import get_lakehouse_tables
    from .HelperFunctions import resolve_lakehouse_name

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)
    
    if lakehouse == None:
        lakehouse_id = fabric.get_lakehouse_id()
        lakehouse = resolve_lakehouse_name(lakehouse_id, workspace)

    lakeTables = get_lakehouse_tables(lakehouse = lakehouse, workspace = workspace)
    lakeTablesDelta = lakeTables[lakeTables['Format'] == 'delta']

    if isinstance(tables, str):
        tables = [tables]

    if tables is not None:
        tables_filt = lakeTablesDelta[lakeTablesDelta['Table Name'].isin(tables)]
    else:
        tables_filt = lakeTablesDelta.copy()

    tableCount = len(tables_filt)

    spark = SparkSession.builder.getOrCreate()

    i=1
    for index, r in (bar := tqdm(tables_filt.iterrows())):
        tableName = r['Table Name']
        tablePath = r['Location']
        bar.set_description(f"Optimizing the '{tableName}' table...")
        deltaTable = DeltaTable.forPath(spark, tablePath)
        deltaTable.optimize().executeCompaction()
        print(f"The '{tableName}' table has been optimized. ({str(i)}/{str(tableCount)})")
        i+=1
