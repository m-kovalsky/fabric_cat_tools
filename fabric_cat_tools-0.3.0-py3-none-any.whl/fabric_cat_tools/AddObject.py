import sempy
import sempy.fabric as fabric
import pandas as pd
sempy.fabric._client._utils._init_analysis_services()
import Microsoft.AnalysisServices.Tabular as TOM
import System

def add_measure(dataset, table_name, measure_name, expression, description = None, format_string = None, display_folder = None, workspace = None):

    """
    
    This function adds a new measure to a semantic model.

    Parameters:

        dataset: The name of the semantic model.
        table_name: The name of the table to which the measure will be added.
        measure_name: The name of the new measure to be created.
        expression: The DAX expression of the new measure.
        description: An optional paramter to set the description of the measure.
        format_string: An optional parameter to set the format string of the measure.
        display_folder: An optional parameter to set the display folder of the measure.
        workspace: An optional parameter to set the workspace in which the lakehouse resides. This defaults to the workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of the operation.

    Example:

    add_measure(
        dataset = 'AdventureWorks'
        ,table_name = 'Internet Sales'
        ,measurename = 'Sales Amount'
        ,expression =  "SUM( 'Internet Sales'[SalesAmount] )"
        #,display_folder = ''
        #,format_string = ''
        #,workspace = '' 
        )
    """

    from .HelperFunctions import resolve_dataset_id

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)
    else:
        workspace_id = fabric.resolve_workspace_id(workspace)   
    
    dfM = fabric.list_measures(dataset = dataset, workspace = workspace)
    dfM_filt = dfM[dfM['Measure Name'] == measure_name]

    if len(dfM_filt) > 0:
        print(f"The '{measure_name}' already exists in the '{dataset}' semantic model in the '{workspace}' workspace.")
        return
    
    tom_server = fabric.create_tom_server(readonly=False, workspace=workspace)

    print(f"Updating the '{dataset}' semantic model...")
    m = tom_server.Databases.GetByName(dataset).Model       
    try:
        measure = TOM.Measure()
        measure.Name = measure_name
        measure.Expression = expression
        if display_folder is not None:
            measure.DisplayFolder = display_folder
        if description is not None:
            measure.Description = description
        if format_string is not None:
            measure.FormatString = format_string

        m.Tables[table_name].Measures.Add(measure)
        m.SaveChanges()
        print(f"The '{measure_name}' measure has been added to the '{table_name}' table in the '{dataset}' semantic model within the '{workspace}' workspace.")
    except:
        print(f"ERROR: The '{measure_name}' measure was not created.")

def add_relationship(dataset, from_table, from_column, to_table, to_column, from_cardinality, to_cardinality, cross_filtering_behavior = 'Automatic', is_active = True, security_filtering_behavior = 'OneDirection', rely_on_referential_integrity = False, workspace = None):

    """
    
    This function adds a new relationship to a semantic model.

    Parameters:

        dataset: The name of the semantic model.
        from_table: The name of the table on the 'from' side of the relationship.
        from_column: The name of the column on the 'from' side of the relationship.
        to_table: The name of the table on the 'to' side of the relationship.
        to_column: The name of the column on the 'to' side of the relationship.
        from_cardinality: The cardinality on the 'from' side of the relationship (One/Many/None) 
        to_cardinality: The cardinality on the 'to' side of the relationship (One/Many/None)
        cross_filtering_behavior: An optional parameter for setting the cross filtering behavior. Default: 'Automatic'. Options: 'Automatic', 'OneDiredction', 'BothDirections'
        security_filtering_behavior: An optional parameter for setting the security filtering behavior. Default: 'OneDirection'. Options: 'OneDirection', 'BothDirections', 'None'
        is_active: An optional parameter for setting whether the relationship is active or not. Default:  True
        rely_on_referential_integrity: An optional parameter. Default: False
        workspace: An optional parameter to set the workspace in which the lakehouse resides. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of the operation.

    Example:

        add_relationship(
            dataset = 'AdventureWorks'
            ,from_table = 'Internet Sales'
            ,from_column = 'ProductKey'
            ,to_table = 'Product'
            ,to_column = 'ProductKey'
            ,from_cardinality = 'Many'
            ,to_cardinality = 'One'
            #,workspace = '' 
            )
    """

    from .HelperFunctions import resolve_dataset_id
    from .HelperFunctions import create_relationship_name

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)
    else:
        workspace_id = fabric.resolve_workspace_id(workspace)

    relObj = create_relationship_name(from_table,from_column,to_table,to_column)
    fromCardinality = fromCardinality.capitalize()
    toCardinality = toCardinality.capitalize()

    cfbValues = ['Automatic', 'OneDirection', 'BothDirections']
    sfbValues = ['None', 'OneDirection', 'BothDirections']

    if cross_filtering_behavior not in cfbValues:
        print(f"The 'crossFilteringBehavior' parameter must be one of these values: {cfbValues}")
        return
    if security_filtering_behavior not in sfbValues:
        print(f"The 'securityFilteringBehavior' parameter must be one of these values: {sfbValues}")
        return
    
    dfR = fabric.list_relationships(dataset = dataset, workspace = workspace)    
    dfR_filt = dfR[(dfR['From Table'] == from_table) & (dfR['From Column'] == from_column) & (dfR['To Table'] == to_table) & (dfR['To Column'] == to_column)]

    if len(dfR_filt) > 0:        
        print(f"The '{relObj}' relationship already exists in the '{dataset}' semantic model in the '{workspace}' workspace.")
        return
    
    tom_server = fabric.create_tom_server(readonly=False, workspace=workspace)

    print(f"Updating the '{dataset}' semantic model...")
    m = tom_server.Databases.GetByName(dataset).Model       
    try:
        rel = TOM.SingleColumnRelationship()
        rel.FromColumn = m.Tables[from_table].Columns[from_column]
        rel.FromCardinality = System.Enum.Parse(TOM.RelationshipEndCardinality, fromCardinality)
        rel.ToColumn = m.Tables[to_table].Columns[to_column]
        rel.ToCardinality = System.Enum.Parse(TOM.RelationshipEndCardinality, toCardinality)
        rel.IsActive = is_active
        rel.CrossFilteringBehavior = System.Enum.Parse(TOM.CrossFilteringBehavior, cross_filtering_behavior)
        rel.SecurityFilteringBehavior = System.Enum.Parse(TOM.SecurityFilteringBehavior, security_filtering_behavior)
        rel.RelyOnReferentialIntegrity = rely_on_referential_integrity
        m.Relationships.Add(rel)

        m.SaveChanges()
        print(f"The {relObj} relationship has been added to the '{dataset}' semantic model within the '{workspace}' workspace.")
    except:
        print(f"ERROR: The {relObj} relationship was not created.")

def add_role(dataset, role_name, model_permission = 'Read', role_description = None, workspace = None):

    """
    
    This function adds a new role to a semantic model.

    Parameters:

        dataset: The name of the semantic model.
        role_name: The name of the role to add to the semantic model.
        model_permission: An optional parameter to set the permission for the role. Default: 'Read'. Options: 'Read', 'ReadRefresh', 'Refresh', 'Administrator', 'None'
        role_description: An optional parameter to set the description of the role.
        workspace: An optional parameter to set the workspace in which the lakehouse resides. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of the operation.

    Example:

        add_role(
            dataset = 'AdventureWorks'
            ,role_name = 'Reader'
            ,role_description = 'This role is for...'
            #,workspace = '' 
            )
    """

    from .HelperFunctions import resolve_dataset_id

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)
    else:
        workspace_id = fabric.resolve_workspace_id(workspace)

    mpValues = ['Read', 'ReadRefresh', 'Refresh', 'Administrator', 'None']

    modelPermission = modelPermission.capitalize()
    
    if modelPermission not in mpValues:
        print(f"The 'modelPermission' parameter must be one of these values: {mpValues}")
        return

    dfRoles = fabric.get_roles(dataset = dataset, workspace = workspace)    
    dfRoles_filt = dfRoles[(dfRoles['Role'] == role_name)]    

    if len(dfRoles_filt) > 0:        
        print(f"The '{role_name}' role already exists in the '{dataset}' semantic model in the '{workspace}' workspace.")
        return

    datasetId = resolve_dataset_id(dataset, workspace)
    tom_server = fabric.create_tom_server(readonly=False, workspace=workspace)

    print(f"Updating the '{dataset}' semantic model...")
    m = tom_server.Databases[datasetId].Model        
    try:
        role = TOM.ModelRole()
        role.Name = role_name
        if role_description is not None:
            role.Description = role_description
        role.ModelPermission = System.Enum.Parse(TOM.ModelPermission, modelPermission)

        m.Roles.Add(role)
        m.SaveChanges()
        print(f"The '{role_name}' role has been added to the '{dataset}' semantic model within the '{workspace}' workspace.")
    except:
        print(f"ERROR: The '{role_name}' role was not created.")
    
def add_hierarchy(dataset, table_name, hierarchy_name, levels, hierarchy_description = None, workspace = None):

    """
    
    This function adds a new hierarchy to a semantic model.

    Parameters:

        dataset: The name of the semantic model.
        table_name: The name of the table in which the hierarchy will be added.
        hierarchy_name: The name of the hierarchy to be created.
        levels: An array of column names to be added to the hierarchy (see the example below).
        hierarchy_description: An optional parameter to set the description of the hierarchy.
        workspace: An optional parameter to set the workspace in which the lakehouse resides. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of the operation.

    Example:

        add_hierarchy(
            dataset = 'AdventureWorks'
            ,table_name = 'Geography'
            ,hierarchy_name = 'Geography Hierarchy'
            ,levels = ['Continent', 'Country', 'City']
            #,workspace = '' 
            )
    """

    from .HelperFunctions import resolve_dataset_id

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)
    else:
        workspace_id = fabric.resolve_workspace_id(workspace)

    dfH = fabric.list_hierarchies(dataset = dataset, workspace = workspace)
    dfH_filt = dfH[(dfH['Hierarchy Name'] == hierarchy_name) & (dfH['Table Name'] == table_name)]

    if len(dfH_filt) > 0:        
        print(f"ERROR: The '{hierarchy_name}' hierarchy already exists in the '{table_name}' table in the '{dataset}' semantic model in the '{workspaceName}' workspace.")
        return
    
    if isinstance(levels, str):
        print(f"ERROR: The 'levels' parameter must be an array.")
        return
    if len(levels) == 1:
        print(f"ERROR: The 'levels' parameter must be an array of multiple columns.")
        return
    
    dfC = fabric.list_columns(dataset = dataset, workspace = workspace)
    dfC_filt = dfC[(dfC['Table Name'] == table_name) & dfC['Column Name'].isin(levels)]

    if len(dfC_filt) < len(levels):
        print(f"ERROR: All levels must be valid columns within the '{table_name} table.")
        return

    tom_server = fabric.create_tom_server(readonly=False, workspace=workspace)

    print(f"Updating the '{dataset}' semantic model...")
    m = tom_server.Databases.GetByName(dataset).Model

    try:
        hier = TOM.Hierarchy()
        hier.Name = hierarchy_name
        if hierarchy_description is not None:
            hier.Description = hierarchy_description

        m.Tables[table_name].Hierarchies.Add(hier)
        print(f"The '{hierarchy_name}' hierarchy within the '{table_name}' table has been added.")

        try:
            lvl = TOM.Level()

            i = 0
            for levelName in levels:
                lvl.Column = m.Tables[table_name].Columns[levelName]
                lvl.Name = levelName
                lvl.Ordinal = i
                i+=1

                m.Tables[table_name].Hierarchies[hierarchy_name].Levels.Add(lvl)
                print(f"The '{levelName}' level within the '{hierarchy_name}' hierarchy in the '{table_name}' table has been added.")
        except:
            pass
    except:
        print(f"ERROR: The '{hierarchy_name}' hierarchy within the '{table_name}' table was not added.")
   
def add_rls(dataset, role_name, table_name, filter_expression, workspace = None):

    """
    
    This function adds row level security to a role/table within a semantic model.

    Parameters:

        dataset: The name of the semantic model.
        role_name: The name of the role to which row level security will be added.
        table_name: The name of the table for which to add row level security.
        filter_expression: The row level security (DAX) expression.        
        workspace: An optional parameter to set the workspace in which the lakehouse resides. This defaults to the workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of the operation.

    Example:

        add_rls(
            dataset = 'AdventureWorks'
            ,role_name = 'Reader'
            ,table_name = 'UserGeography'
            ,filter_expression = "'UserGeography'[UserEmail] = USERPRINCIPALNAME()"
            #,workspace = '' 
            )
    """

    from .HelperFunctions import resolve_dataset_id

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)
    else:
        workspace_id = fabric.resolve_workspace_id(workspace)

    dfRoles = fabric.get_roles(dataset = dataset, workspace = workspace)    
    dfT = fabric.list_tables(dataset = dataset, workspace = workspace)    
    dfRoles_filt = dfRoles[dfRoles['Role'] == role_name]  
    dfT_filt = dfT[dfT['Name'] == table_name]  

    if len(dfRoles_filt) == 0:        
        print(f"ERROR: The '{role_name}' role does not exist in the '{dataset}' semantic model in the '{workspace}' workspace.")
        return
    if len(dfT_filt)== 0:
        print(f"ERROR: The '{table_name}' table does not exist in the '{dataset}' semantic model in the '{workspace}' workspace.")
        return

    datasetId = resolve_dataset_id(dataset, workspace)
    tom_server = fabric.create_tom_server(readonly=False, workspace=workspace)

    print(f"Updating the '{dataset}' semantic model...")
    m = tom_server.Databases[datasetId].Model
    try:
        tp = TOM.TablePermission()
        tp.Table = m.Tables[table_name]
        tp.FilterExpression = filter_expression

        m.Roles[role_name].TablePermissions.Add(tp)

        m.SaveChanges()
        print(f"Row level security has been added to the '{role_name}' role for the '{table_name}' table in the '{dataset}' semantic model within the '{workspace}' workspace.")
    except:
        print(f"ERROR: Row level security has not been added to the '{role_name}' role  for the '{table_name}' table.")

def add_data_column(dataset, table_name, column_name, source_column, data_type, description = None, format_string = None, display_folder = None, workspace = None):

    """
    
    This function adds a new data column to a semantic model.

    Parameters:

        dataset: The name of the semantic model.
        table_name: The name of the table to which the column will be added.
        column_name: The name of the new column to be created.
        source_column: The name of the column in the source system.
        data_type: The data type of the new column. Valid options: 'Int64', 'String', 'Double', 'Decimal', 'DateTime', 'Boolean'.
        description: An optional paramter to set the description of the column.
        format_string: An optional parameter to set the format string of the column.
        display_folder: An optional parameter to set the display folder of the column.
        workspace: An optional parameter to set the workspace in which the lakehouse resides. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of the operation.

    Example:

    add_data_column(
        dataset = 'AdventureWorks'
        ,table_name = 'Internet Sales'
        ,column_name = 'SalesAmount'
        ,source_column = 'SalesAmount'
        ,data_type =  'Int64'
        #,format_string = ''
        #,display_folder = ''
        #,workspace = '' 
        )
    """

    from .HelperFunctions import resolve_dataset_id
    from .HelperFunctions import format_dax_object_name

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)
    else:
        workspace_id = fabric.resolve_workspace_id(workspace)

    validDataTypes = ['Int64', 'String', 'Double', 'Decimal', 'DateTime', 'Boolean']

    if data_type not in validDataTypes:
        print(f"ERROR: 'dataType' parameter is not valid. Must be one of the following values: {validDataTypes}.")
        return
    
    dfC = fabric.list_columns(dataset = dataset, workspace = workspace)
    dfC['Column Object'] = format_dax_object_name(dfC['Table Name'], dfC['Column Name'])

    fullColName = format_dax_object_name(table_name, column_name)
    dfC_filt = dfC[dfC['Column Object'] == fullColName]

    if len(dfC_filt) > 0:
        print(f"ERROR: The '{fullColName}' already exists in the '{dataset}' semantic model in the '{workspace}' workspace.")
        return

    tom_server = fabric.create_tom_server(readonly=False, workspace=workspace)

    print(f"Updating the '{dataset}' semantic model...")
    m = tom_server.Databases.GetByName(dataset).Model
    try:
        column = TOM.DataColumn()
        column.Name = column_name
        column.SourceColumn = source_column
        column.DataType = data_type
        if display_folder is not None:
            column.DisplayFolder = display_folder
        if description is not None:
            column.Description = description
        if format_string is not None:
            column.FormatString = format_string

        m.Tables[table_name].Columns.Add(column)
        m.SaveChanges()
        print(f"The '{fullColName}' column has been added to the '{dataset}' semantic model within the '{workspace}' workspace.")
    except:
        print(f"ERROR: The '{fullColName}' column was not created.")

def add_field_parameter(dataset, table_name, objects, workspace = None):

    """
    
    This function adds a field parameter as a calculated table to a semantic model.

    Parameters:

        dataset: The name of the semantic model.        
        table_name: The name of the field parameter table.
        objects: An array of columns/measures for the field parameter.
        workspace: An optional parameter to set the workspace in which the lakehouse resides. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of the operation.

    Example:

        add_field_parameter(
            dataset = 'AdventureWorks'
            ,table_name = 'Parameter'
            ,objects = ["[Sales Amount]", "[Order Qty]", "'Internet Sales'[Color]"]
            #,workspace = '' 
            )
    """

    from .HelperFunctions import resolve_dataset_id
    from .HelperFunctions import format_dax_object_name

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)
    else:
        workspace_id = fabric.resolve_workspace_id(workspace)

    if isinstance(objects,str):
        print(f"ERROR: The 'objects' parameter must be an array, not a text value string.")
        return
    if len(objects) == 1:
        print(f"ERROR: The 'objects' parameter must be an array of multiple values.")
        return

    dfM = fabric.list_measures(dataset = dataset, workspace = workspace)
    dfM['Measure Object'] = format_dax_object_name(dfM['Table Name'], dfM['Measure Name'])
    dfM['Measure Object No Table'] = '[' +  dfM['Measure Name'] + ']'
    dfC = fabric.list_columns(dataset = dataset, workspace = workspace)
    dfC['Column Object'] = format_dax_object_name(dfC['Table Name'], dfC['Column Name'])
    dfC['Column Object No Quotes'] = dfC['Table Name'] + '[' + dfC['Column Name'] + ']'
    expr = '{\n\t'

    i=0
    for obj in objects:
        if obj in dfM['Measure Object'].values or obj in dfM['Measure Object No Table'].values:
            dfM_filt = dfM[(dfM['Measure Object'] == obj) | (dfM['Measure Object No Table'] == obj)]
            objName = dfM_filt['Measure Name'].iloc[0]
            expr = expr + '("' + objName + '", NAMEOF(' + obj + '), ' + str(i) + '),\n'
        elif obj in dfC['Column Object'].values or obj in dfC['Column Object No Quotes'].values:
            dfC_filt = dfC[(dfC['Column Object'] == obj) | (dfC['Column Object No Quotes'] == obj)]
            objName = dfC_filt['Column Name'].iloc[0]
            fullObjName = dfC_filt['Column Object'].iloc[0]
            expr = expr + '("' + objName + '", NAMEOF(' + fullObjName + '), ' + str(i) + '),\n'
        else:
            print(f"ERROR: '{obj}' was not found...")
            return
        i+=1

    if expr.endswith(",\n"):
        expr = expr[:-2]
    expr = expr + '\n}'

    tom_server = fabric.create_tom_server(readonly=False, workspace=workspace)
    m = tom_server.Databases.GetByName(dataset).Model

    try:
        par = TOM.Partition()
        par.Name = table_name

        parSource = TOM.CalculatedPartitionSource()
        par.Source = parSource
        parSource.Expression = expr

        tbl = TOM.Table()
        tbl.Name = table_name
        tbl.Partitions.Add(par)

        columns = ['Value1', 'Value2', 'Value3']

        for colName in columns:
            col = TOM.CalculatedTableColumn()
            col.Name = colName
            col.SourceColumn = colName
            col.DataType = TOM.DataType.String

        m.Tables.Add(tbl)

        m.SaveChanges()

        ep = TOM.JsonExtendedProperty()
        ep.Name = 'ParameterMetadata'
        ep.Value = '{"version":3,"kind":2}'

        rcd = TOM.RelatedColumnDetails()
        gpc = TOM.GroupByColumn()
        gpc.GroupingColumn = m.Tables[table_name].Columns['Value2']
        rcd.GroupByColumns.Add(gpc)

        # Update column properties
        m.Tables[table_name].Columns['Value2'].IsHidden = True
        m.Tables[table_name].Columns['Value3'].IsHidden = True
        m.Tables[table_name].Columns['Value3'].DataType = TOM.DataType.Int64
        m.Tables[table_name].Columns['Value2'].SortByColumn = m.Tables[table_name].Columns['Value3']
        m.Tables[table_name].Columns['Value2'].ExtendedProperties.Add(ep)
        m.Tables[table_name].Columns['Value1'].RelatedColumnDetails = rcd

        m.SaveChanges()

        m.Tables[table_name].Columns['Value1'].Name = table_name
        m.Tables[table_name].Columns['Value2'].Name = table_name + ' Fields'
        m.Tables[table_name].Columns['Value3'].Name = table_name + ' Order'

        m.SaveChanges()
        print(f"The '{table_name}' table has been added as a field parameter to the '{dataset}' semantic model in the '{workspace}' workspace.")
    except:
        print(f"ERROR: The '{table_name}' table has not been added as a field parameter.")

def set_annotation(datasetName, objectType, objectName, annotationName, annotationValue, workspaceName = None):

    """

    This function adds a field parameter as a calculated table to a semantic model

    Parameters:

        datasetName: The name of the semantic model.        
        objectType: The object type upon which to set an annotation. Options: ['Model', 'Table', 'Partition', 'Column', 'Measure', 'Hierarchy', ]
        objectName: The object name upon which to set an annotation.
        annotationName: The name of the annotation.
        annotationValue: The value of the annotation.
        workspaceName: An optional parameter to set the workspace in which the lakehouse resides. This defaults to the
            workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of the operation.

    Examples:

        set_annotation(
            datasetName = 'AdventureWorks'
            ,objectType = 'Column'
            ,objectName = "'Internet Sales'[SalesAmount]"
            ,annotationName = 'hello'
            ,annotationValue = '33'            
            #,workspaceName = '' 
            )

        set_annotation(
            datasetName = 'AdventureWorks'
            ,objectType = 'Table'
            ,objectName = "Internet Sales"
            ,annotationName = 'hello'
            ,annotationValue = '33'            
            #,workspaceName = '' 
            )

        set_annotation(
            datasetName = 'AdventureWorks'
            ,objectType = 'Measure'
            ,objectName = "Sales Amount"
            ,annotationName = 'hello'
            ,annotationValue = '33'            
            #,workspaceName = '' 
            )
    """

    from .HelperFunctions import resolve_dataset_id
    from .HelperFunctions import format_dax_object_name
    from .ListFunctions import list_annotations

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)

    objectType = objectType.capitalize()

    if objectType == 'Model':
        objectName = 'Model'

    dfA = list_annotations(datasetName, workspaceName)
    dfA_filt = dfA[(dfA['Object Type'] == objectType) & (dfA['Object Name'] == objectName) & (dfA['Annotation Name'] == annotationName)]

    if len(dfA_filt) > 0:
        print(f"The '{annotationName}' annotation on the '{objectType}' object type in the '{datasetName}' semantic model already exists.")
        return

    tom_server = fabric.create_tom_server(readonly=False, workspace=workspaceName)
    datasetId = resolve_dataset_id(datasetName, workspaceName)
    m = tom_server.Databases[datasetId].Model

    ann = TOM.Annotation()
    ann.Name = annotationName
    ann.Value = annotationValue

    try:

        if objectType == 'Model':
            m.Annotations.Add(ann)
        elif objectType == 'Table':
            m.Tables[objectName].Annotations.Add(ann)
        elif objectType == 'Column':
            dfC = fabric.list_columns(dataset = datasetName, workspace = workspaceName)
            dfC['Column Object'] = format_dax_object_name(dfC['Table Name'], dfC['Column Name'])
            dfC_filt = dfC[dfC['Column Object'] == objectName]
            tName = dfC_filt['Table Name'].iloc[0]
            oName = dfC_filt['Column Name'].iloc[0]
            m.Tables[tName].Columns[oName].Add(ann)
        elif objectType == 'Measure':
            dfM = fabric.list_measures(dataset = datasetName, workspace = workspaceName)                
            dfM_filt = dfM[dfM['Measure Name'] == objectName]
            tName = dfM_filt['Table Name'].iloc[0]
            oName = dfM_filt['Measure Name'].iloc[0]
            m.Tables[tName].Measures[oName].Add(ann)
        elif objectType == 'Hierarchy':
            dfH = fabric.list_hierarchies(dataset = datasetName, workspace = workspaceName)
            dfH['Hierarchy Object'] = format_dax_object_name(dfH['Table Name'], dfH['Hierarchy Name'])
            dfH_filt = dfH[dfH['Hierarchy Object'] == objectName]
            tName = dfH_filt['Table Name'].iloc[0]
            oName = dfH_filt['Hierarchy Name'].iloc[0]
            m.Tables[tName].Hierarchies[oName].Add(ann)
        elif objectType == 'Partition':
            dfP = fabric.list_partitions(dataset = datasetName, workspace = workspaceName)
            dfP['Partition Object'] = format_dax_object_name(dfP['Table Name'], dfP['Partition Name'])
            dfP_filt = dfP[dfP['Partition Object'] == objectName]
            tName = dfP_filt['Table Name'].iloc[0]
            oName = dfP_filt['Partition Name'].iloc[0]
            m.Tables[tName].Partitions[oName].Add(ann)
        elif objectType == 'Data Source':
            m.DataSources[objectName].Add(ann)
        #elif objectType == 'Relationship':
        #    m.Relationship[objectName].Add(ann)
        elif objectType == 'Translation':
            m.Cultures[objectName].Add(ann)
        elif objectType == 'Expression':
            m.Expressions[objectName].Add(ann)
        elif objectType == 'Role':
            m.Roles[objectName].Add(ann)
        elif objectType == 'Perspective':
            m.Perspective[objectName].Add(ann)

        m.SaveChanges()
        print(f"The '{annotationName}' annotation on the '{objectName}' {objectType} in the '{datasetName}' semantic model has been created.")
    except:
        print(f"ERROR: '{annotationName}' annotation has not been created on for the '{objectName}' {objectType} in the '{datasetName}' semantic model.")
    
    m.SaveChanges()

        

        

