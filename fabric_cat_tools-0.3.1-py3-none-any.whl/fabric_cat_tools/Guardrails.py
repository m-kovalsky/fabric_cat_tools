import sempy
import sempy.fabric as fabric
import pandas as pd

def get_direct_lake_guardrails():

    """
    
    This function shows the Direct Lake guardrails based on Microsoft documentation.

    Parameters:
        
        This function has no parameters.

    Returns:

        This function returns a pandas dataframe showing the guardrails by SKU.
    """

    url = 'https://learn.microsoft.com/power-bi/enterprise/directlake-overview'

    tables = pd.read_html(url)
    df = tables[0]
    df['Fabric SKUs'] = df['Fabric SKUs'].str.split('/')
    df = df.explode('Fabric SKUs', ignore_index=True)
    
    return df

def get_sku_size(workspace = None):

    """
    
    This function obtains the SKU size for a given workpace.

    Parameters:
        
        workspace: An optional parameter to set the workspace. This defaults to the workspace in which the notebook resides.

    Returns:

        This function returns the SKU size for the workspace.
    """

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)

    dfC = fabric.list_capacities()
    dfW = fabric.list_workspaces().sort_values(by='Name', ascending=True)
    dfC.rename(columns={'Id': 'Capacity Id'}, inplace=True)
    dfCW = pd.merge(dfW, dfC[['Capacity Id', 'Sku', 'Region', 'State']], on='Capacity Id', how='inner')
    sku_value = dfCW.loc[dfCW['Name'] == workspace, 'Sku'].iloc[0]
    
    return sku_value

def get_directlake_guardrails_for_sku(sku_size):

    """
    
    This function obtains guardrails for a given SKU size.

    Parameters:
        
        skuSize: The SKU size for your capacity.

    Returns:

        This function returns a pandas dataframe showing the guardrails for the SKU size.
    """

    df = get_direct_lake_guardrails()
    filtered_df = df[df['Fabric SKUs'] == sku_size]
    
    return filtered_df