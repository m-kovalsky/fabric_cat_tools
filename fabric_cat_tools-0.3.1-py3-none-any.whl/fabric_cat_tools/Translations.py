import pandas as pd

def language_validate(language):
    
    url = 'https://learn.microsoft.com/azure/ai-services/translator/language-support'

    tables = pd.read_html(url)
    df = tables[0]

    df_filt = df[df['Language code'] == language]

    df_filt2 = df[df['Language'] == language.capitalize()]

    if len(df_filt) == 1:
        lang = df_filt['Language'].iloc[0]
    elif len(df_filt2) == 1:
        lang = df_filt2['Language'].iloc[0]
    else:
        print(f"The '{language}' language is not a valid language code. Please refer to this link for a list of valid language codes: {url}.")            
        return

    return lang        

        