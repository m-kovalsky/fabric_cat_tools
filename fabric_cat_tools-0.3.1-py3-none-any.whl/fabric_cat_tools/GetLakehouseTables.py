import sempy
import sempy.fabric as fabric
import pandas as pd
from pyspark.sql import SparkSession
import pyarrow.parquet as pq

def get_lakehouse_tables(lakehouse = None, workspace = None, extended = False, count_rows = False):

    """
    
    This function outputs a dataframe containing a list of tables in a lakehouse.

    Parameters:
        
        lakehouse: An optional parameter to set the lakehouse. This defaults to the lakehouse attached to the notebook.
        workspace: An optional parameter to indicate the workspace in which the lakehouse resides.
        extended: An optional boolean parameter. If set to true it will add additional table statistics regarding parquet/delta tables.
        count_rows: An optional boolean parameter. If set to true it will add a column showing the row count of each table.

    Returns:

        This function returns a pandas dataframe with the following columns:

            Workspace Name
            Lakehouse Name
            Table Name
            Format
            Type
            Location

        If extended==True, the following additional columns are returned.

            ['Files', 'Row Groups', 'Table Size', 'Parquet File Guardrail', 'Row Group Guardrail', 'Row Count Guardrail']
        
        If countRows==True the following additional column are returned.

            ['Row Count']

    Examples:

        get_lakehouse_tables(
        #lakehouse = ''
        #,workspace = ''
        ,extended = True
        ,count_rows = True)

        get_lakehouse_tables(
        #lakehouse = ''
        #,workspace = ''
        ,extended = True
        ,count_rows = False)
            
    """

    from .HelperFunctions import resolve_lakehouse_id
    from .HelperFunctions import resolve_lakehouse_name
    from .Guardrails import get_sku_size
    from .Guardrails import get_directlake_guardrails_for_sku

    df = pd.DataFrame(columns=['Workspace Name', 'Lakehouse Name', 'Table Name', 'Format', 'Type', 'Location'])

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)
    else:
        workspace_id = fabric.resolve_workspace_id(workspace)

    if lakehouse == None:
        lakehouse_id = fabric.get_lakehouse_id()
        lakehouse = resolve_lakehouse_name(lakehouse_id, workspace)
    else:
        lakehouse_id = resolve_lakehouse_id(lakehouse, workspace)

    if count_rows: #Setting countrows defaults to extended=True
        extended=True

    client = fabric.FabricRestClient()
    response = client.get(f"/v1/workspaces/{workspace_id}/lakehouses/{lakehouse_id}/tables")

    for i in response.json()['data']:
        tName = i['name']
        tType = i['type']
        tFormat = i['format']
        tLocation = i['location']
        if extended == False:
            new_data = {'Workspace Name': workspace, 'Lakehouse Name': lakehouse, 'Table Name': tName, 'Format': tFormat, 'Type': tType, 'Location': tLocation }
            df = pd.concat([df, pd.DataFrame(new_data, index=[0])], ignore_index=True)
        else:
            sku_value = get_sku_size(workspace)
            guardrail = get_directlake_guardrails_for_sku(sku_value)

            spark = SparkSession.builder.getOrCreate()
            
            intColumns = ['Files', 'Row Groups', 'Table Size']
            if tType == 'Managed' and tFormat == 'delta':
                detail_df = spark.sql(f"DESCRIBE DETAIL `{tName}`").collect()[0]
                num_files = detail_df.numFiles
                size_in_bytes = detail_df.sizeInBytes                

                delta_table_path = f"Tables/{tName}"
                latest_files = spark.read.format('delta').load(delta_table_path).inputFiles()
                file_paths = [f.split("/")[-1] for f in latest_files]

                # Handle FileNotFoundError
                num_rowgroups = 0
                for filename in file_paths:
                    try:
                        num_rowgroups += pq.ParquetFile(f"/lakehouse/default/{delta_table_path}/{filename}").num_row_groups
                    except FileNotFoundError:
                        continue                

                if count_rows:
                    num_rows = spark.table(tName).count()
                    intColumns.append('Row Count')
                    new_data = {'Workspace Name': workspace, 'Lakehouse Name': lakehouse, 'Table Name': tName, 'Format': tFormat, 'Type': tType, 'Location': tLocation, 'Files': num_files, 'Row Groups': num_rowgroups, 'Row Count': num_rows, 'Table Size': size_in_bytes }
                else:
                    new_data = {'Workspace Name': workspace, 'Lakehouse Name': lakehouse, 'Table Name': tName, 'Format': tFormat, 'Type': tType, 'Location': tLocation, 'Files': num_files, 'Row Groups': num_rowgroups, 'Table Size': size_in_bytes }

                df = pd.concat([df, pd.DataFrame(new_data, index=[0])], ignore_index=True)
                df[intColumns] = df[intColumns].astype(int)
                                
            df['SKU'] = guardrail['Fabric SKUs'].iloc[0]  
            df['Parquet File Guardrail'] = guardrail['Parquet files per table'].iloc[0]
            df['Row Group Guardrail'] = guardrail['Row groups per table'].iloc[0]
            df['Row Count Guardrail'] = guardrail['Rows per table (millions)'].iloc[0] * 1000000

            df['Parquet File Guardrail Hit'] = df['Files'] > df['Parquet File Guardrail']
            df['Row Group Guardrail Hit'] = df['Row Groups'] > df['Row Group Guardrail']

            if count_rows:
                df['Row Count Guardrail Hit'] = df['Row Count'] > df['Row Count Guardrail']

            #intColumns.extend(['Parquet File Guardrail', 'Row Group Guardrail', 'Row Count Guardrail'])
            #df[intColumns] = df[intColumns].astype(int)
            #df[intColumns] = df[intColumns].applymap('{:,}'.format)

    return df