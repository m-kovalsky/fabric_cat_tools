import sempy
import sempy.fabric as fabric
import pandas as pd
import json, os, time, base64

def get_semantic_model_bim(dataset, workspace = None, save_to_file_name = None):

    """

    This script gets the model.bim file for a given semantic model.

    Parameters:

        dataset: This is name of the semantic model.
        workspace: An optional parameter to set the workspace where the semantic model resides. This defaults to the
          workspace in which the notebook resides.
        save_to_file_name: Specifying this optional parameter will save the .bim file with the name of this parameter in the lakehouse attached to the notebook.

    Returns:

        This function returns the .bim file of a given semantic model.

    """

    from .HelperFunctions import resolve_lakehouse_name
    from .Lakehouse import lakehouse_attached

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)
    else:
        workspace_id = fabric.resolve_workspace_id(workspace)
    
    objType = 'SemanticModel'
    client = fabric.FabricRestClient()
    itemList = fabric.list_items(workspace = workspace)
    itemListFilt = itemList[(itemList['Display Name'] == dataset) & (itemList['Type'] == objType)]
    itemId = itemListFilt['Id'].iloc[0]
    response = client.post(f"/v1/workspaces/{workspace_id}/items/{itemId}/getDefinition")
        
    if response.status_code == 200:
        res = response.json()
    elif response.status_code == 202:
        operationId = response.headers['x-ms-operation-id']
        response = client.get(f"/v1/operations/{operationId}")
        response_body = json.loads(response.content) 
        while response_body['status'] != 'Succeeded':
            time.sleep(3)
            response = client.get(f"/v1/operations/{operationId}")
            response_body = json.loads(response.content)
        response = client.get(f"/v1/operations/{operationId}/result")
        res = response.json()
    df_items = pd.json_normalize(res['definition']['parts'])
    df_items_filt = df_items[df_items['path'] == 'model.bim']
    payload = df_items_filt['payload'].iloc[0]
    bimFile = base64.b64decode(payload).decode('utf-8')
    bimJson = json.loads(bimFile)

    if save_to_file_name is not None:        
        lakeAttach = lakehouse_attached()
        if lakeAttach == False:
            print(f"In order to save the model.bim file, a lakehouse must be attached to the notebook. Please attach a lakehouse to this notebook.")
            return
        
        lakehouse_id = fabric.get_lakehouse_id()
        lakehouse = resolve_lakehouse_name(lakehouse_id, workspace)
        folderPath = '/lakehouse/default/Files'
        fileExt = '.bim'
        if not save_to_file_name.endswith(fileExt):
            save_to_file_name = save_to_file_name + fileExt
        filePath = os.path.join(folderPath, save_to_file_name)
        with open(filePath, "w") as json_file:
            json.dump(bimJson, json_file, indent=4)
        print(f"The .bim file for the '{dataset}' semantic model has been saved to the '{lakehouse}' in this location: '{filePath}'.\n\n")

    return bimJson