import sempy
import sempy.fabric as fabric
import pandas as pd
from pyspark.sql import SparkSession
from delta import DeltaTable
import pyarrow.parquet as pq
import numpy as np

def get_lakehouse_tables(lakehouseName = None, workspaceName = None, extended = False, countRows = False):

    """
    
    This function outputs a dataframe containing a list of tables in a lakehouse.

    Parameters:
        
        lakehouseName: An optional parameter to set the lakehouse. This defaults to the lakehouse attached to the notebook.
        workspaceName: An optional parameter to indicate the workspace in which the lakehouse resides.
        extended: An optional boolean parameter. If set to true it will add additional table statistics regarding parquet/delta tables.
        countRows: An optional boolean parameter. If set to true it will add a column showing the row count of each table.

    Returns:

        This function returns a pandas dataframe with the following columns:

            Workspace Name
            Lakehouse Name
            Table Name
            Format
            Type
            Location

        If extended==True, the following additional columns are returned.

            ['Files', 'Row Groups', 'Table Size', 'Parquet File Guardrail', 'Row Group Guardrail', 'Row Count Guardrail']
        
        If countRows==True the following additional column are returned.

            ['Row Count']

    Examples:

        get_lakehouse_tables(
        #lakehouseName = ''
        #,workspaceName = ''
        ,extended = True
        ,countRows = True)

        get_lakehouse_tables(
        #lakehouseName = ''
        #,workspaceName = ''
        ,extended = True
        ,countRows = False)
            
    """

    from .HelperFunctions import resolve_lakehouse_id
    from .HelperFunctions import resolve_lakehouse_name
    from .Guardrails import get_sku_size
    from .Guardrails import get_directlake_guardrails_for_sku

    df = pd.DataFrame(columns=['Workspace Name', 'Lakehouse Name', 'Table Name', 'Format', 'Type', 'Location'])

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)

    if lakehouseName == None:
        lakehouseId = fabric.get_lakehouse_id()
        lakehouseName = resolve_lakehouse_name(lakehouseId)
    else:
        lakehouseId = resolve_lakehouse_id(lakehouseName, workspaceName)

    if countRows: #Setting countrows defaults to extended=True
        extended=True

    client = fabric.FabricRestClient()
    response = client.get(f"/v1/workspaces/{workspaceId}/lakehouses/{lakehouseId}/tables")

    for i in response.json()['data']:
        tName = i['name']
        tType = i['type']
        tFormat = i['format']
        tLocation = i['location']
        if extended == False:
            new_data = {'Workspace Name': workspaceName, 'Lakehouse Name': lakehouseName, 'Table Name': tName, 'Format': tFormat, 'Type': tType, 'Location': tLocation }
            df = pd.concat([df, pd.DataFrame(new_data, index=[0])], ignore_index=True)
        else:
            sku_value = get_sku_size(workspaceName)
            guardrail = get_directlake_guardrails_for_sku(sku_value)

            spark = SparkSession.builder.getOrCreate()
            
            intColumns = ['Files', 'Row Groups', 'Table Size']
            if tType == 'Managed' and tFormat == 'delta':
                detail_df = spark.sql(f"DESCRIBE DETAIL `{tName}`").collect()[0]
                num_files = detail_df.numFiles
                size_in_bytes = detail_df.sizeInBytes                

                delta_table_path = f"Tables/{tName}"
                latest_files = spark.read.format('delta').load(delta_table_path).inputFiles()
                file_paths = [f.split("/")[-1] for f in latest_files]

                # Handle FileNotFoundError
                num_rowgroups = 0
                for filename in file_paths:
                    try:
                        num_rowgroups += pq.ParquetFile(f"/lakehouse/default/{delta_table_path}/{filename}").num_row_groups
                    except FileNotFoundError:
                        continue                

                if countRows:
                    num_rows = spark.table(tName).count()
                    intColumns.append('Row Count')
                    new_data = {'Workspace Name': workspaceName, 'Lakehouse Name': lakehouseName, 'Table Name': tName, 'Format': tFormat, 'Type': tType, 'Location': tLocation, 'Files': num_files, 'Row Groups': num_rowgroups, 'Row Count': num_rows, 'Table Size': size_in_bytes }
                else:
                    new_data = {'Workspace Name': workspaceName, 'Lakehouse Name': lakehouseName, 'Table Name': tName, 'Format': tFormat, 'Type': tType, 'Location': tLocation, 'Files': num_files, 'Row Groups': num_rowgroups, 'Table Size': size_in_bytes }

                df = pd.concat([df, pd.DataFrame(new_data, index=[0])], ignore_index=True)                
                df[intColumns] = df[intColumns].astype(int)
                                
            df['SKU'] = guardrail['Fabric/Power BI SKUs'].iloc[0]  
            df['Parquet File Guardrail'] = guardrail['Parquet files per table'].iloc[0]
            df['Row Group Guardrail'] = guardrail['Row groups per table'].iloc[0]
            df['Row Count Guardrail'] = guardrail['Rows per table (millions)'].iloc[0] * 1000000

            df['Parquet File Guardrail Hit'] = df['Files'] > df['Parquet File Guardrail']
            df['Row Group Guardrail Hit'] = df['Row Groups'] > df['Row Group Guardrail']

            if countRows:
                df['Row Count Guardrail Hit'] = df['Row Count'] > df['Row Count Guardrail']

            #intColumns.extend(['Parquet File Guardrail', 'Row Group Guardrail', 'Row Count Guardrail'])
            #df[intColumns] = df[intColumns].astype(int)
            #df[intColumns] = df[intColumns].applymap('{:,}'.format)

    return df