import sempy
import sempy.fabric as fabric
import pandas as pd

def get_measure_dependencies(datasetName, workspaceName = None):

    """
    
    This function extracts the dependencies of all measures in a semantic model.

    Parameters:
        
        datasetName: This is name of the semantic model.        
        workspaceName: An optional parameter to set the workspace where the semantic model resides. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a pandas dataframe with the following columns:

            Table Name
            Object Name
            Object Type
            Referenced Table
            Referenced Object
            Referenced Object Type
            Parent Node            
    """

    from .HelperFunctions import create_daxfullobjectname

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)

    dep = fabric.evaluate_dax(dataset = datasetName, workspace = workspaceName, dax_string = 
        """
        SELECT 
         [TABLE] AS [Table Name]
        ,[OBJECT] AS [Object Name]
        ,[OBJECT_TYPE] AS [Object Type]
        ,[REFERENCED_TABLE] AS [Referenced Table]
        ,[REFERENCED_OBJECT] AS [Referenced Object]
        ,[REFERENCED_OBJECT_TYPE] AS [Referenced Object Type]
        FROM $SYSTEM.DISCOVER_CALC_DEPENDENCY
        WHERE [OBJECT_TYPE] = 'MEASURE'
        """)

    dep['Object Type'] = dep['Object Type'].str.capitalize()
    dep['Referenced Object Type'] = dep['Referenced Object Type'].str.capitalize()

    dep['Full Object Name'] =  create_daxfullobjectname(dep['Table Name'], dep['Object Name'])
    dep['Referenced Full Object Name'] = create_daxfullobjectname(dep['Referenced Table'], dep['Referenced Object'])
    dep['Parent Node'] = dep['Object Name']

    df = dep

    df['Done'] = df.apply(lambda row: False if row['Referenced Object Type'] == 'Measure' else True, axis=1)

    while(any(df['Done'] == False)):
        for i, r in df.iterrows():
            rObjFull = r['Referenced Full Object Name']
            rObj = r['Referenced Object']
            if r['Done'] == False:
                dep_filt = dep[dep['Full Object Name'] == rObjFull]

                for index, dependency in dep_filt.iterrows():
                    d = True
                    if dependency[5] == 'Measure':
                        d = False
                    df = pd.concat([df, pd.DataFrame([{'Table Name': r['Table Name'], 'Object Name': r['Object Name'], 'Object Type': r['Object Type']
                    , 'Referenced Object': dependency[4], 'Referenced Table': dependency[3], 'Referenced Object Type': dependency[5], 'Done': d, 'Full Object Name': r['Full Object Name'], 'Referenced Full Object Name': dependency[7],'Parent Node': rObj     }])], ignore_index=True)

            df.loc[i, 'Done'] = True

    df = df.drop(['Done','Full Object Name','Referenced Full Object Name'], axis=1)

    return df