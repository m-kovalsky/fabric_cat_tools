import sempy
import sempy.fabric as fabric
import pandas as pd
import json, os, time, base64
from anytree import Node, RenderTree

def get_report_json(reportName, workspaceName = None):

    """

    This function obtains the report.json file for a given Power BI report.

    Parameters:

        reportName: The report name.        
        workspaceName: An optional parameter to set the workspace in which report resides. This defaults to the
          workspace in which the notebook resides.

    Returns:

        The report.json file for a given Power BI report.

    """

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)

    client = fabric.FabricRestClient()

    dfI = fabric.list_items(workspace = workspaceName)
    dfI_filt = dfI[(dfI['Display Name'] == reportName) & (dfI['Type'] == 'Report')]

    if len(dfI_filt) == 0:
        print(f"The '{reportName}' report does not exist in the '{workspaceName}' workspace.")
        return
    
    itemId = dfI_filt['Id'].iloc[0]
    response = client.post(f"/v1/workspaces/{workspaceId}/items/{itemId}/getDefinition")
    df_items = pd.json_normalize(response.json()['definition']['parts'])
    df_items_filt = df_items[df_items['path'] == 'report.json']
    payload = df_items_filt['payload'].iloc[0]

    reportFile = base64.b64decode(payload).decode('utf-8')
    reportJson = json.loads(reportFile)

    return reportJson

def report_dependency_tree(workspaceName = None):

    """

    This function shows the dependencies...

    Parameters:

        reportName: The report name.        
        workspaceName: An optional parameter to set the workspace in which report resides. This defaults to the
          workspace in which the notebook resides.

    Returns:

        The report.json file for a given Power BI report.

    """

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    
    dfR = fabric.list_reports(workspace = workspaceName)
    dfD = fabric.list_datasets(workspace = workspaceName)
    dfR = pd.merge(dfR, dfD[['Dataset ID', 'Dataset Name']], left_on = 'Dataset Id', right_on = 'Dataset ID', how = 'left')
    dfR.rename(columns={'Name': 'Report Name'}, inplace=True)
    dfR = dfR[['Report Name', 'Dataset Name']]

    report_icon = '\U0001F4F6'
    dataset_icon = '\U0001F9CA'
    workspace_icon = '\U0001F465'

    node_dict = {}
    rootNode = Node(workspaceName)
    node_dict[workspaceName] = rootNode
    rootNode.custom_property = workspace_icon + ' '

    for i, r in dfR.iterrows():
        datasetName = r['Dataset Name']
        reportName = r['Report Name']
        parentNode = node_dict.get(datasetName)
        if parentNode is None:
            parentNode = Node(datasetName, parent = rootNode)
            node_dict[datasetName] = parentNode
        parentNode.custom_property = dataset_icon + ' '

        child_node = Node(reportName, parent=parentNode)
        child_node.custom_property = report_icon + ' '

    # Print the tree structure
    for pre, _, node in RenderTree(node_dict[workspaceName]):
        print(f"{pre}{node.custom_property}'{node.name}'")

def export_report(reportName, exportFormat, fileName = None, bookmarkName = None, pageName = None, visualName = None, workspaceName = None):

    """

    This function exports a Power BI report to a file in a specified format and saves the file to the Fabric lakehouse.

    Parameters:

        reportName: The report name.     
        exportFormat: The format in which to export the report. See this link for valid formats: https://learn.microsoft.com/rest/api/power-bi/reports/export-to-file-in-group#fileformat. For image formats, enter the file extension in this parameter, not 'IMAGE'.
        fileName: An optional parameter to specify the file name of the export file (no need to include the file extension). Default value is the reportName parameter.        
        bookmarkName: An optional parameter to have the report export based on a bookmark from the report.
        workspaceName: An optional parameter to set the workspace in which report resides. This defaults to the workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of this operation.

    Examples:

        export_report(
            reportName = 'AdventureWorks'
            ,exportFormat = 'PDF'
            #,fileName = None
            #,workspaceName = None
            )

        export_report(
            reportName = 'AdventureWorks'
            ,exportFormat = 'PDF'
            ,fileName = 'Exports\MyReport'
            #,workspaceName = None
            )

    """

    #https://learn.microsoft.com/rest/api/power-bi/reports/export-to-file-in-group

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)

    if bookmarkName is not None and (pageName is not None or visualName is not None):
        print(f"If the 'bookmarkName' parameter is set, the 'pageName' and 'visualName' parameters must not be set.")
        return
    if visualName is not None and pageName is None:
        print(f"If the 'visualName' parameter is set, the 'pageName' parameter must be set.")
        return

    validFormats = {
    'ACCESSIBLEPDF': '.pdf',
    'CSV': '.csv',
    'DOCX': '.docx',
    'MHTML': '.mhtml',
    'PDF': '.pdf',
    'PNG': '.png',
    'PPTX': '.pptx',
    'XLSX': '.xlsx',
    'XML': '.xml',
    'BMP': '.bmp',
    'EMF': '.emf',
    'GIF': '.gif',
    'JPEG': '.jpeg',
    'TIFF': '.tiff'
    }
    
    exportFormat = exportFormat.upper()
    if exportFormat not in validFormats:
        print(f"The '{exportFormat}' format is not a valid format for exporting Power BI reports. Please enter a valid format. Options: {validFormats}")
        return

    fileExt = validFormats.get(exportFormat)

    if fileName == None:
        fileName = reportName + fileExt
    else:
        fileName = fileName + fileExt

    folderPath = '/lakehouse/default/Files'
    filePath = os.path.join(folderPath, fileName)

    dfI = fabric.list_items(workspace = workspaceName)
    dfI_filt = dfI[(dfI['Type'] == 'Report') & (dfI['Display Name'] == reportName)]

    if len(dfI_filt) == 0:
        print(f"The '{reportName}' report does not exist in the '{workspaceName}' workspace.")
        return
    
    reportId = dfI_filt['Id'].iloc[0]
    client = fabric.PowerBIRestClient()

    if exportFormat in ['BMP', 'EMF', 'GIF', 'JPEG', 'TIFF']:
        request_body = {
                'format': 'IMAGE',
                'powerBIReportConfiguration': {
                    'formatSettings': {
                        'OutputFormat': exportFormat.lower()
                    }
                }
        }
    elif bookmarkName is None and pageName is None and visualName is None:
        request_body = {
                'format': exportFormat
            }
    elif bookmarkName is not None:
        request_body = {
                'format': exportFormat,
                'powerBIReportConfiguration': {
                    'defaultBookmark': {
                        'name': bookmarkName
                    }
                }
        }
    elif pageName is not None and visualName is None:
        request_body = {
                'format': exportFormat,
                'powerBIReportConfiguration': {
                    'pages': {
                        'pageName': pageName
                    }
                }
        }
    elif pageName is not None and visualName is not None:
        request_body = {
                'format': exportFormat,
                'powerBIReportConfiguration': {
                    'pages': {
                        'pageName': pageName,
                        'visualName': visualName
                    }
                }
        }

    response = client.post(f"/v1.0/myorg/groups/{workspaceId}/reports/{reportId}/ExportTo",json=request_body)
    if response.status_code == 202:
        response_body = json.loads(response.content)
        exportId = response_body['id']
        response = client.get(f"/v1.0/myorg/groups/{workspaceId}/reports/{reportId}/exports/{exportId}")
        response_body = json.loads(response.content)
        while response_body['status'] not in ['Succeeded', 'Failed']:
            time.sleep(3)
            response = client.get(f"/v1.0/myorg/groups/{workspaceId}/reports/{reportId}/exports/{exportId}")
            response_body = json.loads(response.content)
        if response_body['status'] == 'Failed':
            print(f"The export for the '{reportName}' report within the '{workspaceName}' workspace in the '{exportFormat}' format has failed.")
        else:
            print("Export succeeded.")
            response = client.get(f"/v1.0/myorg/groups/{workspaceId}/reports/{reportId}/exports/{exportId}/file")
            print(f"Saving the '{exportFormat}' export for the '{reportName}' report within the '{workspaceName}' workspace to the lakehouse...")
            with open(filePath, "wb") as export_file:
                export_file.write(response.content)
            print(f"The '{exportFormat}' export for the '{reportName}' report within the '{workspaceName}' workspace has been saved to the following location: '{filePath}'.")


def clone_report(reportName, clonedReportName, workspaceName = None, targetWorkspaceName = None, targetDatasetName = None):

    """

    This function clones a Power BI report.

    Parameters:

        reportName: The name of the report to be cloned.
        clonedReportName: The name of the new report.         
        workspaceName: An optional parameter to set the workspace in which report resides. This defaults to the workspace in which the notebook resides.
        targetWorkspaceName: An optional parameter to set the target workspace in which the cloned report will reside. This defaults to the workspace in which the notebook resides.
        targetDatasetName: An optional parameter to set the target dataset from which the cloned report will be fed. This defaults to the dataset used by the original report.

    Returns:

        This function returns a printout stating the success/failure of this operation.

    Examples:

        clone_report(
            reportName = 'MyReport'
            ,clonedReportName = 'MyNewReport'
            #,workspaceName = None
            #,targetWorkspace = None
            #,targetDatasetName = None
            )

        clone_report(
            reportName = 'MyReport'
            ,clonedReportName = 'MyNewReport'
            #,workspaceName = None
            #,targetWorkspace = 'Other workspace'
            #,targetDatasetName = 'AdventureWorks'
            )

    """

    #https://learn.microsoft.com/rest/api/power-bi/reports/clone-report-in-group

    from .HelperFunctions import resolve_dataset_name
    from .HelperFunctions import resolve_report_id

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)

    dfI = fabric.list_items(workspace = workspaceName)
    dfI_filt = dfI[(dfI['Type'] == 'Report') & (dfI['Display Name'] == reportName)]    

    if len(dfI_filt) == 0:
        print(f"The '{reportName}' report does not exist within the '{workspaceName}' workspace.")
        return
    
    reportId = resolve_report_id(reportName, workspaceName)

    if targetWorkspaceName is None:
        targetWorkspaceName = workspaceName
        targetWorkspaceId = workspaceId
    else:
        dfW = fabric.list_workspaces()
        dfW_filt = dfW[dfW['Name'] == targetWorkspaceName]

        if len(dfW_filt) == 0:
            print(f"The '{workspaceName}' is not a valid workspace.")
            return
        targetWorkspaceId = dfW_filt['Id'].iloc[0]
    
    if targetDatasetName == None:
        dfR = fabric.list_reports(workspace = targetWorkspaceName)
        dfR_filt = dfR[dfR['Name'] == reportName]
        targetDatasetId = dfR_filt['Dataset Id'].iloc[0]
        targetDatasetName = resolve_dataset_name(datasetId = targetDatasetId, workspaceName = targetWorkspaceName)
    else:
        dfD = fabric.list_datasets(workspace = targetWorkspaceName)
        dfD_filt = dfD[dfD['Dataset Name'] == targetDatasetName]

        if len(dfD_filt) == 0:
            print(f"The '{targetDatasetName}' target dataset does not exist in the '{targetWorkspaceName}' workspace.")
            return        
        targetDatasetId = dfD_filt['Dataset Id'].iloc[0]

    client = fabric.PowerBIRestClient()

    if targetWorkspaceName is None and targetDatasetName is None:
        request_body = {
            "name": clonedReportName
        }
    elif targetWorkspaceName is not None and targetDatasetName is None:
        request_body = {
            "name": clonedReportName,
            "targetWorkspaceId": targetWorkspaceId
        }
    elif targetWorkspaceName is not None and targetDatasetName is not None:
        request_body = {
            "name": clonedReportName,
            "targetModelId": targetDatasetId,
            "targetWorkspaceId": targetWorkspaceId
        }
    elif targetWorkspaceName is None and targetDatasetName is not None:
        request_body = {
            "name": clonedReportName,
            "targetModelId": targetDatasetId
        }

    response = client.post(f"/v1.0/myorg/groups/{workspaceId}/reports/{reportId}/Clone",json=request_body)

    if response.status_code == 200:
        print('POST request successful')        
        print(f"The '{reportName}' report has been successfully cloned as the '{clonedReportName}' report within the '{targetWorkspaceName}' workspace using the '{targetDatasetName}' semantic model.")
    else:
        print(f"POST request failed with status code: {response.status_code}")