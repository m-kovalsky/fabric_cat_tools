import sempy
import sempy.fabric as fabric
import pandas as pd
sempy.fabric._client._utils._init_analysis_services()
import Microsoft.AnalysisServices.Tabular as TOM

def update_direct_lake_partition_entity(dataset: str, table_name: str | list, entity_name: str | list, workspace: str | None = None, lakehouse: str | None = None, lakehouse_workspace: str | None = None):

    """
    
    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#update_direct_lake_partition_entity

    """

    from .GetLakehouseTables import get_lakehouse_tables
    #from .GetDirectLakeLakehouse import get_direct_lake_lakehouse
    from .HelperFunctions import resolve_lakehouse_name
    from .HelperFunctions import get_direct_lake_sql_endpoint

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)
    else:
        workspace_id = fabric.resolve_workspace_id(workspace)   

    if lakehouse_workspace == None:
        lakehouse_workspace = workspace

    if lakehouse is None:
        lakehouse_id = fabric.get_lakehouse_id()
        lakehouse = resolve_lakehouse_name(lakehouse_id, lakehouse_workspace)

    sqlEndpointId = get_direct_lake_sql_endpoint(dataset, workspace)

    dfI = fabric.list_items(workspace = lakehouse_workspace)
    dfI_filt = dfI[(dfI['Type'] == 'SQLEndpoint') & (dfI['Id'] == sqlEndpointId)]

    if len(dfI_filt) == 0:
        print(f"The SQL Endpoint in the '{dataset}' semantic model in the '{workspace} workspace does not point to the '{lakehouse}' lakehouse in the '{lakehouse_workspace}' workspace as specified.")
        return

    # Support both str & list types
    if isinstance(table_name, str):
        table_name = [table_name]
    if isinstance(entity_name, str):
        entity_name = [entity_name]
    
    if len(table_name) != len(entity_name):
        print(f"ERROR: The 'table_name' and 'entity_name' arrays must be of equal length.")
        return
    
    dfP = fabric.list_partitions(dataset = dataset, workspace = workspace)
    dfP_filt = dfP[(dfP['Table Name'].isin(table_name)) & (dfP['Mode'] == 'DirectLake')]        

    if len(dfP_filt) == 0:
        print(f"ERROR: The '{table_name}' tables in the '{dataset}' semantic model is not in Direct Lake mode. This function is only applicable to tables in Direct Lake mode.")
        return
    
    tblent = pd.DataFrame({
        'Table Name': table_name,
        'Entity Name': entity_name
    })

    lt = get_lakehouse_tables(lakehouse, lakehouse_workspace)

    tom_server = fabric.create_tom_server(readonly=False, workspace=workspace)
    print(f"Updating the '{dataset}' semantic model...")
    m = tom_server.Databases.GetByName(dataset).Model

    for i, r in dfP_filt.iterrows():
        tName = r['Table Name']
        pName = r['Partition Name']
        tblent_filt = tblent[tblent['Table Name'] == tName]
        eName = tblent_filt['Entity Name'].iloc[0]
    
        lt_filt = lt[lt['Table Name'] == eName]
    
        if len(lt_filt) == 0:
            print(f"ERROR: The '{lakehouse}' lakehouse used by the '{dataset}' semantic model has no table named '{eName}'. The '{tName}' table was not updated.")
        else:
            shEx = m.Expressions['DatabaseQuery']
            ep = TOM.EntityPartitionSource()
            ep.EntityName = eName
            ep.ExpressionSource = shEx
            
            try:
                m.Tables[tName].Partitions[pName].Source = ep                
                print(f"The '{tName}' table in the '{dataset}' semantic model has been updated to point to the '{eName}' table in the '{lakehouse}' lakehouse within the '{lakehouse_workspace}' workspace.")
            except:
                print(f"ERROR: The '{tName}' table in the '{dataset}' semantic model has not been updated.")

    m.SaveChanges()



    

