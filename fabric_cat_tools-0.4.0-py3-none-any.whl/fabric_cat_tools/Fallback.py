import sempy
import sempy.fabric as fabric
import numpy as np
sempy.fabric._client._utils._init_analysis_services()
import Microsoft.AnalysisServices.Tabular as TOM
import System

def check_fallback_reason(dataset: str, workspace: str | None = None):

    """
    
    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#check_fallback_reason

    """

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)

    dfP = fabric.list_partitions(dataset = dataset, workspace = workspace)
    dfP_filt = dfP[dfP['Mode'] == 'DirectLake']
    
    if len(dfP_filt) == 0:
        print(f"The '{dataset}' semantic model is not in Direct Lake. This function is only applicable to Direct Lake semantic models.")
    else:
        df = fabric.evaluate_dax(dataset = dataset,workspace = workspace,
        dax_string = 
        """
        SELECT [TableName] AS [Table Name],[FallbackReason] AS [FallbackReasonID]
        FROM $SYSTEM.TMSCHEMA_DELTA_TABLE_METADATA_STORAGES
        """    
        )        

        value_mapping = {
            0: 'No reason for fallback',
            1: 'This table is not framed',
            2: 'This object is a view in the lakehouse',
            3: 'The table does not exist in the lakehouse',
            4: 'Transient error',
            5: 'Using OLS will result in fallback to DQ',
            6: 'Using RLS will result in fallback to DQ'
        }

        # Create a new column based on the mapping
        df['Fallback Reason Detail'] = np.vectorize(value_mapping.get)(df['FallbackReasonID'])
        
        return df
    
def control_fallback(dataset, direct_lake_behavior, workspace = None):

    """
    
    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#control_fallback

    """

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)
    else:
        workspace_id = fabric.resolve_workspace_id(workspace)

        #direct_lake_behavior = direct_lake_behavior.capitalize().replace(' ','')

    dlValues = ['Automatic', 'DirectLakeOnly', 'DirectQueryOnly']

    if direct_lake_behavior not in dlValues:
        print(f"The 'directLakeBehavior' parameter must be one of these values: {dlValues}.")
        return

    dfP = fabric.list_partitions(dataset = dataset, workspace = workspace)
    dfP_filt = dfP[dfP['Mode'] == 'DirectLake']

    if len(dfP_filt) == 0:
        print(f"The '{dataset}' semantic model in the '{workspace}' workspace is not in Direct Lake mode. This function is only applicable to semantic models in Direct Lake mode.")
        return

    tom_server = fabric.create_tom_server(readonly=False, workspace=workspace)
    m = tom_server.Databases.GetByName(dataset).Model

    try:
        m.DirectLakeBehavior = System.Enum.Parse(TOM.DirectLakeBehavior, direct_lake_behavior)
        m.SaveChanges()
        print(f"Direct Lake Behavior set to '{direct_lake_behavior}' for the '{dataset}' semantic model in the '{workspace}' workspace.")
    except:
        print(f"ERROR: Direct Lake Behavior setting was not changed for the '{dataset}' semantic model in the '{workspace}' workspace.")