import sempy
import sempy.fabric as fabric
import json
import pandas as pd
import base64
import time

def create_report_from_reportjson(reportName, datasetName, reportJson, themeJson = None, workspaceName = None):

    """

    This function creates a Power BI report based on a report.json file, binded to a specified semantic model.

    Parameters:

        reportName: The report name.
        datasetName: The name of the semantic model to bind to the report.
        reportJson: The report.json file to be used to generate the report.
        themeJson: An optional parameter to set the theme json file for the report.
        workspaceName: An optional parameter to set the workspace in which the semantic model will be created. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of the operation.

    """

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)

    objectType = 'Report'

    dfI = fabric.list_items(workspace = workspaceName)
    dfI_filt = dfI[(dfI['Display Name'] == datasetName) & (dfI['Type'] == 'SemanticModel')]

    if len(dfI_filt) == 0:
        print(f"ERROR: The '{datasetName}' semantic model does not exist in the '{workspaceName}' workspace.")
        return
    
    datasetId = dfI_filt['Id'].iloc[0]

    dfI_filt = dfI[(dfI['Display Name'] == reportName) & (dfI['Type'] == 'Report')]

    if len(dfI_filt) > 0:
        print(f"WARNING: '{reportName}' already exists as a report in the '{workspaceName}' workspace.")
        return

    client = fabric.FabricRestClient()
    defPBIR = {
    "version": "1.0",
    "datasetReference": {
        "byPath": None,
        "byConnection": {
            "connectionString": None,
            "pbiServiceModelId": None,
            "pbiModelVirtualServerName": "sobe_wowvirtualserver",
            "pbiModelDatabaseName": datasetId,
            "name": "EntityDataSource",
            "connectionType": "pbiServiceXmlaStyleLive"
        }
    }
}

    def conv_b64(file):
        
        loadJson = json.dumps(file)
        f = base64.b64encode(loadJson.encode('utf-8')).decode('utf-8')
        
        return f

    definitionPBIR = conv_b64(defPBIR)
    payloadReportJson = conv_b64(reportJson)
    
    if themeJson == None:      
        request_body = {
                'displayName': reportName,
                'type': objectType,
                'definition': {
            "parts": [
                {
                    "path": "report.json",
                    "payload": payloadReportJson,
                    "payloadType": "InlineBase64"
                },
                {
                    "path": "definition.pbir",
                    "payload": definitionPBIR,
                    "payloadType": "InlineBase64"
                }
            ]

                }
            }
    else:
        payloadThemeJson = conv_b64(themeJson)
        themeID = themeJson['payload']['blob']['displayName']
        themePath = 'StaticResources/SharedResources/BaseThemes/' + themeID + '.json'
        request_body = {
                'displayName': reportName,
                'type': objectType,
                'definition': {
            "parts": [
                {
                    "path": "report.json",
                    "payload": payloadReportJson,
                    "payloadType": "InlineBase64"
                },
                {
                    "path": themePath,
                    "payload": payloadThemeJson,
                    "payloadType": "InlineBase64"
                },
                {
                    "path": "definition.pbir",
                    "payload": definitionPBIR,
                    "payloadType": "InlineBase64"
                }
            ]

                }
            }

    response = client.post(f"/v1/workspaces/{workspaceId}/items",json=request_body)

    if response.status_code == 201:
        print('Report creation succeeded')
        print(response.json())
    elif response.status_code == 202:
        location_url = response.headers['Location']
        operationId = response.headers['x-ms-operation-id']
        response = client.get(f"/v1/operations/{operationId}")
        response_body = json.loads(response.content) 
        while response_body['status'] != 'Succeeded':
            time.sleep(3)
            response = client.get(f"/v1/operations/{operationId}")
            response_body = json.loads(response.content)
        response = client.get(f"/v1/operations/{operationId}/result")
        print('Report creation succeeded')
        print(response.json())