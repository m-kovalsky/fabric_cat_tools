import sempy
import sempy.fabric as fabric
import pandas as pd
import re
sempy.fabric._client._utils._init_analysis_services()
import Microsoft.AnalysisServices.Tabular as TOM
import System

def migrate_calc_tables_to_semantic_model(datasetName, newDatasetName, workspaceName = None):
    
    """

    This function migrates calculated tables (except field parameters) from one semantic model to a new semantic model. 
    This is primarily for migrating semantic models to Direct Lake mode.

    Calculated tables are not supported in Direct Lake mode. As such, this adds the tables as
    regular tables which source their data from the delta tables in the lakehouse.

    Parameters:
        
        datasetName: This is name of the old semantic model.
        newDatasetName: This is the name of the new semantic model.
        workspaceName: Optional parameter specifying the workspace of the two semantic models.

    Returns:

        This returns a printout of which tables/columns were added to the new semantic model.
    """

    from .ListFunctions import list_tables
    from .ListFunctions import list_annotations
    from .GetLakehouseColumns import get_lakehouse_columns
    from .HelperFunctions import resolve_dataset_id

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)

    # Get calc tables but not field parameters
    dfP = fabric.list_partitions(dataset = datasetName, workspace = workspaceName)
    dfP_filt = dfP[(dfP['Source Type'] == 'Calculated')]
    dfP_filt = dfP_filt[~dfP_filt['Query'].str.contains('NAMEOF')]

    dfC = fabric.list_columns(dataset = datasetName, workspace = workspaceName)
    lc = get_lakehouse_columns() # add parameters
    # Get all calc table columns of calc tables not including field parameters
    dfC_filt = dfC[(dfC['Table Name'].isin(dfP_filt['Table Name'])) & (dfC['Type'] == 'CalculatedTableColumn')]
    dfA = list_annotations(newDatasetName, workspaceName)
    dfA_filt = dfA[(dfA['Object Type'] == 'Model') & ~ (dfA['Annotation Value'].str.contains('NAMEOF'))]

    tom_server = fabric.create_tom_server(readonly=False, workspace=workspaceName)
    newDatasetId = resolve_dataset_id(newDatasetName, workspaceName)

    if len(dfP_filt) == 0:
        print(f"The '{datasetName}' semantic model has no calculated tables.")
        return

    print(f"Updating '{newDatasetName}' based on '{datasetName}'...")
    m = tom_server.Databases[newDatasetId].Model
    exp = m.Expressions['DatabaseQuery']
    for tName in dfC_filt['Table Name'].unique():
        if tName.lower() in lc['Table Name'].values:
            tbl = TOM.Table()
            tbl.Name = tName

            ep = TOM.EntityPartitionSource()
            ep.Name = tName
            ep.EntityName = tName.replace(' ', '_').lower() #lakehouse table names use underscores instead of spaces
            ep.ExpressionSource = exp

            part = TOM.Partition()
            part.Name = tName
            part.Source = ep
            part.Mode = TOM.ModeType.DirectLake

            tbl.Partitions.Add(part)

            columns_in_table = dfC_filt.loc[dfC_filt['Table Name'] == tName, 'Column Name'].unique()

            for cName in columns_in_table:
                scName = dfC.loc[(dfC['Table Name'] == tName) & (dfC['Column Name'] == cName), 'Source'].iloc[0]
                cDataType = dfC.loc[(dfC['Table Name'] == tName) & (dfC['Column Name'] == cName), 'Data Type'].iloc[0]

                if tName in dfA_filt['Annotation Name'].values:
                    pattern = r"\[([^\]]+)\]"
            
                    matches = re.findall(pattern, scName) 
                    scName = matches[0]
                    scName = scName.replace(' ','')

                tc = "'" + tName.lower() + "'[" + scName + "]"
                if tc in lc['Full Column Name'].values:
                    lc_filt = lc[lc['Full Column Name'] == tc]
                    sc = lc_filt['Column Name'].iloc[0]
                    col = TOM.DataColumn()
                    col.Name = cName
                    col.SourceColumn = sc
                    col.DataType = System.Enum.Parse(TOM.DataType, cDataType)

                    try:
                        tbl.Columns.Add(col)
                        print(f"The '{tName}'[{cName}] column has been added.")
                    except:
                        print(f"ERROR: The '{tName}'[{cName}] column has not been added.")                    
        try:
            m.Tables.Add(tbl)
            print(f"The '{tName}' table has been added.")
        except:
            print(f"ERROR: The '{tName}' table has not been added.")
                
    m.SaveChanges()
    print(f"\nAll viable calculated tables have been added to the model.")