import sempy
import sempy.fabric as fabric
import pandas as pd
import re
from pyspark.sql import SparkSession

def refresh_calc_tables(datasetName, workspaceName = None):

    """
    
    This function will repopulate the lakehouse delta tables based on the calculated table logic now stored in the 
    Direct Lake model's annotations. 
    
    This function must be executed after the Direct Lake model is created.

    This function should be executed each time you updated lakehouse tables as it will repopulate the respective 
    lakehouse tables based on its dependencies.

    Parameters:

        datasetName: The semantic model name.
        workspaceName: An optional parameter to set the workspace where the semantic model resides. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of this operation.
    """

    from .ListFunctions import list_annotations

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)

    dfA = list_annotations(datasetName, workspaceName)
    dfA_filt = dfA[(dfA['Object Type'] == 'Model')]
    dfP = fabric.list_partitions(dataset = datasetName, workspace = workspaceName)
    dfP_filt = dfP[dfP['Table Name'].isin(dfA_filt['Annotation Name'])] # only tables which have annotations (are calc tables)
    dfC = fabric.list_columns(dataset = datasetName, workspace = workspaceName)
    dfC['Full Column Name'] = "'" + dfC['Table Name'] + "'[" + dfC['Column Name'] + "]"
    dfC_filt = dfC[dfC['Table Name'].isin(dfP_filt['Table Name'])] # only tables which are valid tables (with annotations)
    dfA_filt = dfA_filt[dfA_filt['Annotation Name'].isin(dfP['Table Name'])]
    
    spark = SparkSession.builder.getOrCreate()

    if len(dfC_filt) == 0:
        print(f"The '{datasetName}' semantic model has no tables which were calculated tables in the original semantic model.")
    else:
        for i,r in dfA_filt.iterrows():
            tName = r['Annotation Name']
            query = r['Annotation Value']
            daxquery = 'EVALUATE \n' + query

            try:
                df = fabric.evaluate_dax(dataset = datasetName, dax_string = daxquery, workspace = workspaceName)

                # Update column names for non-field parameters
                if query.find('NAMEOF') == -1:
                    for old_column_name in df.columns:
                        pattern = r"\[([^\]]+)\]"
                        
                        matches = re.findall(pattern, old_column_name) 
                        new_column_name = matches[0]
                        new_column_name = new_column_name.replace(' ','')
                    
                        df.rename(columns={old_column_name: new_column_name}, inplace=True)

                        # Update data types for lakehouse columns
                        dfC_type = dfC[(dfC['Table Name'] == tName) & (dfC['Source'] == new_column_name)]
                        dataType = dfC_type['Data Type'].iloc[0]                    
                        
                        if dataType == 'Int64':
                            df[new_column_name] = df[new_column_name].astype(int)
                        elif dataType in ['Decimal', 'Double']:
                            df[new_column_name] = df[new_column_name].astype(float)
                        elif dataType == 'Boolean':
                            df[new_column_name] = df[new_column_name].astype(bool)
                        elif dataType == 'DateTime':
                            df[new_column_name] = pd.to_datetime(df[new_column_name])
                else:
                    second_column_name = df.columns[1]
                    third_column_name = df.columns[2]
                    df[third_column_name] = df[third_column_name].astype(int)

                    # Remove calc columns from field parameters
                    mask = df[second_column_name].isin(dfC_filt['Full Column Name'])
                    df = df[~mask]

                delta_table_name = tName.replace(' ','_')

                spark_df = spark.createDataFrame(df)
                spark_df.write.mode('overwrite').format('delta').saveAsTable(delta_table_name)
                print(f"Calculated table '{tName}' has been created as delta table '{delta_table_name.lower()}' in the lakehouse.")
            except:
                print(f"Failed to create calculated table '{tName}' as a delta table in the lakehouse.")