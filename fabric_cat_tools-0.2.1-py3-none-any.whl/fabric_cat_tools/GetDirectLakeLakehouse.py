import sempy
import sempy.fabric as fabric
import pandas as pd
import re

def get_direct_lake_lakehouse(datasetName, workspaceName = None, lakehouseName = None, lakehouseWorkspaceName = None):

    """
    
    This function identifies the lakehouse used by a Direct Lake semantic model.

    Note: This only works if the semantic model and lakehouse used for the Direct Lake connection are in the same workspace.

    Parameters:
        
        datasetName: The name of the semantic model. 
        workspaceName: An optional parameter to set the workspace in which the lakehouse resides. This defaults to the
          workspace in which the notebook resides.
        lakehouseName: An optional parameter to set the lakehouse name used in the Direct Lake semantic model.
        lakehouseWorkspaceName: An optional parameter to set the workspace in which the lakehouse resides. If you specify a lakehouseName you must specify a lakehouseWorkspaceName.  

    Returns:

        This function returns the lakehouse name and ID.
    """

    from .HelperFunctions import resolve_lakehouse_id

    if workspaceName == None:
        workspaceID = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceID)
    else:
        workspaceID = fabric.resolve_workspace_id(workspaceName)

    if lakehouseWorkspaceName is None and lakehouseName is not None:
        print(f"ERROR: If you specify a lakehouseName you must also specify a lakehouseWorkspaceName.")
        return
    elif lakehouseWorkspaceName is None:
        lakehouseWorkspaceName = workspaceName

    dfP = fabric.list_partitions(dataset = datasetName, workspace = workspaceName)
    dfP_filt = dfP[dfP['Mode'] == 'DirectLake']

    if len(dfP_filt) == 0:
        print(f"ERROR: The '{datasetName}' semantic model is not in Direct Lake mode.")
    else:
        dfE = fabric.list_expressions(dataset = datasetName, workspace = workspaceName)
        dfE_filt = dfE[dfE['Name']== 'DatabaseQuery']
        expr = dfE_filt['Expression'].iloc[0]

        matches = re.findall(r'"([^"]*)"', expr)

        sqlEndpointId = matches[1]

        dfI = fabric.list_items(workspace = lakehouseWorkspaceName)
        dfI_filt = dfI[dfI['Id'] == sqlEndpointId]
        lakehouseName = dfI_filt['Display Name'].iloc[0]

        lakehouseId = resolve_lakehouse_id(lakehouseName, lakehouseWorkspaceName)

        return lakehouseName, lakehouseId
    
   

