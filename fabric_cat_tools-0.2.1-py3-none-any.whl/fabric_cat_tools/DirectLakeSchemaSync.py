import sempy
import sempy.fabric as fabric
import fabric_cat_tools as fct
import pandas as pd
sempy.fabric._client._utils._init_analysis_services()
import Microsoft.AnalysisServices.Tabular as TOM
import System

def direct_lake_schema_sync(datasetName, addToModel = False, workspaceName = None, lakehouseName = None, lakehouseWorkspaceName = None):

    """
    
    This function shows/adds columns which exist in the lakehouse but do not exist in the semantic model (only for tables in the semantic model).

    Parameters:

        datasetName: The semantic model name.
        addToModel: This optional boolean parameter adds columns which exist in the lakehouse but do not exist in the semantic model. No new tables are added. Default value: False.
        workspaceName: An optional parameter to set the workspace where the semantic model resides. This defaults to the
          workspace in which the notebook resides.
        lakehouseName: An optional parameter to set the lakehouse. This defaults to the lakehouse attached to the notebook.
        lakehouseWorkspaceName: An optional parameter to set the workspace in which the lakehouse exists.

    Returns:

        This function returns a printout stating the success/failure of the operation.

    Example:

        direct_lake_schema_sync(
                datasetName = 'AdventureWorks'
                ,addToModel = True
                #,workspaceName = None 
                )


    """

    from .GetLakehouseColumns import get_lakehouse_columns
    from .HelperFunctions import create_daxfullobjectname
    from .HelperFunctions import resolve_lakehouse_name

    if lakehouseWorkspaceName is None and lakehouseName is not None:
        print(f"If you specify a lakehouseName you must also specify a lakehouseWorkspaceName.")
        return
    elif lakehouseWorkspaceName is None:
        lakehouseWorkspaceName = workspaceName

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)

    if lakehouseName == None:
        lakehouseId = fabric.get_lakehouse_id()
        lakehouseName = resolve_lakehouse_name(lakehouseId, workspaceName)

    dfP = fabric.list_partitions(dataset = datasetName, workspace = workspaceName)
    dfP_filt = dfP[dfP['Source Type'] == 'Entity']
    dfC = fabric.list_columns(dataset = datasetName, workspace = workspaceName)
    dfC_filt = dfC[dfC['Table Name'].isin(dfP_filt['Table Name'].values)]
    dfC_filt = pd.merge(dfC_filt, dfP_filt[['Table Name', 'Query']], on = 'Table Name', how = 'left')
    dfC_filt['Column Object'] = create_daxfullobjectname(dfC_filt['Query'], dfC_filt['Source'])

    lc = get_lakehouse_columns(lakehouseName, lakehouseWorkspaceName)
    lc_filt = lc[lc['Table Name'].isin(dfP_filt['Query'].values)]

    mapping = {
        'string': 'String',
        'bigint': 'Int64',
        'int': 'Int64',
        'smallint': 'Int64',
        'boolean': 'Boolean',
        'timestamp': 'DateTime',
        'date': 'DateTime',
        'decimal(38,18)': 'Decimal',
        'double': 'Double'
    }

    tom_server = fabric.create_tom_server(readonly=False, workspace=workspaceName)
    m = tom_server.Databases.GetByName(datasetName).Model
    for i, r in lc_filt.iterrows():
        lakeTName = r['Table Name']
        lakeCName = r['Column Name']
        fullColName = r['Full Column Name']
        dType = r['Data Type']

        if fullColName not in dfC_filt['Column Object'].values:
            dfL = dfP_filt[dfP_filt['Query'] == lakeTName]            
            tName = dfL['Table Name'].iloc[0]
            if addToModel:
                col = TOM.DataColumn()
                col.Name = lakeCName
                col.SourceColumn = lakeCName
                dt = mapping.get(dType)
                try:
                    col.DataType = System.Enum.Parse(TOM.DataType, dt)
                except:
                    print(f"ERROR: '{dType}' data type is not mapped properly to the semantic model data types.")
                    return

                m.Tables[tName].Columns.Add(col)
                print(f"The '{lakeCName}' column has been added to the '{tName}' table as a '{dt}' data type within the '{datasetName}' semantic model within the '{workspaceName}' workspace.")
            else:
                print(f"The {fullColName} column exists in the lakehouse but not in the '{tName}' table in the '{datasetName}' semantic model within the '{workspaceName}' workspace.")
        m.SaveChanges()
