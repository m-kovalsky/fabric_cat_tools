import sempy
import sempy.fabric as fabric
import pandas as pd
import re

def direct_lake_schema_compare(datasetName, workspaceName = None, lakehouseName = None, lakehouseWorkspaceName = None):

    """
    
    This function checks that all tables/columns in a Direct Lake model exist in the lakehouse

    Parameters:

        datasetName: The semantic model name.
        workspaceName: An optional parameter to set the workspace where the semantic model resides. This defaults to the
          workspace in which the notebook resides.
        lakehouseName: An optional parameter to set the lakehouse. This defaults to the lakehouse attached to the notebook.
        lakehouseWorkspaceName: An optional parameter to set the workspace in which the lakehouse exists.

    Returns:

        This function returns 2 dataframes showing which tables/columns exist in the semantic model but do not exist
        in the lakehouse as currently mapped by their partition entity name and source column, respectively.
    """

    from .HelperFunctions import create_daxfullobjectname
    from .HelperFunctions import resolve_lakehouse_name
    from .GetLakehouseColumns import get_lakehouse_columns
    from .ListFunctions import list_tables

    if lakehouseWorkspaceName is None and lakehouseName is not None:
        print(f"If you specify a lakehouseName you must also specify a lakehouseWorkspaceName.")
        return
    elif lakehouseWorkspaceName is None:
        lakehouseWorkspaceName = workspaceName

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)

    if lakehouseName == None:
        lakehouseId = fabric.get_lakehouse_id()
        lakehouseName = resolve_lakehouse_name(lakehouseId, workspaceName)

    dfP = fabric.list_partitions(dataset = datasetName, workspace = workspaceName)
    dfE = fabric.list_expressions(dataset = datasetName, workspace = workspaceName)
    dfE_filt = dfE[dfE['Name']== 'DatabaseQuery']
    expr = dfE_filt['Expression'].iloc[0]

    matches = re.findall(r'"([^"]*)"', expr)
    sqlEndpointId = matches[1]

    dfI = fabric.list_items(workspace = lakehouseWorkspaceName)
    dfI_filt = dfI[(dfI['Type'] == 'SQLEndpoint') & (dfI['Id'] == sqlEndpointId)]

    if len(dfI_filt) == 0:
        print(f"The SQL Endpoint in the '{datasetName}' semantic model in the '{workspaceName} workspace does not point to the '{lakehouseName}' lakehouse in the '{lakehouseWorkspaceName}' workspace as specified.")
        return

    if not any(r['Mode'] == 'DirectLake' for i, r in dfP.iterrows()):
        print(f"The '{datasetName}' semantic model is not in Direct Lake mode.")
        return

    dfT = list_tables(datasetName, workspaceName)
    dfC = fabric.list_columns(dataset = datasetName, workspace = workspaceName)
    lc = get_lakehouse_columns(lakehouseName, lakehouseWorkspaceName)        
    
    dfT.rename(columns={'Type': 'Table Type'}, inplace=True)
    dfP_filt = dfP[dfP['Mode'] == 'DirectLake']
    dfC = pd.merge(dfC,dfP[['Table Name', 'Query']], on='Table Name', how='inner')
    dfC = pd.merge(dfC,dfT[['Name', 'Table Type']], left_on='Table Name', right_on='Name', how='inner')
    dfC['Full Column Name'] = create_daxfullobjectname(dfC['Query'], dfC['Source'])
    dfC_filt = dfC[dfC['Table Type'] == 'Table']
    # Schema compare
    missingtbls = dfP_filt[~dfP_filt['Query'].isin(lc['Table Name'])]
    missingtbls = missingtbls[['Table Name', 'Query']]
    missingtbls.rename(columns={'Query': 'Source Table'}, inplace=True)
    missingcols = dfC_filt[~dfC_filt['Full Column Name'].isin(lc['Full Column Name'])]
    missingcols = missingcols[['Table Name', 'Column Name', 'Type', 'Data Type', 'Source']]
    missingcols.rename(columns={'Source': 'Source Column'}, inplace=True)

    if len(missingtbls) == 0:
        print(f"All tables exist in the '{lakehouseName}' lakehouse within the '{lakehouseWorkspaceName}' workspace.")
    else:
        print(f"The following tables exist in the '{datasetName}' semantic model within the '{workspaceName}' workspace but do not exist in the '{lakehouseName}' lakehouse within the '{lakehouseWorkspaceName}' workspace.")
        display(missingtbls)
    if len(missingcols) == 0:
        print(f"All columns exist in the '{lakehouseName}' lakehouse within the '{lakehouseWorkspaceName}' workspace.")
    else:
        print(f"The following columns exist in the '{datasetName}' semantic model within the '{workspaceName}' workspace but do not exist in the '{lakehouseName}' lakehouse within the '{lakehouseWorkspaceName}' workspace.")
        display(missingcols)
        