import sempy
import sempy.fabric as fabric
import pandas as pd

def remove_measure(datasetName, measureName, workspaceName = None):

    """

    This function removes measure(s) from a semantic model

    Parameters:

        datasetName: The name of the semantic model.        
        measureName: The name of the measure(s) to be removed. Can be a single measure name or an array of measure names.
        workspaceName: An optional parameter to set the workspace in which the semantic model resides. This defaults to the workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of the operation.

    Examples:

        remove_measure(
            datasetName = 'AdventureWorks'
            ,measureName = 'Sales Amount' 
            #,workspaceName = '' 
            )

        remove_measure(
            datasetName = 'AdventureWorks'
            ,measureName = ['Sales Amount', 'Order Quantity']
            #,workspaceName = '' 
            )
    """

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)

    if isinstance(measureName, str):
        measureName = [measureName]

    dfM = fabric.list_measures(dataset = datasetName, workspace = workspaceName)
    dfM_filt = dfM[dfM['Measure Name'].isin(measureName)]        

    # Check if no measures validate:
    if len(dfM_filt) == 0:
        print(f"ERROR: The '{measureName}' measure(s) do not exist in the '{datasetName}' semantic model in the '{workspaceName}' workspace.")
        return
    
    # Print out invalid measures
    for m in measureName:
        if m not in dfM['Measure Name'].values:
            print(f"ERROR: The '{m}' measure does not exist in the '{datasetName}' semantic model in the '{workspaceName}' workspace.")

    tom_server = fabric.create_tom_server(readonly=False, workspace=workspaceName)
    m = tom_server.Databases.GetByName(datasetName).Model

    # Remove validated measures
    for i, r in dfM_filt.iterrows():
        tName = r['Table Name']
        mName = r['Measure Name']

        try:
            m.Tables[tName].Measures.Remove(mName)
            print(f"The '{mName}' measure has been removed from the '{datasetName}' semantic model in the '{workspaceName}' workspace.")
        except:
            print(f"ERROR: The '{mName}' measure has not been removed from the '{datasetName}' semantic model in the '{workspaceName}' workspace.")

    m.SaveChanges()

def remove_table(datasetName, tableName, workspaceName = None):

    """

    This function removes table(s) from a semantic model

    Parameters:

        datasetName: The name of the semantic model.        
        tableName: The name of the table(s) to be removed. Can be a single table name or an array of table names.
        workspaceName: An optional parameter to set the workspace in which the semantic model resides. This defaults to the workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of the operation.

    Examples:

        remove_table(
            datasetName = 'AdventureWorks'
            ,tableName = 'Internet Sales' 
            #,workspaceName = '' 
            )

        remove_table(
            datasetName = 'AdventureWorks'
            ,tableName = ['Internet Sales', 'Geography']
            #,workspaceName = '' 
            )
    """

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)

    if isinstance(tableName, str):
        tableName = [tableName]

    dfT = fabric.list_tables(dataset = datasetName, workspace = workspaceName)
    dfT_filt = dfT[dfT['Name'].isin(tableName)]

    # Check if no tables validate:
    if len(dfT_filt) == 0:
        print(f"The '{tableName}' table(s) do not exist in the '{datasetName}' semantic model in the '{workspaceName}' workspace.")
        return
    
    # Print out invalid tables
    for m in tableName:
        if m not in dfT['Name'].values:
            print(f"The '{m}' table does not exist in the '{datasetName}' semantic model in the '{workspaceName}' workspace.")
    
    tom_server = fabric.create_tom_server(readonly=False, workspace=workspaceName)
    m = tom_server.Databases.GetByName(datasetName).Model

    # Remove validated tables
    for i, r in dfT_filt.iterrows():
        tName = r['Name']

        try:
            m.Tables.Remove(tName)
            print(f"The '{tName}' table has been removed from the '{datasetName}' semantic model in the '{workspaceName}' workspace.")
        except:
            print(f"ERROR: The '{tName}' table has not been removed from the '{datasetName}' semantic model in the '{workspaceName}' workspace.")

    m.SaveChanges()

def remove_column(datasetName, tableName, columnName, workspaceName = None):

    """

    This function removes column(s) from a semantic model

    Parameters:

        datasetName: The name of the semantic model.        
        tableName: The name of the column's table. See the examples below.
        columnName: The name of the column(s) to be removed. Can be a single column name or an array of column names. See the examples below.
        workspaceName: An optional parameter to set the workspace in which the semantic model resides. This defaults to the workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of the operation.

    Examples:

        remove_column(
            datasetName = 'AdventureWorks'
            ,tableName = 'Internet Sales'
            ,columnName = 'SalesAmount'
            #,workspaceName = '' 
            )

        remove_column(
            datasetName = 'AdventureWorks'
            ,tableName = ['Internet Sales', 'Geography']
            ,columnName = ['SalesAmount', 'GeographyKey']
            #,workspaceName = '' 
            )
    """

    from .HelperFunctions import create_daxfullobjectname

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)

    # Support both str & list types
    if isinstance(tableName, str):
        tableName = [tableName]
    if isinstance(columnName, str):
        columnName = [columnName]
    
    if len(tableName) != len(columnName):
        print(f"ERROR: The 'tableName' and 'columnName' arrays must be of equal length.")
        return
    
    tblcol = pd.DataFrame({
        'Table Name': tableName,
        'Column Name': columnName
    })
    tblcol['Column Object'] = create_daxfullobjectname(tblcol['Table Name'], tblcol['Column Name'])

    dfC = fabric.list_columns(dataset = datasetName, workspace = workspaceName)
    dfC['Column Object'] = create_daxfullobjectname(dfC['Table Name'], dfC['Column Name'])    
    dfC_filt = dfC[dfC['Column Object'].isin(tblcol['Column Object'].values)]

    # Check if no columns validate:
    if len(dfC_filt) == 0:
        print(f"ERROR: The columns submitted do not exist in the '{datasetName}' semantic model in the '{workspaceName}' workspace.")
        return
    
    # Print out invalid columns
    for i,r in tblcol.iterrows():
        colobj = r['Column Object']
        if colobj not in dfC['Column Object'].values:
            print(f"ERROR: The {colobj} column does not exist in the '{datasetName}' semantic model in the '{workspaceName}' workspace.")
    
    tom_server = fabric.create_tom_server(readonly=False, workspace=workspaceName)
    m = tom_server.Databases.GetByName(datasetName).Model

    # Remove validated columns
    for i, r in dfC_filt.iterrows():
        tName = r['Table Name']
        oName = r['Column Name']
        coName = r['Column Object']

        try:
            m.Tables[tName].Columns.Remove(oName)
            print(f"The {coName}'column has been removed from the '{datasetName}' semantic model in the '{workspaceName}' workspace.")
        except:
            print(f"ERROR: The {coName} column has not been removed from the '{datasetName}' semantic model in the '{workspaceName}' workspace.")

    m.SaveChanges()