import sempy
import sempy.fabric as fabric
import pandas as pd
from IPython.display import display, HTML
import warnings

def vertipaq_analyzer(datasetName, workspaceName = None):
    
    """
    
    This function extracts the vertipaq analyzer statistics from a semantic model.

    Parameters:

        datasetName: The name of the semantic model.        
        workspaceName: An optional parameter to set the workspace in which the semantic model resides. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a visual showing the vertipaq analyzer statistics.

    Example:

    vertipaq_analyzer(
        datasetName = 'AdventureWorks'
        #,workspaceName = '' 
        )
    """

    from .HelperFunctions import create_daxfullobjectname

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)

    dfT = fabric.list_tables(dataset = datasetName,extended=True, workspace = workspaceName)
    dfC = fabric.list_columns(dataset = datasetName,extended=True, workspace = workspaceName)
    dfC['Column Object'] = create_daxfullobjectname(dfC['Table Name'], dfC['Column Name'])
    dfH = fabric.list_hierarchies(dataset = datasetName,extended=True, workspace = workspaceName)
    dfR = fabric.list_relationships(dataset = datasetName,extended=True, workspace = workspaceName)
    dfP = fabric.list_partitions(dataset = datasetName,extended=True, workspace = workspaceName)
    dfD = fabric.list_datasets(workspace = workspaceName, additional_xmla_properties=['CompatibilityLevel','Model.DefaultMode'])
    dfD = dfD[dfD['Dataset Name'] == datasetName]

    total_size = dfC['Total Size'].sum()
    table_sizes = dfC.groupby('Table Name')['Total Size'].sum().reset_index()
    table_sizes.rename(columns={'Total Size': 'Table Size'}, inplace=True)

    ## Column views (need to add cardinality)
    dfC_filt = dfC[~dfC['Column Name'].str.startswith('RowNumber-')]
    dfC_filt['% DB'] = round((dfC_filt['Total Size'] / total_size) * 100,2)
    dfC_filt = pd.merge(dfC_filt, table_sizes, on = 'Table Name', how = 'left')
    dfC_filt['% Table'] = round((dfC_filt['Total Size'] / dfC_filt['Table Size']) * 100,2)
    columnList = ['Table Name', 'Column Name', 'Type', 'Column Cardinality', 'Total Size', 'Data Size', 'Dictionary Size', 'Hierarchy Size','% Table', '% DB', 'Data Type', 'Encoding', 'Is Resident', 'Temperature', 'Last Accessed']

    colSize = dfC_filt[columnList].sort_values(by='Total Size', ascending=False)
    temp = dfC_filt[columnList].sort_values(by='Temperature', ascending=False)

    # Format
    intList = ['Column Cardinality', 'Total Size', 'Data Size', 'Dictionary Size', 'Hierarchy Size']
    pctList = ['% Table', '% DB']
    colSize[intList] = colSize[intList].applymap('{:,}'.format)
    temp[intList] = temp[intList].applymap('{:,}'.format)
    colSize[pctList] = colSize[pctList].applymap('{:.2f}%'.format)
    temp[pctList] = temp[pctList].applymap('{:.2f}%'.format)

    # Table views
    intList = ['Total Size', 'Data Size', 'Dictionary Size', 'Hierarchy Size']
    dfCSum = dfC.groupby(['Table Name'])[intList].sum().reset_index()
    dfCSum['% DB'] = round((dfCSum['Total Size'] / total_size) * 100,2)

    # Merge
    df = pd.merge(dfT[['Name', 'Type', 'Row Count']], dfCSum, left_on = 'Name', right_on = 'Table Name', how = 'inner')
    # Drop duplicates (temporary)
    df = df.drop_duplicates()

    # Select columns sort
    df = df[['Table Name', 'Type', 'Row Count', 'Total Size', 'Data Size', 'Dictionary Size', 'Hierarchy Size', '% DB']].sort_values(by='Total Size', ascending=False)
    #df = df.style.bar(subset=['Row Count'], color='#5F94F3')

    # Format
    intList.append('Row Count')
    df[intList] = df[intList].applymap('{:,}'.format)
    pctList = ['% DB']
    df[pctList] = df[pctList].applymap('{:.2f}%'.format)
    df

    ## Relationship view (need cardinality)
    dfR['From Object'] = create_daxfullobjectname(dfR['From Table'], dfR['From Column'])
    dfR['To Object'] = create_daxfullobjectname(dfR['To Table'], dfR['To Column'])

    dfR = pd.merge(dfR, dfC[['Column Object', 'Column Cardinality']], left_on = 'From Object', right_on = 'Column Object', how = 'left')
    dfR.rename(columns={'Column Cardinality': 'Max From Cardinality'}, inplace=True)
    dfR = pd.merge(dfR, dfC[['Column Object', 'Column Cardinality']], left_on = 'To Object', right_on = 'Column Object', how='left')
    dfR.rename(columns={'Column Cardinality': 'Max To Cardinality'}, inplace=True)
    dfR = dfR[['From Object', 'To Object', 'Used Size', 'Max From Cardinality', 'Max To Cardinality']].sort_values(by='Used Size', ascending=False)
    intList = ['Used Size', 'Max From Cardinality', 'Max To Cardinality']
    dfR[intList] = dfR[intList].applymap('{:,}'.format)

    ## Partition view (need to fix Records per Segment)
    dfP = dfP[['Table Name', 'Partition Name', 'Mode', 'Record Count', 'Segment Count']].sort_values(by='Record Count', ascending=False) #, 'Records per Segment'
    dfP['Records per Segment'] = round(dfP['Record Count'] / dfP['Segment Count'],2) # Remove after records per segment is fixed
    intList = ['Record Count', 'Segment Count', 'Records per Segment']
    dfP[intList] = dfP[intList].applymap('{:,}'.format)

    ## Hierarchy view
    dfH_filt = dfH[dfH['Level Ordinal'] == 0]
    dfH_filt = dfH_filt[['Table Name', 'Hierarchy Name', 'Used Size']].sort_values(by='Used Size', ascending=False)
    intList = ['Used Size']
    dfH_filt[intList] = dfH_filt[intList].applymap('{:,}'.format)

    ## Model (summary) view 
    if total_size >= 1000000000:
        y = total_size / (1024 ** 3) * 1000000000
    elif total_size >= 1000000:
        y = total_size / (1024 ** 2) * 1000000
    elif total_size >= 1000:
        y = total_size / (1024) * 1000
    y = round(y)

    tblCount = len(dfT)
    colCount = len(dfC_filt)
    compatLevel = dfD['Compatibility Level'].iloc[0]
    defMode = dfD['Model Default Mode'].iloc[0]

    dfCSumNoGroup = pd.DataFrame({'Dataset Name': datasetName, 'Total Size': y, 'Table Count': tblCount, 'Column Count': colCount, 'Compatibility Level': compatLevel, 'Default Mode': defMode}, index=[0])
    intList = ['Total Size', 'Table Count', 'Column Count']
    dfCSumNoGroup[intList] = dfCSumNoGroup[intList].applymap('{:,}'.format)    

    #define the dictionary with {"Tab name":df}
    df_dict = {
        "Model Summary":dfCSumNoGroup,
        "Tables":df,
        "Partitions": dfP,
        "Columns (Total Size)": colSize,
        "Columns (Temperature)": temp,
        "Relationships": dfR,
        "Hierarchies": dfH_filt
            }    

    # Basic styles for the tabs and tab content
    styles = """
    <style>
        .tab { overflow: hidden; border: 1px solid #ccc; background-color: #f1f1f1; }
        .tab button { background-color: inherit; float: left; border: none; outline: none; cursor: pointer; padding: 14px 16px; transition: 0.3s; }
        .tab button:hover { background-color: #ddd; }
        .tab button.active { background-color: #ccc; }
        .tabcontent { display: none; padding: 6px 12px; border: 1px solid #ccc; border-top: none; }
    </style>
    """
    # JavaScript for tab functionality
    script = """
    <script>
    function openTab(evt, tabName) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(tabName).style.display = "block";
        evt.currentTarget.className += " active";
    }
    </script>
    """
    # HTML for tabs
    tab_html = '<div class="tab">'
    content_html = ''
    for i, (title, df) in enumerate(df_dict.items()):
        tab_id = f"tab{i}"
        tab_html += f'<button class="tablinks" onclick="openTab(event, \'{tab_id}\')">{title}</button>'
        content_html += f'<div id="{tab_id}" class="tabcontent"><h3>{title}</h3>{df.to_html()}</div>'
    tab_html += '</div>'

    # Display the tabs, tab contents, and run the script
    display(HTML(styles + tab_html + content_html + script))
    # Default to open the first tab
    display(HTML("<script>document.getElementsByClassName('tablinks')[0].click();</script>"))