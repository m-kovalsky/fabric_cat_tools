import sempy
import sempy.fabric as fabric
import pandas as pd
from IPython.display import display, HTML
import zipfile
import os
from notebookutils import mssparkutils
from pyspark.sql import SparkSession
import shutil

def vertipaq_analyzer(datasetName, workspaceName = None, export = None):
    
    """
    
    This function extracts the vertipaq analyzer statistics from a semantic model.

    Parameters:

        datasetName: The name of the semantic model.        
        workspaceName: An optional parameter to set the workspace in which the semantic model resides. This defaults to the
          workspace in which the notebook resides.
        export: Setting this to 'zip' will export the contents to a .zip file which can be imported using the import_vertipaq_analyzer function.
            Setting this to 'table' will export the contents to delta tables in the format 'VertipaqAnalyzer_' + workspaceName + '_' + datasetName.
            Default value: None

    Returns:

        This function returns a visual showing the vertipaq analyzer statistics.

    Example:

        vertipaq_analyzer(
            datasetName = 'AdventureWorks'
            #,workspaceName = ''
            ,export = None
            )
    
        vertipaq_analyzer(
            datasetName = 'AdventureWorks'
            #,workspaceName = ''
            ,export = 'zip'
            )

        vertipaq_analyzer(
            datasetName = 'AdventureWorks'
            #,workspaceName = ''
            ,export = 'table'
            )
    """

    from .HelperFunctions import create_daxfullobjectname

    pd.options.mode.copy_on_write = True

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)

    dfT = fabric.list_tables(dataset = datasetName,extended=True, workspace = workspaceName)
    dfC = fabric.list_columns(dataset = datasetName,extended=True, workspace = workspaceName)
    dfC['Column Object'] = create_daxfullobjectname(dfC['Table Name'], dfC['Column Name'])
    dfC.rename(columns={'Column Cardinality': 'Cardinality'}, inplace=True)
    dfH = fabric.list_hierarchies(dataset = datasetName,extended=True, workspace = workspaceName)
    dfR = fabric.list_relationships(dataset = datasetName,extended=True, workspace = workspaceName)
    dfP = fabric.list_partitions(dataset = datasetName,extended=True, workspace = workspaceName)
    dfD = fabric.list_datasets(workspace = workspaceName, additional_xmla_properties=['CompatibilityLevel','Model.DefaultMode'])
    dfD = dfD[dfD['Dataset Name'] == datasetName]

    dfD['Compatibility Level'] = dfD['Compatibility Level'].astype(int)

    total_size = dfC['Total Size'].sum()
    table_sizes = dfC.groupby('Table Name')['Total Size'].sum().reset_index()
    table_sizes.rename(columns={'Total Size': 'Table Size'}, inplace=True)

    # Columns
    dfC_filt = dfC[~dfC['Column Name'].str.startswith('RowNumber-')]
    dfC_filt['% DB'] = round((dfC_filt['Total Size'] / total_size) * 100,2)
    dfC_filt = pd.merge(dfC_filt, table_sizes, on = 'Table Name', how = 'left')
    dfC_filt['% Table'] = round((dfC_filt['Total Size'] / dfC_filt['Table Size']) * 100,2)
    columnList = ['Table Name', 'Column Name', 'Type', 'Cardinality', 'Total Size', 'Data Size', 'Dictionary Size', 'Hierarchy Size','% Table', '% DB', 'Data Type', 'Encoding', 'Is Resident', 'Temperature', 'Last Accessed']

    colSize = dfC_filt[columnList].sort_values(by='Total Size', ascending=False)
    temp = dfC_filt[columnList].sort_values(by='Temperature', ascending=False)
    colSize.reset_index(drop=True, inplace=True)
    temp.reset_index(drop=True, inplace=True)

    export_Col = colSize    

    intList = ['Cardinality', 'Total Size', 'Data Size', 'Dictionary Size', 'Hierarchy Size']
    pctList = ['% Table', '% DB']
    colSize[intList] = colSize[intList].applymap('{:,}'.format)
    temp[intList] = temp[intList].applymap('{:,}'.format)
    colSize[pctList] = colSize[pctList].applymap('{:.2f}%'.format)
    temp[pctList] = temp[pctList].applymap('{:.2f}%'.format)

    # Tables
    intList = ['Total Size', 'Data Size', 'Dictionary Size', 'Hierarchy Size']
    dfCSum = dfC.groupby(['Table Name'])[intList].sum().reset_index()
    dfCSum['% DB'] = round((dfCSum['Total Size'] / total_size) * 100,2)

    dfTable = pd.merge(dfT[['Name', 'Type', 'Row Count']], dfCSum, left_on = 'Name', right_on = 'Table Name', how = 'inner')
    dfTable = dfTable.drop_duplicates() #Drop duplicates (temporary)

    dfTable = dfTable[['Table Name', 'Type', 'Row Count', 'Total Size', 'Data Size', 'Dictionary Size', 'Hierarchy Size', '% DB']].sort_values(by='Total Size', ascending=False)    
    export_Table = dfTable

    intList.append('Row Count')
    dfTable[intList] = dfTable[intList].applymap('{:,}'.format)
    pctList = ['% DB']
    dfTable[pctList] = dfTable[pctList].applymap('{:.2f}%'.format)
    dfTable
    dfTable.reset_index(drop=True, inplace=True)

    ## Relationships
    dfR['From Object'] = create_daxfullobjectname(dfR['From Table'], dfR['From Column'])
    dfR['To Object'] = create_daxfullobjectname(dfR['To Table'], dfR['To Column'])
    #dfR = pd.merge(dfR, dfC[['Column Object', 'Cardinality']], left_on = 'From Object', right_on = 'Column Object', how = 'left')
    #dfR.rename(columns={'Cardinality': 'Max From Cardinality'}, inplace=True)
    #dfR = pd.merge(dfR, dfC[['Column Object', 'Cardinality']], left_on = 'To Object', right_on = 'Column Object', how='left')
    #dfR.rename(columns={'Cardinality': 'Max To Cardinality'}, inplace=True)
    dfR = dfR[['From Object', 'To Object', 'Used Size', 'Max From Cardinality', 'Max To Cardinality']].sort_values(by='Used Size', ascending=False)
    dfR.reset_index(drop=True, inplace=True)
    export_Rel = dfR
    intList = ['Used Size', 'Max From Cardinality', 'Max To Cardinality']
    dfR[intList] = dfR[intList].applymap('{:,}'.format)

    ## Partitions
    dfP = dfP[['Table Name', 'Partition Name', 'Mode', 'Record Count', 'Segment Count']].sort_values(by='Record Count', ascending=False) #, 'Records per Segment'
    dfP['Records per Segment'] = round(dfP['Record Count'] / dfP['Segment Count'],2) # Remove after records per segment is fixed
    dfP.reset_index(drop=True, inplace=True)
    export_Part = dfP
    intList = ['Record Count', 'Segment Count', 'Records per Segment']
    dfP[intList] = dfP[intList].applymap('{:,}'.format)

    ## Hierarchies
    dfH_filt = dfH[dfH['Level Ordinal'] == 0]
    dfH_filt = dfH_filt[['Table Name', 'Hierarchy Name', 'Used Size']].sort_values(by='Used Size', ascending=False)
    dfH_filt.reset_index(drop=True, inplace=True)
    export_Hier = dfH_filt
    intList = ['Used Size']
    dfH_filt[intList] = dfH_filt[intList].applymap('{:,}'.format)

    ## Model
    if total_size >= 1000000000:
        y = total_size / (1024 ** 3) * 1000000000
    elif total_size >= 1000000:
        y = total_size / (1024 ** 2) * 1000000
    elif total_size >= 1000:
        y = total_size / (1024) * 1000
    y = round(y)

    tblCount = len(dfT)
    colCount = len(dfC_filt)
    compatLevel = dfD['Compatibility Level'].iloc[0]
    defMode = dfD['Model Default Mode'].iloc[0]

    dfModel = pd.DataFrame({'Dataset Name': datasetName, 'Total Size': y, 'Table Count': tblCount, 'Column Count': colCount, 'Compatibility Level': compatLevel, 'Default Mode': defMode}, index=[0])
    dfModel.reset_index(drop=True, inplace=True)
    export_Model = dfModel
    intList = ['Total Size', 'Table Count', 'Column Count']
    dfModel[intList] = dfModel[intList].applymap('{:,}'.format)

    dataFrames = {
        'dfModel': dfModel,
        'dfTable': dfTable,
        'dfP': dfP,
        'colSize': colSize,
        'temp': temp,
        'dfR': dfR,
        'dfH_filt': dfH_filt
    }

    dfs = {}
    for fileName, df in dataFrames.items():
        dfs[fileName] = df
      
    visualize_vertipaq(dfs)

    ### Export vertipaq to delta tables in lakehouse
    if export == 'table':
       dName = datasetName.replace(' ','_')
       wName = workspaceName.replace(' ','_')
       spark = SparkSession.builder.getOrCreate()

       dfMap = {
        'export_Col': ['Columns', export_Col],
        'export_Table': ['Tables', export_Table],
        'export_Part': ['Partition', export_Part],
        'export_Rel': ['Relationships', export_Rel],
        'export_Hier': ['Hierarchies', export_Hier],
        'export_Model': ['Model', export_Model]
        }
       
       print(f"Saving Vertipaq Analyzer to delta tables in the lakehouse...\n")
       for key, (obj, df) in dfMap.items():
        df['Timestamp'] = pd.Timestamp.now()
        df.columns = df.columns.str.replace(' ', '_')        

        delta_table_name = f"VertipaqAnalyzer_{wName}_{dName}_{obj}".lower()
        spark_df = spark.createDataFrame(df)
        spark_df.write.mode('append').format('delta').saveAsTable(delta_table_name)
        print(f"\u2022 Vertipaq Analyzer results for '{obj}' have been appended to the '{delta_table_name}' delta table.")    

    ### Export vertipaq to zip file within the lakehouse
    if export == 'zip':
      # Check that lakehouse is attached to the notebook
      mounts = pd.DataFrame(mssparkutils.fs.mounts())
      mounts_filt = mounts[mounts['storageType'] == 'Lakehouse']

      # Run if lakehouse is attached to the notebook or a lakehouse & lakehouse workspace are specified
      if len(mounts_filt) < 1:
        print('A lakehouse must be attached to notebook in order to export the vertipaq analyer information.')
        return
      
      dataFrames = {
        'dfModel': dfModel,
        'dfTable': dfTable,
        'dfP': dfP,
        'colSize': colSize,
        'temp': temp,
        'dfR': dfR,
        'dfH_filt': dfH_filt
    }
      
      zipFileName = f"{workspaceName}.{datasetName}.zip"

      folderPath = '/lakehouse/default/Files'
      subFolderPath = os.path.join(folderPath, 'VertipaqAnalyzer')
      ext = '.csv'
      if not os.path.exists(subFolderPath):
        os.makedirs(subFolderPath, exist_ok=True)
      zipFilePath = os.path.join(subFolderPath, zipFileName)

      # Create CSV files based on dataframes
      for fileName, df in dataFrames.items():
        filePath = os.path.join(subFolderPath, fileName + ext)
        df.to_csv(filePath, index=False)

      # Create a zip file and add CSV files to it
      with zipfile.ZipFile(zipFilePath, 'w') as zipf:
          for fileName in dataFrames:
               filePath = os.path.join(subFolderPath, fileName + ext)
               zipf.write(filePath, os.path.basename(filePath))

      # Clean up: remove the individual CSV files
      for fileName, df in dataFrames.items():
          filePath = os.path.join(subFolderPath, fileName) + ext
          if os.path.exists(filePath):
             os.remove(filePath)
      print(f"The Vertipaq Analyzer info for the '{datasetName}' semantic model in the '{workspaceName}' workspace has been saved to the 'Vertipaq Analyzer\{zipFileName}' in the default lakehouse attached to this notebook.")

def visualize_vertipaq(dataframes):
    
    # Tooltips for columns within the visual
    data = [
        {'ViewName': 'Model', 'ColumnName': 'Dataset Name', 'Tooltip': 'The name of the semantic model'},
        {'ViewName': 'Model', 'ColumnName': 'Total Size', 'Tooltip': 'The size of the model (in bytes)'},
        {'ViewName': 'Model', 'ColumnName': 'Table Count', 'Tooltip': 'The number of tables in the semantic model'},
        {'ViewName': 'Model', 'ColumnName': 'Column Count', 'Tooltip': 'The number of columns in the semantic model'},
        {'ViewName': 'Model', 'ColumnName': 'Compatibility Level', 'Tooltip': 'The compatibility level of the semantic model'},
        {'ViewName': 'Model', 'ColumnName': 'Default Mode', 'Tooltip': 'The default query mode of the semantic model'},
        {'ViewName': 'Table', 'ColumnName': 'Table Name', 'Tooltip': 'The name of the table'},
        {'ViewName': 'Table', 'ColumnName': 'Type', 'Tooltip': 'The type of table'},
        {'ViewName': 'Table', 'ColumnName': 'Row Count', 'Tooltip': 'The number of rows in the table'},
        {'ViewName': 'Table', 'ColumnName': 'Total Size', 'Tooltip': 'Data Size + Dictionary Size + Hierarchy Size (in bytes)'},
        {'ViewName': 'Table', 'ColumnName': 'Data Size', 'Tooltip': 'The size of the data for all the columns in this table (in bytes)'},
        {'ViewName': 'Table', 'ColumnName': 'Dictionary Size', 'Tooltip': "The size of the column's dictionary for all columns in this table (in bytes)"},
        {'ViewName': 'Table', 'ColumnName': 'Hierarchy Size', 'Tooltip': 'The size of hierarchy structures for all columns in this table (in bytes)'},
        {'ViewName': 'Table', 'ColumnName': '% DB', 'Tooltip': 'The size of the table relative to the size of the semantic model'},
        {'ViewName': 'Partition', 'ColumnName': 'Table Name', 'Tooltip': 'The name of the table'},
        {'ViewName': 'Partition', 'ColumnName': 'Partition Name', 'Tooltip': 'The name of the partition within the table'},
        {'ViewName': 'Partition', 'ColumnName': 'Mode', 'Tooltip': 'The query mode of the partition'},
        {'ViewName': 'Partition', 'ColumnName': 'Record Count', 'Tooltip': 'The number of rows in the partition'},
        {'ViewName': 'Partition', 'ColumnName': 'Segment Count', 'Tooltip': 'The number of segments within the partition'},
        {'ViewName': 'Partition', 'ColumnName': 'Records per Segment', 'Tooltip': 'The number of rows per segment'},
        {'ViewName': 'Column', 'ColumnName': 'Table Name', 'Tooltip': 'The name of the table'},
        {'ViewName': 'Column', 'ColumnName': 'Column Name', 'Tooltip': 'The name of the column'},
        {'ViewName': 'Column', 'ColumnName': 'Type', 'Tooltip': 'The type of column'},
        {'ViewName': 'Column', 'ColumnName': 'Cardinality', 'Tooltip': 'The number of unique rows in the column'},
        {'ViewName': 'Column', 'ColumnName': 'Total Size', 'Tooltip': 'Data Size + Dictionary Size + Hierarchy Size (in bytes)'},
        {'ViewName': 'Column', 'ColumnName': 'Data Size', 'Tooltip': 'The size of the data for the column (in bytes)'},
        {'ViewName': 'Column', 'ColumnName': 'Dictionary Size', 'Tooltip': "The size of the column's dictionary (in bytes)"},
        {'ViewName': 'Column', 'ColumnName': 'Hierarchy Size', 'Tooltip': 'The size of hierarchy structures (in bytes)'},
        {'ViewName': 'Column', 'ColumnName': '% Table', 'Tooltip': 'The size of the column relative to the size of the table'},
        {'ViewName': 'Column', 'ColumnName': '% DB', 'Tooltip': 'The size of the column relative to the size of the semantic model'},
        {'ViewName': 'Column', 'ColumnName': 'Data Type', 'Tooltip': 'The data type of the column'},
        {'ViewName': 'Column', 'ColumnName': 'Encoding', 'Tooltip': 'The encoding type for the column'},
        {'ViewName': 'Column', 'ColumnName': 'Is Resident', 'Tooltip': 'Indicates whether the column is in memory or not'},
        {'ViewName': 'Column', 'ColumnName': 'Temperature', 'Tooltip': 'A decimal indicating the frequency and recency of queries against the column'},
        {'ViewName': 'Column', 'ColumnName': 'Last Accessed', 'Tooltip': 'The time the column was last queried'},
        {'ViewName': 'Hierarchy', 'ColumnName': 'Table Name', 'Tooltip': 'The name of the table'},
        {'ViewName': 'Hierarchy', 'ColumnName': 'Hierarchy Name', 'Tooltip': 'The name of the hierarchy'},
        {'ViewName': 'Hierarchy', 'ColumnName': 'Used Size', 'Tooltip': 'The size of user hierarchy structures (in bytes)'},
        {'ViewName': 'Relationship', 'ColumnName': 'From Object', 'Tooltip': 'The from table/column in the relationship'},
        {'ViewName': 'Relationship', 'ColumnName': 'To Object', 'Tooltip': 'The to table/column in the relationship'},
        {'ViewName': 'Relationship', 'ColumnName': 'Used Size', 'Tooltip': 'The size of the relationship (in bytes)'},
        {'ViewName': 'Relationship', 'ColumnName': 'Max From Cardinality', 'Tooltip': 'The number of unique values in the column used in the from side of the relationship'},
        {'ViewName': 'Relationship', 'ColumnName': 'Max To Cardinality', 'Tooltip': 'The number of unique values in the column used in the to side of the relationship'}
    ]

    # Create DataFrame
    tooltipDF = pd.DataFrame(data)

    #define the dictionary with {"Tab name":df}
    df_dict = {
        "Model Summary":dataframes['dfModel'],
        "Tables":dataframes['dfTable'],
        "Partitions": dataframes['dfP'],
        "Columns (Total Size)": dataframes['colSize'],
        "Columns (Temperature)": dataframes['temp'],
        "Relationships": dataframes['dfR'],
        "Hierarchies": dataframes['dfH_filt']
            }

    mapping = {
    'Model Summary': 'Model',
    'Tables': 'Table',
    'Partitions': 'Partition',
    'Columns (Total Size)': 'Column',
    'Columns (Temperature)': 'Column',
    'Relationships': 'Relationship',
    'Hierarchies': 'Hierarchy'
}

    # Basic styles for the tabs and tab content
    styles = """
    <style>
        .tab { overflow: hidden; border: 1px solid #ccc; background-color: #f1f1f1; }
        .tab button { background-color: inherit; float: left; border: none; outline: none; cursor: pointer; padding: 14px 16px; transition: 0.3s; }
        .tab button:hover { background-color: #ddd; }
        .tab button.active { background-color: #ccc; }
        .tabcontent { display: none; padding: 6px 12px; border: 1px solid #ccc; border-top: none; }
    </style>
    """
    # JavaScript for tab functionality
    script = """
    <script>
    function openTab(evt, tabName) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(tabName).style.display = "block";
        evt.currentTarget.className += " active";
    }
    </script>
    """
    # HTML for tabs
    tab_html = '<div class="tab">'
    content_html = ''
    for i, (title, df) in enumerate(df_dict.items()):
        tab_id = f"tab{i}"
        tab_html += f'<button class="tablinks" onclick="openTab(event, \'{tab_id}\')">{title}</button>'

        vw = mapping.get(title)

        df_html = df.to_html()
        for col in df.columns:
            tt = None
            try:
                tooltipDF_filt = tooltipDF[(tooltipDF['ViewName'] == vw) & (tooltipDF['ColumnName'] == col)]
                tt = tooltipDF_filt['Tooltip'].iloc[0]
            except:
                pass
            df_html = df_html.replace(f'<th>{col}</th>', f'<th title="{tt}">{col}</th>')
        content_html += f'<div id="{tab_id}" class="tabcontent"><h3>{title}</h3>{df_html}</div>'
    tab_html += '</div>'

    # Display the tabs, tab contents, and run the script
    display(HTML(styles + tab_html + content_html + script))
    # Default to open the first tab
    display(HTML("<script>document.getElementsByClassName('tablinks')[0].click();</script>"))

def import_vertipaq_analyzer(folderPath, fileName):

  """
    
    This function imports and visualizes the vertipaq analyzer info from a saved .zip file in your lakehouse.

    Parameters:

        folderPath: The folder within your lakehouse in which the .zip file containing the vertipaq analyzer info has been saved.
        fileName:  The file name of the file which contains the vertipaq analyzer info.

    Returns:

        This function returns a visual showing the vertipaq analyzer statistics.

    Example:

      import_vertipaq_analyzer(
          folderPath = '/lakehouse/default/Files/VertipaqAnalyzer'
          ,fileName = 'Workspace Name-DatasetName.zip'
          )
    """
  
  pd.options.mode.copy_on_write = True

  zipFilePath = os.path.join(folderPath, fileName)
  extracted_dir = os.path.join(folderPath, 'extracted_dataframes')

  with zipfile.ZipFile(zipFilePath, 'r') as zip_ref:
      zip_ref.extractall(extracted_dir)

  # Read all CSV files into a dictionary of DataFrames
  dfs = {}
  for file_name in zip_ref.namelist():
      df = pd.read_csv(extracted_dir + '/' + file_name)
      dfs[file_name] = df

  visualize_vertipaq(dfs)

  # Clean up: remove the extracted directory
  shutil.rmtree(extracted_dir)