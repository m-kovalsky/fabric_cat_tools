import sempy
import sempy.fabric as fabric
import pandas as pd

def get_lakehouse_tables(lakehouseName = None, workspaceName = None):

    """
    
    This function outputs a dataframe containing a list of tables in a lakehouse.

    Parameters:
        
        lakehouseName: An optional parameter to set the lakehouse. This defaults to the lakehouse attached to the notebook.
        workspaceName: An optional parameter to indicate the workspace in which the lakehouse resides.

    Returns:

        This function returns a pandas dataframe with the following columns:

            Lakehouse Name
            Table Name
            Format
            Type
            Location
            
    """

    from .HelperFunctions import resolve_lakehouse_id
    from .HelperFunctions import resolve_lakehouse_name

    df = pd.DataFrame(columns=['Lakehouse Name', 'Table Name', 'Format', 'Type', 'Location'])

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)

    if lakehouseName == None:
        lakehouseId = fabric.get_lakehouse_id()
        lakehouseName = resolve_lakehouse_name(lakehouseId)
    else:
        lakehouseId = resolve_lakehouse_id(lakehouseName, workspaceName)   

    client = fabric.FabricRestClient()
    response = client.get(f"/v1/workspaces/{workspaceId}/lakehouses/{lakehouseId}/tables")

    for i in response.json()['data']:
        new_data = {'Lakehouse Name': lakehouseName, 'Table Name': i['name'], 'Format': i['format'], 'Type': i['type'], 'Location': i['location'] }
        df = pd.concat([df, pd.DataFrame(new_data, index=[0])], ignore_index=True)

    return df
 
    