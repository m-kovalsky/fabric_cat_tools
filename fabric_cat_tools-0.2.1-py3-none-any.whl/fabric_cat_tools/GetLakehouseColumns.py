import sempy
import sempy.fabric as fabric
import pandas as pd
from notebookutils import mssparkutils
from pyspark.sql import SparkSession
from delta import DeltaTable

def get_lakehouse_columns(lakehouseName = None, workspaceName = None):

    """
    
    This function outputs a dataframe containing a list of tables/columns in a lakehouse. It is used for the schema check
    as well as for properly adding the calc tables to the new semantic model.

    Parameters:
        
        lakehouseName: An optional parameter to set the lakehouse. This defaults to the lakehouse attached to the notebook.
        workspaceName: An optional parameter to set the workspace in which the lakehouse exists. This defaults to the workspace attached to the notebook.

    Returns:

        This function returns a pandas dataframe with the following columns:

            Workspace Name
            Lakehouse Name
            Table Name
            Column Name
            Full Column Name
            Data Type

            Note: 'Full Column Name' is in the following format: 'TableName'[ColumnName]
    """

    from .HelperFunctions import resolve_lakehouse_name
    from .HelperFunctions import create_daxfullobjectname
    from .HelperFunctions import resolve_lakehouse_id
    from .GetLakehouseTables import get_lakehouse_tables

    df = pd.DataFrame(columns=['Workspace Name', 'Lakehouse Name', 'Table Name', 'Column Name', 'Full Column Name', 'Data Type'])

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)

    if lakehouseName == None:
        lakehouseId = fabric.get_lakehouse_id()
        lakehouseName = resolve_lakehouse_name(lakehouseId, workspaceName)
    else:
        lakehouseId = resolve_lakehouse_id(lakehouseName, workspaceName)

    spark = SparkSession.builder.getOrCreate()

    tables = get_lakehouse_tables(lakehouseName, workspaceName)
    tables_filt = tables[tables['Format'] == 'delta']
    #tables = mssparkutils.fs.ls(f'abfss://{workspaceId}@onelake.dfs.fabric.microsoft.com/{lakehouseId}/Tables')

    for i, r in tables_filt.iterrows():
        tName = r['Table Name']
        tPath = r['Location']
        delta_table = DeltaTable.forPath(spark, tPath)
        sparkdf = delta_table.toDF()

        for cName, data_type in sparkdf.dtypes:
            tc = create_daxfullobjectname(tName, cName)
            new_data = {'Workspace Name': workspaceName, 'Lakehouse Name': lakehouseName, 'Table Name': tName, 'Column Name': cName, 'Full Column Name': tc, 'Data Type': data_type}
            df = pd.concat([df, pd.DataFrame(new_data, index=[0])], ignore_index=True)

    return df