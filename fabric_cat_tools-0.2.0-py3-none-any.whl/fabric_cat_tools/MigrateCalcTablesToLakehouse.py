import sempy
import sempy.fabric as fabric
import pandas as pd
import re
sempy.fabric._client._utils._init_analysis_services()
import Microsoft.AnalysisServices.Tabular as TOM
from pyspark.sql import SparkSession

def migrate_calc_tables_to_lakehouse(datasetName, newDatasetName, workspaceName = None):

    """
    
    This function is executed to establish the initial creation of the delta lake tables in the lakehouse
    based on the calculated tables in the original semantic model. It stores the calculated table DAX
    expression as annotations in the new semantic model.

    This function only creates one row in the lakehouse table to save time ( TOPN(...,1) ). 
    The RefreshCalcTables function is used to fully populate each calc table in the lakehouse.

    Parameters:

        datasetName: The old semantic model name.
        newDatasetName: The new semantic model name.
        workspaceName: An optional parameter to set the workspace where the semantic models exist. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of this operation.
    """

    from .HelperFunctions import resolve_dataset_id
    from .GetLakehouseTables import get_lakehouse_tables
    from .HelperFunctions import resolve_lakehouse_name

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)

    lakehouseId = fabric.get_lakehouse_id()
    lakehouseName = resolve_lakehouse_name(lakehouseId, workspaceName)

    dfC = fabric.list_columns(dataset = datasetName, workspace = workspaceName)
    dfC['Full Column Name'] = "'" + dfC['Table Name'] + "'[" + dfC['Column Name'] + "]"
    dfC_filt = dfC[dfC['Type'] == 'Calculated']
    dfP = fabric.list_partitions(dataset = datasetName, workspace = workspaceName)
    dfP_filt = dfP[dfP['Source Type'] == 'Calculated']
    dfC_CalcColumn = dfC[dfC['Type'] == 'Calculated']
    lakeTables = get_lakehouse_tables(lakehouseName, workspaceName)

    # Do not execute the function if lakehouse tables already exist with the same name
    killFunction = False
    for i, r in dfP_filt.iterrows():
        tName = r['Table Name']
        dtName = tName.replace(' ', '_')        

        if dtName in lakeTables['Table Name'].values:
            print(f"ERROR: The '{tName}' table already exists as '{dtName}' in the '{lakehouseName}' lakehouse in the '{workspaceName}' workspace.")
            killFunction = True
        
    if killFunction:
        return

    spark = SparkSession.builder.getOrCreate()

    if len(dfP_filt) == 0:
        print(f"The '{datasetName}' semantic model in the '{workspaceName}' workspace has no calculated tables.")
        return

    tom_server = fabric.create_tom_server(readonly=False, workspace=workspaceName)
    newDatasetId = resolve_dataset_id(newDatasetName, workspaceName)

    for i,r in dfP_filt.iterrows():
        tName = r['Table Name']
        query = r['Query']

        # For field parameters, remove calc columns from the query
        if not query.find('NAMEOF') == -1:
            rows = query.strip().split('\n')
            filtered_rows = [row for row in rows if not any(value in row for value in dfC_CalcColumn['Full Column Name'].values)]

            updated_query_string = '\n'.join(filtered_rows)

            # Remove extra comma
            lines = updated_query_string.strip().split('\n')
            lines[-2] = lines[-2].rstrip(',')
            updated_query_string = '\n'.join(lines)

            query = updated_query_string

        daxquery = 'EVALUATE \nTOPN(1,\n' + query + '\n)' # Only take 1 row to establish the table structure

        try:
            df = fabric.evaluate_dax(dataset = datasetName,dax_string = daxquery, workspace = workspaceName)

            # Update column names for non-field parameters
            if query.find('NAMEOF') == -1:
                for old_column_name in df.columns:
                    pattern = r"\[([^\]]+)\]"
                    
                    matches = re.findall(pattern, old_column_name) 
                    new_column_name = matches[0]
                    new_column_name = new_column_name.replace(' ','')
                
                    df.rename(columns={old_column_name: new_column_name}, inplace=True)

                    # Update data types for lakehouse columns
                    dfC_type = dfC[(dfC['Table Name'] == tName) & (dfC['Source'] == old_column_name)]
                    dataType = dfC_type['Data Type'].iloc[0]
                                        
                    if dataType == 'Int64':
                        df[new_column_name] = df[new_column_name].astype(int)
                    elif dataType in ['Decimal', 'Double']:
                        df[new_column_name] = df[new_column_name].astype(float)
                    elif dataType == 'Boolean':
                        df[new_column_name] = df[new_column_name].astype(bool)
                    elif dataType == 'DateTime':
                        df[new_column_name] = pd.to_datetime(df[new_column_name])                                        
            else:
                second_column_name = df.columns[1]
                third_column_name = df.columns[2]
                df[third_column_name] = df[third_column_name].astype(int)

                # Remove calc columns from field parameters
                mask = df[second_column_name].isin(dfC_filt['Full Column Name'])
                df = df[~mask]

            delta_table_name = tName.replace(' ','_')

            spark_df = spark.createDataFrame(df)
            spark_df.write.mode('overwrite').format('delta').saveAsTable(delta_table_name)

            # Set annotations on the model for each calc table with their source expression
            m = tom_server.Databases[newDatasetId].Model

            ann = TOM.Annotation()
            ann.Name = tName
            ann.Value = query

            try:
                if not any(existing_ann.Name == tName for existing_ann in m.Annotations):
                    m.Annotations.Add(ann)
                    print(f"Model annotation for the '{tName}' table and its expression has been added.")
                else:
                    m.Annotations[tName].Value = query
                    print(f"Model annotation for the '{tName}' table and its expression has been updated.")
            except:
                print(f"ERROR: Model annotation for the '{tName}' table was not added.")
            m.SaveChanges()

            print(f"Calculated table '{tName}' has been created as delta table '{delta_table_name.lower()}' in the lakehouse.")
        except:
            print(f"Failed to create calculated table '{tName}' as a delta table in the lakehouse.")