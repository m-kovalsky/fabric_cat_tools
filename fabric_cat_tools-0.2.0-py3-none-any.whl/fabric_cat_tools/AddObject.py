import sempy
import sempy.fabric as fabric
import pandas as pd
sempy.fabric._client._utils._init_analysis_services()
import Microsoft.AnalysisServices.Tabular as TOM
import System

def add_measure(datasetName, tableName, measureName, measureExpression, measureDescription = None, measureFormatString = None, measureDisplayFolder = None, workspaceName = None):

    """
    
    This function adds a new measure to a semantic model.

    Parameters:

        datasetName: The name of the semantic model.
        tableName: The name of the table to which the measure will be added.
        measureName: The name of the new measure to be created.
        measureExpression: The DAX expression of the new measure.
        measureDescription: An optional paramter to set the description of the measure.
        measureFormatString: An optional parameter to set the format string of the measure.
        measureDisplayFolder: An optional parameter to set the display folder of the measure.
        workspaceName: An optional parameter to set the workspace in which the lakehouse resides. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of the operation.

    Example:

    add_measure(
        datasetName = 'AdventureWorks'
        ,tableName = 'Internet Sales'
        ,measureName = 'Sales Amount'
        ,measureExpression =  "SUM( 'Internet Sales'[SalesAmount] )"
        #,measureDisplayFolder = ''
        #,measureFormatString = ''
        #,workspaceName = '' 
        )
    """

    from .HelperFunctions import resolve_dataset_id

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)   
    
    dfM = fabric.list_measures(dataset = datasetName, workspace = workspaceName)
    dfM_filt = dfM[dfM['Measure Name'] == measureName]

    if len(dfM_filt) > 0:
        print(f"The '{measureName}' already exists in the '{datasetName}' semantic model in the '{workspaceName}' workspace.")
    else:
        datasetId = resolve_dataset_id(datasetName, workspaceName)
        tom_server = fabric.create_tom_server(readonly=False, workspace=workspaceName)

        print(f"Updating the '{datasetName}' semantic model...")
        m = tom_server.Databases[datasetId].Model        
        try:
            measure = TOM.Measure()
            measure.Name = measureName
            measure.Expression = measureExpression
            if measureDisplayFolder is not None:
                measure.DisplayFolder = measureDisplayFolder
            if measureDescription is not None:
                measure.Description = measureDescription
            if measureFormatString is not None:
                measure.FormatString = measureFormatString

            m.Tables[tableName].Measures.Add(measure)
            m.SaveChanges()
            print(f"The '{measureName}' measure has been added to the '{tableName}' table in the '{datasetName}' semantic model within the '{workspaceName}' workspace.")
        except:
            print(f"ERROR: The '{measureName}' measure was not created.")

def add_relationship(datasetName, fromTable, fromColumn, toTable, toColumn, fromCardinality, toCardinality, crossFilteringBehavior = 'Automatic', isActive = True, securityFilteringBehavior = 'OneDirection', relyOnReferentialIntegrity = False, workspaceName = None):

    """
    
    This function adds a new relationship to a semantic model.

    Parameters:

        datasetName: The name of the semantic model.
        fromTable: The name of the table on the 'from' side of the relationship.
        fromColumn: The name of the column on the 'from' side of the relationship.
        toTable: The name of the table on the 'to' side of the relationship.
        toColumn: The name of the column on the 'to' side of the relationship.
        fromCardinality: The cardinality on the 'from' side of the relationship (One/Many/None) 
        toCardinality: The cardinality on the 'to' side of the relationship (One/Many/None)
        crossFilteringBehavior: An optional parameter for setting the cross filtering behavior. Default: 'Automatic'. Options: 'Automatic', 'OneDiredction', 'BothDirections'
        securityFilteringBehavior: An optional parameter for setting the security filtering behavior. Default: 'OneDirection'. Options: 'OneDirection', 'BothDirections', 'None'
        isActive: An optional parameter for setting whether the relationship is active or not. Default:  True
        relyOnReferentialIntegrity: An optional parameter. Default: False
        workspaceName: An optional parameter to set the workspace in which the lakehouse resides. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of the operation.

    Example:

        add_relationship(
            datasetName = 'AdventureWorks'
            ,fromTable = 'Internet Sales'
            ,fromColumn = 'ProductKey'
            ,toTable = 'Product'
            ,toColumn = 'ProductKey'
            ,fromCardinality = 'Many'
            ,toCardinality = 'One'
            #,workspaceName = '' 
            )
    """

    from .HelperFunctions import resolve_dataset_id
    from .HelperFunctions import create_relationship_name

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)

    relObj = create_relationship_name(fromTable,fromColumn,toTable,toColumn)
    fromCardinality = fromCardinality.capitalize()
    toCardinality = toCardinality.capitalize()

    cfbValues = ['Automatic', 'OneDirection', 'BothDirections']
    sfbValues = ['None', 'OneDirection', 'BothDirections']

    if crossFilteringBehavior not in cfbValues:
        print(f"The 'crossFilteringBehavior' parameter must be one of these values: {cfbValues}")
        return
    if securityFilteringBehavior not in sfbValues:
        print(f"The 'securityFilteringBehavior' parameter must be one of these values: {sfbValues}")
        return
    
    dfR = fabric.list_relationships(dataset = datasetName, workspace = workspaceName)    
    dfR_filt = dfR[(dfR['From Table'] == fromTable) & (dfR['From Column'] == fromColumn) & (dfR['To Table'] == toTable) & (dfR['To Column'] == toColumn)]    

    if len(dfR_filt) > 0:        
        print(f"The '{relObj}' relationship already exists in the '{datasetName}' semantic model in the '{workspaceName}' workspace.")
    else:
        datasetId = resolve_dataset_id(datasetName, workspaceName)
        tom_server = fabric.create_tom_server(readonly=False, workspace=workspaceName)

        print(f"Updating the '{datasetName}' semantic model...")
        m = tom_server.Databases[datasetId].Model        
        try:
            rel = TOM.SingleColumnRelationship()
            rel.FromColumn = m.Tables[fromTable].Columns[fromColumn]
            rel.FromCardinality = System.Enum.Parse(TOM.RelationshipEndCardinality, fromCardinality)
            rel.ToColumn = m.Tables[toTable].Columns[toColumn]
            rel.ToCardinality = System.Enum.Parse(TOM.RelationshipEndCardinality, toCardinality)
            rel.IsActive = isActive
            rel.CrossFilteringBehavior = System.Enum.Parse(TOM.CrossFilteringBehavior, crossFilteringBehavior)
            rel.SecurityFilteringBehavior = System.Enum.Parse(TOM.SecurityFilteringBehavior, securityFilteringBehavior)
            rel.RelyOnReferentialIntegrity = relyOnReferentialIntegrity
            m.Relationships.Add(rel)

            m.SaveChanges()
            print(f"The {relObj} relationship has been added to the '{datasetName}' semantic model within the '{workspaceName}' workspace.")
        except:
            print(f"ERROR: The {relObj} relationship was not created.")

def add_role(datasetName, roleName, modelPermission = 'Read', roleDescription = None, workspaceName = None):

    """
    
    This function adds a new role to a semantic model.

    Parameters:

        datasetName: The name of the semantic model.
        roleName: The name of the role to add to the semantic model.
        modelPermission: An optional parameter to set the permission for the role. Default: 'Read'. Options: 'Read', 'ReadRefresh', 'Refresh', 'Administrator', 'None'
        roleDescription: An optional parameter to set the description of the role.
        workspaceName: An optional parameter to set the workspace in which the lakehouse resides. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of the operation.

    Example:

        add_role(
            datasetName = 'AdventureWorks'
            ,roleName = 'Reader'
            ,roleDescription = 'This role is for...'
            #,workspaceName = '' 
            )
    """

    from .HelperFunctions import resolve_dataset_id

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)

    mpValues = ['Read', 'ReadRefresh', 'Refresh', 'Administrator', 'None']

    modelPermission = modelPermission.capitalize()
    
    if modelPermission not in mpValues:
        print(f"The 'modelPermission' parameter must be one of these values: {mpValues}")
        return

    dfRoles = fabric.get_roles(dataset = datasetName, workspace = workspaceName)    
    dfRoles_filt = dfRoles[(dfRoles['Role'] == roleName)]    

    if len(dfRoles_filt) > 0:        
        print(f"The '{roleName}' role already exists in the '{datasetName}' semantic model in the '{workspaceName}' workspace.")
        return

    datasetId = resolve_dataset_id(datasetName, workspaceName)
    tom_server = fabric.create_tom_server(readonly=False, workspace=workspaceName)

    print(f"Updating the '{datasetName}' semantic model...")
    m = tom_server.Databases[datasetId].Model        
    try:
        role = TOM.ModelRole()
        role.Name = roleName
        if roleDescription is not None:
            role.Description = roleDescription
        role.ModelPermission = System.Enum.Parse(TOM.ModelPermission, modelPermission)

        m.Roles.Add(role)
        m.SaveChanges()
        print(f"The '{roleName}' role has been added to the '{datasetName}' semantic model within the '{workspaceName}' workspace.")
    except:
        print(f"ERROR: The '{roleName}' role was not created.")
    
def add_hierarchy(datasetName, tableName, hierarchyName, levels, hierarchyDescription = None, workspaceName = None):

    """
    
    This function adds a new hierarchy to a semantic model.

    Parameters:

        datasetName: The name of the semantic model.
        tableName: The name of the table in which the hierarchy will be added.
        hierarchyName: The name of the hierarchy to be created.
        levels: An array of column names to be added to the hierarchy (see the example below).
        hierarchyDescription: An optional parameter to set the description of the hierarchy.
        workspaceName: An optional parameter to set the workspace in which the lakehouse resides. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of the operation.

    Example:

        add_hierarchy(
            datasetName = 'AdventureWorks'
            ,tableName = 'Geography'
            ,hierarchyName = 'Geography Hierarchy'
            ,levels = ['Continent', 'Country', 'City']
            #,workspaceName = '' 
            )
    """

    from .HelperFunctions import resolve_dataset_id

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)

    dfH = fabric.list_hierarchies(dataset = datasetName, workspace = workspaceName)
    dfH_filt = dfH[(dfH['Hierarchy Name'] == hierarchyName) & (dfH['Table Name'] == tableName)]

    if len(dfH_filt) > 0:        
        print(f"ERROR: The '{hierarchyName}' hierarchy already exists in the '{tableName}' table in the '{datasetName}' semantic model in the '{workspaceName}' workspace.")
        return
    
    if isinstance(levels, str):
        print(f"ERROR: The 'levels' parameter must be an array.")
        return
    if len(levels) == 1:
        print(f"ERROR: The 'levels' parameter must be an array of multiple columns.")
        return

    datasetId = resolve_dataset_id(datasetName, workspaceName)
    tom_server = fabric.create_tom_server(readonly=False, workspace=workspaceName)

    print(f"Updating the '{datasetName}' semantic model...")
    m = tom_server.Databases[datasetId].Model 

    try:
        hier = TOM.Hierarchy()
        hier.Name = hierarchyName
        if hierarchyDescription is not None:
            hier.Description = hierarchyDescription

        m.Tables[tableName].Hierarchies.Add(hier)
        print(f"The '{hierarchyName}' hierarchy within the '{tableName}' table has been added.")

        try:
            lvl = TOM.Level()

            i = 0
            for levelName in levels:
                lvl.Column = m.Tables[tableName].Columns[levelName]
                lvl.Name = levelName
                lvl.Ordinal = i
                i+=1

                m.Tables[tableName].Hierarchies[hierarchyName].Levels.Add(lvl)
                print(f"The '{levelName}' level within the '{hierarchyName}' hierarchy in the '{tableName}' table has been added.")
        except:
            pass
    except:
        print(f"ERROR: The '{hierarchyName}' hierarchy within the '{tableName}' table was not added.")
   
def add_rls(datasetName, roleName, tableName, filterExpression, workspaceName = None):

    """
    
    This function adds row level security to a role/table within a semantic model.

    Parameters:

        datasetName: The name of the semantic model.
        roleName: The name of the role to which row level security will be added.
        tableName: The name of the table for which to add row level security.
        filterExpression: The row level security (DAX) expression.        
        workspaceName: An optional parameter to set the workspace in which the lakehouse resides. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of the operation.

    Example:

        add_rls(
            datasetName = 'AdventureWorks'
            ,roleName = 'Reader'
            ,tableName = 'UserGeography'
            ,filterExpression = "'UserGeography'[UserEmail] = USERPRINCIPALNAME()"
            #,workspaceName = '' 
            )
    """

    from .HelperFunctions import resolve_dataset_id

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)

    dfRoles = fabric.get_roles(dataset = datasetName, workspace = workspaceName)    
    dfT = fabric.list_tables(dataset = datasetName, workspace = workspaceName)    
    dfRoles_filt = dfRoles[dfRoles['Role'] == roleName]  
    dfT_filt = dfT[dfT['Name'] == tableName]  

    if len(dfRoles_filt) == 0:        
        print(f"ERROR: The '{roleName}' role does not exist in the '{datasetName}' semantic model in the '{workspaceName}' workspace.")
        return
    if len(dfT_filt)== 0:
        print(f"ERROR: The '{tableName}' table does not exist in the '{datasetName}' semantic model in the '{workspaceName}' workspace.")
        return

    datasetId = resolve_dataset_id(datasetName, workspaceName)
    tom_server = fabric.create_tom_server(readonly=False, workspace=workspaceName)

    print(f"Updating the '{datasetName}' semantic model...")
    m = tom_server.Databases[datasetId].Model
    try:
        tp = TOM.TablePermission()
        tp.Table = m.Tables[tableName]
        tp.FilterExpression = filterExpression

        m.Roles[roleName].TablePermissions.Add(tp)

        m.SaveChanges()
        print(f"Row level security has been added to the '{roleName}' role for the '{tableName}' table in the '{datasetName}' semantic model within the '{workspaceName}' workspace.")
    except:
        print(f"ERROR: Row level security has not been added to the '{roleName}' role  for the '{tableName}' table.")

def add_field_parameter(datasetName, tableName, objects, workspaceName = None):

    """
    
    This function adds a field parameter as a calculated table to a semantic model.

    Parameters:

        datasetName: The name of the semantic model.        
        tableName: The name of the field parameter table.
        objects: An array of columns/measures for the field parameter.
        workspaceName: An optional parameter to set the workspace in which the lakehouse resides. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of the operation.

    Example:

        add_field_parameter(
            datasetName = 'AdventureWorks'
            ,tableName = 'Parameter'
            ,objects = ["[Sales Amount]", "[Order Qty]", "'Internet Sales'[Color]"]
            #,workspaceName = '' 
            )
    """

    from .HelperFunctions import resolve_dataset_id
    from .HelperFunctions import create_daxfullobjectname

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)

    if isinstance(objects,str):
        print(f"ERROR: The 'objects' parameter must be an array, not a text value string.")
        return
    if len(objects) == 1:
        print(f"ERROR: The 'objects' parameter must be an array of multiple values.")
        return

    dfM = fabric.list_measures(dataset = datasetName, workspace = workspaceName)
    dfM['Measure Object'] = create_daxfullobjectname(dfM['Table Name'], dfM['Measure Name'])
    dfM['Measure Object No Table'] = '[' +  dfM['Measure Name'] + ']'
    dfC = fabric.list_columns(dataset = datasetName, workspace = workspaceName)
    dfC['Column Object'] = create_daxfullobjectname(dfC['Table Name'], dfC['Column Name'])
    dfC['Column Object No Quotes'] = dfC['Table Name'] + '[' + dfC['Column Name'] + ']'
    expr = '{\n\t'

    i=0
    for obj in objects:
        if obj in dfM['Measure Object'].values or obj in dfM['Measure Object No Table'].values:
            dfM_filt = dfM[(dfM['Measure Object'] == obj) | (dfM['Measure Object No Table'] == obj)]
            objName = dfM_filt['Measure Name'].iloc[0]
            expr = expr + '("' + objName + '", NAMEOF(' + obj + '), ' + str(i) + '),\n'
        elif obj in dfC['Column Object'].values or obj in dfC['Column Object No Quotes'].values:
            dfC_filt = dfC[(dfC['Column Object'] == obj) | (dfC['Column Object No Quotes'] == obj)]
            objName = dfC_filt['Column Name'].iloc[0]
            fullObjName = dfC_filt['Column Object'].iloc[0]
            expr = expr + '("' + objName + '", NAMEOF(' + fullObjName + '), ' + str(i) + '),\n'
        else:
            print('ERROR: Object not found...')
            return
        i+=1

    if expr.endswith(",\n"):
        expr = expr[:-2]
    expr = expr + '\n}'

    tom_server = fabric.create_tom_server(readonly=False, workspace=workspaceName)
    datasetId = resolve_dataset_id(datasetName, workspaceName)
    m = tom_server.Databases[datasetId].Model

    try:
        par = TOM.Partition()
        par.Name = tableName

        parSource = TOM.CalculatedPartitionSource()
        par.Source = parSource
        parSource.Expression = expr

        tbl = TOM.Table()
        tbl.Name = tableName
        tbl.Partitions.Add(par)

        columns = ['A', 'B', 'C']

        for colName in columns:
            col = TOM.CalculatedTableColumn()
            col.Name = colName
            col.SourceColumn = colName
            col.DataType = TOM.DataType.String

        m.Tables.Add(tbl)

        m.SaveChanges()

        # Update column properties
        m.Tables[tableName].Columns['Value2'].IsHidden = True
        m.Tables[tableName].Columns['Value3'].IsHidden = True
        m.Tables[tableName].Columns['Value3'].DataType = TOM.DataType.Int64
        m.Tables[tableName].Columns['Value2'].SortByColumn = m.Tables[tableName].Columns['Value3']

        m.Tables[tableName].Columns['Value1'].Name = tableName
        m.Tables[tableName].Columns['Value2'].Name = tableName + ' Fields'
        m.Tables[tableName].Columns['Value3'].Name = tableName + ' Order'

        m.SaveChanges()
        print(f"The '{tableName}' table has been added as a field parameter to the '{datasetName}' semantic model in the '{workspaceName}' workspace.")
    except:
        print(f"ERROR: The '{tableName}' table has not been added as a field parameter.")

def set_annotation(datasetName, objectType, objectName, annotationName, annotationValue, workspaceName = None):

    """

    This function adds a field parameter as a calculated table to a semantic model

    Parameters:

        datasetName: The name of the semantic model.        
        objectType: The object type upon which to set an annotation. Options: ['Model', 'Table', 'Partition', 'Column', 'Measure', 'Hierarchy', ]
        objectName: The object name upon which to set an annotation.
        annotationName: The name of the annotation.
        annotationValue: The value of the annotation.
        workspaceName: An optional parameter to set the workspace in which the lakehouse resides. This defaults to the
            workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of the operation.

    Examples:

        set_annotation(
            datasetName = 'AdventureWorks'
            ,objectType = 'Column'
            ,objectName = "'Internet Sales'[SalesAmount]"
            ,annotationName = 'hello'
            ,annotationValue = '33'            
            #,workspaceName = '' 
            )

        set_annotation(
            datasetName = 'AdventureWorks'
            ,objectType = 'Table'
            ,objectName = "Internet Sales"
            ,annotationName = 'hello'
            ,annotationValue = '33'            
            #,workspaceName = '' 
            )

        set_annotation(
            datasetName = 'AdventureWorks'
            ,objectType = 'Measure'
            ,objectName = "Sales Amount"
            ,annotationName = 'hello'
            ,annotationValue = '33'            
            #,workspaceName = '' 
            )
    """

    from .HelperFunctions import resolve_dataset_id
    from .HelperFunctions import create_daxfullobjectname
    from .ListFunctions import list_annotations

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)

    objectType = objectType.capitalize()

    if objectType == 'Model':
        objectName = 'Model'

    dfA = list_annotations(datasetName, workspaceName)
    dfA_filt = dfA[(dfA['Object Type'] == objectType) & (dfA['Object Name'] == objectName) & (dfA['Annotation Name'] == annotationName)]

    if len(dfA_filt) > 0:
        print(f"The '{annotationName}' annotation on the '{objectType}' object type in the '{datasetName}' semantic model already exists.")
        return

    tom_server = fabric.create_tom_server(readonly=False, workspace=workspaceName)
    datasetId = resolve_dataset_id(datasetName, workspaceName)
    m = tom_server.Databases[datasetId].Model

    ann = TOM.Annotation()
    ann.Name = annotationName
    ann.Value = annotationValue

    try:

        if objectType == 'Model':
            m.Annotations.Add(ann)
        elif objectType == 'Table':
            m.Tables[objectName].Annotations.Add(ann)
        elif objectType == 'Column':
            dfC = fabric.list_columns(dataset = datasetName, workspace = workspaceName)
            dfC['Column Object'] = create_daxfullobjectname(dfC['Table Name'], dfC['Column Name'])
            dfC_filt = dfC[dfC['Column Object'] == objectName]
            tName = dfC_filt['Table Name'].iloc[0]
            oName = dfC_filt['Column Name'].iloc[0]
            m.Tables[tName].Columns[oName].Add(ann)
        elif objectType == 'Measure':
            dfM = fabric.list_measures(dataset = datasetName, workspace = workspaceName)                
            dfM_filt = dfM[dfM['Measure Name'] == objectName]
            tName = dfM_filt['Table Name'].iloc[0]
            oName = dfM_filt['Measure Name'].iloc[0]
            m.Tables[tName].Measures[oName].Add(ann)
        elif objectType == 'Hierarchy':
            dfH = fabric.list_hierarchies(dataset = datasetName, workspace = workspaceName)
            dfH['Hierarchy Object'] = create_daxfullobjectname(dfH['Table Name'], dfH['Hierarchy Name'])
            dfH_filt = dfH[dfH['Hierarchy Object'] == objectName]
            tName = dfH_filt['Table Name'].iloc[0]
            oName = dfH_filt['Hierarchy Name'].iloc[0]
            m.Tables[tName].Hierarchies[oName].Add(ann)
        elif objectType == 'Partition':
            dfP = fabric.list_partitions(dataset = datasetName, workspace = workspaceName)
            dfP['Partition Object'] = create_daxfullobjectname(dfP['Table Name'], dfP['Partition Name'])
            dfP_filt = dfP[dfP['Partition Object'] == objectName]
            tName = dfP_filt['Table Name'].iloc[0]
            oName = dfP_filt['Partition Name'].iloc[0]
            m.Tables[tName].Partitions[oName].Add(ann)
        elif objectType == 'Data Source':
            m.DataSources[objectName].Add(ann)
        #elif objectType == 'Relationship':
        #    m.Relationship[objectName].Add(ann)
        elif objectType == 'Translation':
            m.Cultures[objectName].Add(ann)
        elif objectType == 'Expression':
            m.Expressions[objectName].Add(ann)
        elif objectType == 'Role':
            m.Roles[objectName].Add(ann)
        elif objectType == 'Perspective':
            m.Perspective[objectName].Add(ann)

        m.SaveChanges()
        print(f"The '{annotationName}' annotation on the '{objectName}' {objectType} in the '{datasetName}' semantic model has been created.")
    except:
        print(f"ERROR: '{annotationName}' annotation has not been created on for the '{objectName}' {objectType} in the '{datasetName}' semantic model.")
    
    m.SaveChanges()

        

        

