import sempy
import sempy.fabric as fabric
import json, requests, pandas as pd

def report_rebind(report, dataset, report_workspace = None, dataset_workspace = None):

    """
    
    This function rebinds a report to the specified semantic model.

    Parameters:

        report: The report to be rebinded.
        dataset: The semantic model to rebind to the report.
        report_workspace: An optional parameter to set the workspace in which the report resides. This defaults to the
          workspace in which the notebook resides.
        dataset_workspace: An optional parameter to set the workspace in which the semantic model resides. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of this operation.        
    """

    from .HelperFunctions import resolve_dataset_id
    from .HelperFunctions import resolve_report_id

    if report_workspace == None:
        report_workspace_id = fabric.get_workspace_id()
        report_workspace = fabric.resolve_workspace_name(report_workspace_id)
    else:
        report_workspace_id = fabric.resolve_workspace_id(report_workspace)
    if dataset_workspace == None:
        dataset_workspace = report_workspace 

    client = fabric.PowerBIRestClient()

    reportId = resolve_report_id(report = report, workspace = report_workspace)
    datasetId = resolve_dataset_id(dataset = dataset, workspace = dataset_workspace)

    # Prepare API
    request_body = {
        'datasetId': datasetId
    }

    response = client.post(f"/v1.0/myorg/groups/{report_workspace_id}/reports/{reportId}/Rebind",json=request_body)

    if response.status_code == 200:
        print(f"The '{report}' report has been successfully rebinded to the '{dataset}' semantic model.")
    else:
        print(f"The '{report}' report within the '{report_workspace}' workspace failed to rebind to the '{dataset}' semantic model within the '{dataset_workspace}' workspace.")

def report_rebind_all(dataset, new_dataset, dataset_workspace = None, new_dataset_workpace = None, report_workspace = None):

    """
    
    This function rebinds all reports which are bound to a specific semantic model to a different semantic model.

    Parameters:

        dataset: The old semantic model name.
        new_dataset: The new semantic model name.
        dataset_workspace: The workspace in which the original semantic model resides. This defaults to the workspace in which the notebook resides.
        new_dataset_workspace: The workspace in which the new semantic model resides. This defaults to the workspace in which the notebook resides.
        report_workspace: The workspace in which the reports reside. This defaults to the workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of this operation.        
    """

    from .HelperFunctions import resolve_dataset_id

    if dataset_workspace == None:
        dataset_workspace_id = fabric.get_workspace_id()
        dataset_workspace = fabric.resolve_workspace_name(dataset_workspace_id)
    else:
        dataset_workspace_id = fabric.resolve_workspace_id(dataset_workspace)    

    if new_dataset_workpace == None:
        new_dataset_workpace = dataset_workspace

    if report_workspace == None:
        report_workspace = dataset_workspace
    
    datasetId = resolve_dataset_id(dataset, dataset_workspace)

    dfRep = fabric.list_reports(workspace = report_workspace)
    dfRep_filt = dfRep[dfRep['Dataset Id'] == datasetId]

    for i, r in dfRep_filt.iterrows():
        rptName = r['Name']
        report_rebind(report = rptName, dataset = new_dataset, report_workspace = report_workspace, dataset_workspace = new_dataset_workpace)