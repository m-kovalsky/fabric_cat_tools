import sempy
import sempy.fabric as fabric
import pandas as pd
sempy.fabric._client._utils._init_analysis_services()
import Microsoft.AnalysisServices.Tabular as TOM
from notebookutils import mssparkutils
import System

def migrate_tables_columns_to_semantic_model(dataset, new_dataset, workspace = None, new_dataset_workspace = None, lakehouse = None, lakehouse_workspace = None):

    """
    
    This function adds tables and columns (and only their basic properties) to the new semantic model
    based on the original semantic model. This only includes regular tables (not calc tables or calc groups).

    Parameters:
        
        dataset: This is name of the original semantic model.
        new_dataset: This is name of the new semantic model.
        workspace: An optional parameter to set the workspace of the original semantic models. This defaults to the workspace in which the notebook resides.
        new_dataset_workspace: An optional parameter to set the workspace where the new semantic model resides. This defaults to thes same workspace as the original semantic model.
        lakehouse: An optional parameter to set the lakehouse to tie the new Direct Lake semantic model.
        lakehouse_workspace: The workspace in which the lakehouse resides.

    Returns:

        This function returns a printout detailing which objects have been migrated and any failures.    

    """

    from .ListFunctions import list_tables
    from .GetSharedExpression import get_shared_expression
    from .HelperFunctions import resolve_lakehouse_name
    from .Lakehouse import lakehouse_attached

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)
    else:
        workspace_id = fabric.resolve_workspace_id(workspace)

    if new_dataset_workspace == None:
        new_dataset_workspace = workspace

    if lakehouse_workspace == None:
        lakehouse_workspace = new_dataset_workspace

    if lakehouse == None:
        lakehouse_id = fabric.get_lakehouse_id()
        lakehouse = resolve_lakehouse_name(lakehouse_id, lakehouse_workspace)

    tom_server = fabric.create_tom_server(readonly=False, workspace=new_dataset_workspace)    

    # Check that lakehouse is attached to the notebook
    lakeAttach = lakehouse_attached()

    # Run if lakehouse is attached to the notebook or a lakehouse & lakehouse workspace are specified
    if lakeAttach or (lakehouse is not None and lakehouse_workspace is not None):
        #print('Lakehouse attached to notebook\n')
        shEx = get_shared_expression(lakehouse, lakehouse_workspace)

        dfC = fabric.list_columns(dataset = dataset, workspace = workspace)
        dfT = list_tables(dataset, workspace)

        print(f"Updating '{new_dataset}' based on '{dataset}'...")
        m = tom_server.Databases.GetByName(new_dataset).Model
        print(f"\nCreating shared expression parameter...")
        exp = TOM.NamedExpression()
        eName = 'DatabaseQuery'
        exp.Name = eName
        exp.Kind = TOM.ExpressionKind.M
        exp.Expression = shEx
        if not any(e.Name == eName for e in m.Expressions):
            m.Expressions.Add(exp)
            print(f"'{eName}' shared expression has been added.")

        for tName in dfC['Table Name'].unique():
            tType = dfT.loc[(dfT['Name'] == tName), 'Type'].iloc[0]
            tDC = dfC.loc[(dfC['Table Name'] == tName), 'Data Category'].iloc[0]
            tDesc = dfC.loc[(dfC['Table Name'] == tName), 'Description'].iloc[0]

            # Create the table with its columns for regular tables that do not already exist in the model
            if tType == 'Table' and not any(t.Name == tName for t in m.Tables):
                tbl = TOM.Table()        
                tbl.Name = tName
                tbl.DataCategory = tDC
                tbl.Description = tDesc

                ep = TOM.EntityPartitionSource()
                ep.Name = tName
                ep.EntityName = tName.replace(' ', '_') #lakehouse table names use underscores instead of spaces
                ep.ExpressionSource = exp

                part = TOM.Partition()
                part.Name = tName
                part.Source = ep
                part.Mode = TOM.ModeType.DirectLake

                tbl.Partitions.Add(part)

                columns_in_table = dfC.loc[dfC['Table Name'] == tName, 'Column Name'].unique()
        
                print(f"\nCreating columns for '{tName}' table...")           
                for cName in columns_in_table:
                    scName = dfC.loc[(dfC['Table Name'] == tName) & (dfC['Column Name'] == cName), 'Source'].iloc[0]
                    cType = dfC.loc[(dfC['Table Name'] == tName) & (dfC['Column Name'] == cName), 'Type'].iloc[0]
                    cHid = bool(dfC.loc[(dfC['Table Name'] == tName) & (dfC['Column Name'] == cName), 'Hidden'].iloc[0])
                    cDataType = dfC.loc[(dfC['Table Name'] == tName) & (dfC['Column Name'] == cName), 'Data Type'].iloc[0]

                    if cType == 'Data' and not any(t.Name == tName and c.Name == cName for t in m.Tables for c in t.Columns):
                        col = TOM.DataColumn()
                        col.Name = cName
                        col.IsHidden = cHid
                        col.SourceColumn = scName.replace(' ', '_') #lakehouse column names use underscores instead of spaces
                        col.DataType = System.Enum.Parse(TOM.DataType, cDataType)

                        tbl.Columns.Add(col)
                        print(f"The '{tName}'[{cName}] column has been added.")
        
                m.Tables.Add(tbl)
                print(f"The '{tName}' table has been added.")

        m.SaveChanges()
        print(f"\nAll regular tables and columns have been added to the '{new_dataset}' semantic model.")

    else:
        print('Lakehouse not attached to notebook and lakehouse/lakehouse_workspace are not specified. Please add your lakehouse to this notebook or specify the lakehouse/lakehouse_workspace parameters.')
        print(f"To attach a lakehouse to a notebook, go to the the 'Explorer' window to the left, click 'Lakehouses' to add your lakehouse to this notebook")
        print(f"\nLearn more here: https://learn.microsoft.com/fabric/data-engineering/lakehouse-notebook-explore#add-or-remove-a-lakehouse")