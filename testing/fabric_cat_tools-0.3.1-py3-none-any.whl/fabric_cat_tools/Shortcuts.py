import sempy
import sempy.fabric as fabric
import pandas as pd

def create_shortcut_onelake(table_name, source_lakehouse, source_workspace, destination_lakehouse, destination_workspace = None, shortcut_name = None):

    """
    
    This function creates a shortcut based on a table in OneLake (Fabric lakehouse).

    Parameters:

        table_name: The table name for which a shortcut will be created.
        source_lakehouse: The lakehouse in which the table resides.
        source_workspace: The workspace in which the source lakehouse resides.        
        destination_lakehouse: The lakehouse where the shortcut will be created.
        destination_workspace: An optional parameter to se the workspace in which the shortcut will be created. Defaults to the source_workspace.
        shortcut_name: An optional parameter to set the name of the shortcut 'table' to be created. This defaults to the tableName.

    Returns:

        This function returns a printout stating the success/failure of this operation.

    Examples:

        create_shortcut_onelake(
            table_name = 'DimCalendar'
            ,source_lakehouse = 'Lakehouse1'
            ,source_workspace = 'Workspace1'
            ,destination_lakehouse = 'Lakehouse2'
            ,destination_workspace = 'Workspace2'
            #,shortcut_name = ''
            )

        create_shortcut_onelake(
            table_name = 'DimCalendar'
            ,source_lakehouse = 'Lakehouse1'
            ,source_workspace = 'Workspace1'
            ,destination_lakehouse = 'Lakehouse2'
            #,destination_workspace = ''
            ,shortcut_name = 'Calendar'
            )

    """

    from .HelperFunctions import resolve_lakehouse_id

    sourceWorkspaceId = fabric.resolve_workspace_id(source_workspace)
    sourceLakehouseId = resolve_lakehouse_id(source_lakehouse, source_workspace)

    if destination_workspace == None:
        destination_workspace = source_workspace
    
    destinationWorkspaceId = fabric.resolve_workspace_id(destination_workspace)
    destinationLakehouseId = resolve_lakehouse_id(destination_lakehouse, destination_workspace)

    if shortcutName == None:
        shortcutName = table_name
    
    client = fabric.FabricRestClient()
    tablePath = 'Tables/' + table_name

    request_body = {
    "path": 'Tables',
    "name": shortcutName.replace(' ',''),
    "target": {
        "oneLake": {
        "workspaceId": sourceWorkspaceId,
        "itemId": sourceLakehouseId,
        "path": tablePath}
        }
    }

    try:
        response = client.post(f"/v1/workspaces/{destinationWorkspaceId}/items/{destinationLakehouseId}/shortcuts",json=request_body)
        if response.status_code == 201:
            print(f"The shortcut '{shortcutName}' was created in the '{destination_lakehouse}' lakehouse within the '{destination_workspace} workspace. It is based on the '{table_name}' table in the '{source_lakehouse}' lakehouse within the '{source_workspace}' workspace.")
        else:
            print(response.status_code)
    except:
        print(f"ERROR: Failed to create a shortcut for the '{table_name}' table.")

def create_shortcut(shortcut_name, location, subpath, source, connection_id, lakehouse = None, workspace = None):

    """
    
    This function creates a shortcut based on an ADLSGen2 or Amazon S3 source.

    Parameters:

        shortcut_name: The name of the shortcut to be created.
        location:
        subpath:
        source: 
        connection_id: 
        lakehouse: The lakehouse where the shortcut will be created.
        workspace: An optional parameter to se the workspace in which the shortcut will be created. Defaults to the source_workspace.

    Returns:

        This function returns a printout stating the success/failure of this operation.

    Examples:

        create_shortcut(
            table_name = 'PartnerEmployees'
            ,location = 'https://my-s3-bucket.s3.us-west-2.amazonaws.com'
            ,subpath = '/data/ContosoEmployees'
            ,connectionId = 'cf480513-2c1c-46b2-958a-42556ee584c3'
            ,source = 'amazonS3'
            ,destination_lakehouse = 'Lakehouse2'
            ,destination_workspace = 'Workspace2'
            )

        create_shortcut(
            table_name = 'PartnerProducts'
            ,location = 'https://contosoadlsaccount.dfs.core.windows.net'
            ,subpath = '/mycontainer/data/ContosoProducts'
            ,connectionId = '91324db9-8dc4-4730-a1e5-bafabf1fb91e'
            ,source = 'adlsGen2'
            ,destination_lakehouse = 'Lakehouse2'
            ,destination_workspace = 'Workspace2'
            )

    """    

    from .HelperFunctions import resolve_lakehouse_id

    source_titles = {
        'adlsGen2': 'ADLS Gen2',
        'amazonS3': 'Amazon S3'
    }

    sourceValues = list(source_titles.keys())

    if source not in sourceValues:
        print(f"ERROR: The 'source' parameter must be one of these values: {sourceValues}.")
        return

    sourceTitle = source_titles[source]

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)
    else:
        workspace_id = fabric.resolve_workspace_id(workspace)

    if lakehouse == None:
        lakehouse_id = fabric.get_lakehouse_id()
    else:
        lakehouse_id = resolve_lakehouse_id(lakehouse, workspace)
    
    client = fabric.FabricRestClient()
    shortcutActualName = shortcut_name.replace(' ','')

    request_body = {
    "path": 'Tables',
    "name": shortcutActualName,
    "target": {
        source: {
        "location": location,
        "subpath": subpath,
        "connectionId": connection_id}
        }
    }

    try:
        response = client.post(f"/v1/workspaces/{workspace_id}/items/{lakehouse_id}/shortcuts",json=request_body)
        if response.status_code == 201:
            print(f"The shortcut '{shortcutActualName}' was created in the '{lakehouse}' lakehouse within the '{workspace} workspace. It is based on the '{subpath}' table in '{sourceTitle}'.")
        else:
            print(response.status_code)
    except:
        print(f"ERROR: Failed to create a shortcut for the '{shortcut_name}' table.")

def list_shortcuts(lakehouse = None, workspace = None):

    """
    
    This function shows all the shortcuts for a given lakehouse.

    Parameters:

        lakehouse: The lakehouse name.
        workspace: The workspace in which the lakehouse resides.

    Returns:

        This function returns a pandas dataframe showing all the shortcuts in the lakehouse and their details.

    Example:

        list_shortcuts(
            ,lakehouse = 'MyLakehouse'
            #,workspace = 'Workspace1'
            )

    """

    from .HelperFunctions import resolve_lakehouse_name
    from .HelperFunctions import resolve_lakehouse_id    

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)
    else:
        workspace_id = fabric.resolve_workspace_id(workspace)
    
    if lakehouse == None:
        lakehouse_id = fabric.get_lakehouse_id()
        lakehouse = resolve_lakehouse_name(lakehouse_id, workspace)
    else:
        lakehouse_id = resolve_lakehouse_id(lakehouse, workspace)

    df = pd.DataFrame(columns=['Shortcut Name', 'Shortcut Path', 'Source', 'Source Lakehouse Name', 'Source Workspace Name', 'Source Path', 'Source Connection ID', 'Source Location', 'Source SubPath'])

    client = fabric.FabricRestClient()
    response = client.get(f"/v1/workspaces/{workspace_id}/items/{lakehouse_id}/shortcuts")
    if response.status_code == 200:
        for s in response.json()['value']:
            shortcutName = s['name']
            shortcutPath = s['path']
            source = list(s['target'].keys())[0]
            sourceLakehouseName, sourceWorkspaceName, sourcePath, connectionId, location, subpath = None, None, None, None, None, None
            if source == 'oneLake':
                sourceLakehouseId = s['target'][source]['itemId']
                sourcePath = s['target'][source]['path']
                sourceWorkspaceId = s['target'][source]['workspaceId']
                sourceWorkspaceName = fabric.resolve_workspace_name(sourceWorkspaceId)
                sourceLakehouseName = resolve_lakehouse_name(sourceLakehouseId, sourceWorkspaceName)
            else:
                connectionId = s['target'][source]['connectionId']
                location = s['target'][source]['location']
                subpath = s['target'][source]['subpath']

            new_data = {'Shortcut Name': shortcutName, 'Shortcut Path': shortcutPath, 'Source': source, 'Source Lakehouse Name': sourceLakehouseName, 'Source Workspace Name': sourceWorkspaceName, 'Source Path': sourcePath, 'Source Connection ID': connectionId, 'Source Location': location, 'Source SubPath': subpath}
            df = pd.concat([df, pd.DataFrame(new_data, index=[0])], ignore_index=True) 
    
    return df

def delete_shortcut(shortcut_name, lakehouse = None, workspace = None):

    """
    
    This function deletes a shortcut in OneLake.

    Parameters:

        shortcut_name: The name of the shortcut to delete.
        lakehouse: The lakehouse in which the shortcut resides.
        workspace: The workspace in which the lakehouse resides.

    Returns:

        This function returns a printout stating the success/failure of this operation.

    Example:

        delete_shortcut(
            shortcut_name = 'DimCalendar'
            ,lakehouse = 'Lakehouse1'
            ,workspace = 'Workspace1'
            )

    """

    from .HelperFunctions import resolve_lakehouse_name
    from .HelperFunctions import resolve_lakehouse_id

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)
    else:
        workspace_id = fabric.resolve_workspace_id(workspace)
    
    if lakehouse == None:
        lakehouse_id = fabric.get_lakehouse_id()
        lakehouse = resolve_lakehouse_name(lakehouse_id, workspace)
    else:
        lakehouse_id = resolve_lakehouse_id(lakehouse, workspace)

    client = fabric.FabricRestClient()
    response = client.delete(f"/v1/workspaces/{workspace_id}/items/{lakehouse_id}/shortcuts/Tables/{shortcut_name}")
    
    if response.status_code == 200:
        print(f"The '{shortcut_name}' shortcut in the '{lakehouse}' within the '{workspace}' workspace has been deleted.")
    else:
        print(f"ERROR: The '{shortcut_name}' has not been deleted.")