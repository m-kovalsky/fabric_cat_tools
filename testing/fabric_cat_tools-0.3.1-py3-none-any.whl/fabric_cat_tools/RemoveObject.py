import sempy
import sempy.fabric as fabric
import pandas as pd

def remove_measure(dataset, measure_name, workspace = None):

    """

    This function removes measure(s) from a semantic model

    Parameters:

        dataset: The name of the semantic model.        
        measure_name: The name of the measure(s) to be removed. Can be a single measure name or an array of measure names.
        workspace: An optional parameter to set the workspace in which the semantic model resides. This defaults to the workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of the operation.

    Examples:

        remove_measure(
            dataset = 'AdventureWorks'
            ,measure_name = 'Sales Amount' 
            #,workspace = '' 
            )

        remove_measure(
            dataset = 'AdventureWorks'
            ,measure_name = ['Sales Amount', 'Order Quantity']
            #,workspace = '' 
            )
    """

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)
    else:
        workspace_id = fabric.resolve_workspace_id(workspace)

    if isinstance(measure_name, str):
        measure_name = [measure_name]

    dfM = fabric.list_measures(dataset = dataset, workspace = workspace)
    dfM_filt = dfM[dfM['Measure Name'].isin(measure_name)]        

    # Check if no measures validate:
    if len(dfM_filt) == 0:
        print(f"ERROR: The '{measure_name}' measure(s) do not exist in the '{dataset}' semantic model in the '{workspace}' workspace.")
        return
    
    # Print out invalid measures
    for m in measure_name:
        if m not in dfM['Measure Name'].values:
            print(f"ERROR: The '{m}' measure does not exist in the '{dataset}' semantic model in the '{workspace}' workspace.")

    tom_server = fabric.create_tom_server(readonly=False, workspace=workspace)
    m = tom_server.Databases.GetByName(dataset).Model

    # Remove validated measures
    for i, r in dfM_filt.iterrows():
        tName = r['Table Name']
        mName = r['Measure Name']

        try:
            m.Tables[tName].Measures.Remove(mName)
            print(f"The '{mName}' measure has been removed from the '{dataset}' semantic model in the '{workspace}' workspace.")
        except:
            print(f"ERROR: The '{mName}' measure has not been removed from the '{dataset}' semantic model in the '{workspace}' workspace.")

    m.SaveChanges()

def remove_table(dataset, table_name, workspace = None):

    """

    This function removes table(s) from a semantic model

    Parameters:

        dataset: The name of the semantic model.        
        table_name: The name of the table(s) to be removed. Can be a single table name or an array of table names.
        workspace: An optional parameter to set the workspace in which the semantic model resides. This defaults to the workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of the operation.

    Examples:

        remove_table(
            dataset = 'AdventureWorks'
            ,table_name = 'Internet Sales' 
            #,workspace = '' 
            )

        remove_table(
            dataset = 'AdventureWorks'
            ,table_name = ['Internet Sales', 'Geography']
            #,workspace = '' 
            )
    """

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)
    else:
        workspace_id = fabric.resolve_workspace_id(workspace)

    if isinstance(table_name, str):
        table_name = [table_name]

    dfT = fabric.list_tables(dataset = dataset, workspace = workspace)
    dfT_filt = dfT[dfT['Name'].isin(table_name)]

    # Check if no tables validate:
    if len(dfT_filt) == 0:
        print(f"The '{table_name}' table(s) do not exist in the '{dataset}' semantic model in the '{workspace}' workspace.")
        return
    
    # Print out invalid tables
    for m in table_name:
        if m not in dfT['Name'].values:
            print(f"The '{m}' table does not exist in the '{dataset}' semantic model in the '{workspace}' workspace.")
    
    tom_server = fabric.create_tom_server(readonly=False, workspace=workspace)
    m = tom_server.Databases.GetByName(dataset).Model

    # Remove validated tables
    for i, r in dfT_filt.iterrows():
        tName = r['Name']

        try:
            m.Tables.Remove(tName)
            print(f"The '{tName}' table has been removed from the '{dataset}' semantic model in the '{workspace}' workspace.")
        except:
            print(f"ERROR: The '{tName}' table has not been removed from the '{dataset}' semantic model in the '{workspace}' workspace.")

    m.SaveChanges()

def remove_column(dataset, table_name, column_name, workspace = None):

    """

    This function removes column(s) from a semantic model

    Parameters:

        dataset: The name of the semantic model.        
        table_name: The name of the column's table. See the examples below.
        column_name: The name of the column(s) to be removed. Can be a single column name or an array of column names. See the examples below.
        workspace: An optional parameter to set the workspace in which the semantic model resides. This defaults to the workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of the operation.

    Examples:

        remove_column(
            dataset = 'AdventureWorks'
            ,table_name = 'Internet Sales'
            ,column_name = 'SalesAmount'
            #,workspace = '' 
            )

        remove_column(
            dataset = 'AdventureWorks'
            ,table_name = ['Internet Sales', 'Geography']
            ,column_name = ['SalesAmount', 'GeographyKey']
            #,workspace = '' 
            )
    """

    from .HelperFunctions import format_dax_object_name

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)
    else:
        workspaceId = fabric.resolve_workspace_id(workspace)

    # Support both str & list types
    if isinstance(table_name, str):
        table_name = [table_name]
    if isinstance(column_name, str):
        column_name = [column_name]
    
    if len(table_name) != len(column_name):
        print(f"ERROR: The 'table_name' and 'column_name' arrays must be of equal length.")
        return
    
    tblcol = pd.DataFrame({
        'Table Name': table_name,
        'Column Name': column_name
    })
    tblcol['Column Object'] = format_dax_object_name(tblcol['Table Name'], tblcol['Column Name'])

    dfC = fabric.list_columns(dataset = dataset, workspace = workspace)
    dfC['Column Object'] = format_dax_object_name(dfC['Table Name'], dfC['Column Name'])    
    dfC_filt = dfC[dfC['Column Object'].isin(tblcol['Column Object'].values)]

    # Check if no columns validate:
    if len(dfC_filt) == 0:
        print(f"ERROR: The columns submitted do not exist in the '{dataset}' semantic model in the '{workspace}' workspace.")
        return
    
    # Print out invalid columns
    for i,r in tblcol.iterrows():
        colobj = r['Column Object']
        if colobj not in dfC['Column Object'].values:
            print(f"ERROR: The {colobj} column does not exist in the '{dataset}' semantic model in the '{workspace}' workspace.")
    
    tom_server = fabric.create_tom_server(readonly=False, workspace=workspace)
    m = tom_server.Databases.GetByName(dataset).Model

    # Remove validated columns
    for i, r in dfC_filt.iterrows():
        tName = r['Table Name']
        oName = r['Column Name']
        coName = r['Column Object']

        try:
            m.Tables[tName].Columns.Remove(oName)
            print(f"The {coName}'column has been removed from the '{dataset}' semantic model in the '{workspace}' workspace.")
        except:
            print(f"ERROR: The {coName} column has not been removed from the '{dataset}' semantic model in the '{workspace}' workspace.")

    m.SaveChanges()