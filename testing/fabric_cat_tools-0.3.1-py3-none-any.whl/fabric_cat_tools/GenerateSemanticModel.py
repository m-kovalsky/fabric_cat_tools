import sempy
import sempy.fabric as fabric
import pandas as pd
import json, base64, time

def create_semantic_model_from_bim(dataset, bim_file, workspace = None):

    """

    This function deploys a Model.bim file to create a new semantic model in a workspace.

    Note: Make sure to set the data source credentials within the dataset settings in order for the data source credentials to populate properly

    Parameters:

        dataset: The name of the semantic model to be created.
        bim_file: A model.bim file for a semantic model. Use the get_semantic_model_bim to obtain the Model.bim file for a semantic model in a Fabric workspace.
        workspace: An optional parameter to set the workspace in which the semantic model will be created. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of the operation.

    """

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)
    else:
        workspace_id = fabric.resolve_workspace_id(workspace)

    objectType = 'SemanticModel'

    dfI = fabric.list_items(workspace = workspace)
    dfI_filt = dfI[(dfI['Display Name'] == dataset) & (dfI['Type'] == objectType)]

    if len(dfI_filt) > 0:
        print(f"WARNING: '{dataset}' already exists as a semantic model in the '{workspace}' workspace.")
        return

    client = fabric.FabricRestClient()
    defPBIDataset = {
    "version": "1.0",
    "settings": {}
    }

    def conv_b64(file):
        
        loadJson = json.dumps(file)
        f = base64.b64encode(loadJson.encode('utf-8')).decode('utf-8')
        
        return f

    payloadPBIDefinition = conv_b64(defPBIDataset)
    payloadBim = conv_b64(bim_file)

    request_body = {
            'displayName': dataset,
            'type': objectType,
            'definition': {
        "parts": [
            {
                "path": "model.bim",
                "payload": payloadBim,
                "payloadType": "InlineBase64"
            },
            {
                "path": "definition.pbidataset",
                "payload": payloadPBIDefinition,
                "payloadType": "InlineBase64"
            }
        ]

            }
        }

    response = client.post(f"/v1/workspaces/{workspace_id}/items",json=request_body)

    if response.status_code == 201:
        print('Model creation succeeded')
        print(response.json())
    elif response.status_code == 202:
        location_url = response.headers['Location']
        operationId = response.headers['x-ms-operation-id']
        response = client.get(f"/v1/operations/{operationId}")
        response_body = json.loads(response.content) 
        while response_body['status'] != 'Succeeded':
            time.sleep(3)
            response = client.get(f"/v1/operations/{operationId}")
            response_body = json.loads(response.content)
        response = client.get(f"/v1/operations/{operationId}/result")
        print('Model creation succeeded')
        print(response.json())