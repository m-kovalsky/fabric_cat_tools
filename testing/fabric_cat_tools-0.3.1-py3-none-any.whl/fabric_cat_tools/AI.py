import sempy
import sempy.fabric as fabric
from synapse.ml.services.openai import OpenAICompletion
from pyspark.sql.functions import col
from pyspark.sql import SparkSession
sempy.fabric._client._utils._init_analysis_services()
import Microsoft.AnalysisServices.Tabular as TOM
import System

def generate_measure_descriptions(dataset, measures, gpt_model = 'gpt-35-turbo', workspace = None):

    if isinstance(measures, str):
        measures = [measures]

    validModels = ['gpt-35-turbo', 'gpt-35-turbo-16k', 'gpt-4']
    if gpt_model not in validModels:
        print(f"The '{gpt_model}' model is not a valid model. Enter a gpt_model from this list: {validModels}.")
        return

    dfM = fabric.list_measures(dataset = dataset, workspace = workspace)

    if measures is not None:
        dfM_filt = dfM[dfM['Measure Name'].isin(measures)]
    else:
        dfM_filt = dfM

    df = dfM_filt[['Table Name', 'Measure Name', 'Measure Expression', 'Measure Description']]

    # Generate new column in df dataframe which has the AI-generated descriptions
    completion = {
        OpenAICompletion()
        .setDeploymentName(gpt_model)
        .setMaxTokens(200)
        .setPromptCol('prompt')
        .setErrorCol('error')
        .setOutputCol('completions')
    }

    completed_df = completion.transform(df).cache()
    completed_df.select(
        col('prompt'),
        col('error'),
        col('completions.choices.text').getItem(0).alias('text'),
    )

    # Update the model to use the new descriptions
    tom_server = fabric.create_tom_server(readonly=False, workspace=workspace)
    m = tom_server.Databases.GetByName(dataset).Model

    #for t in m.Tables:
        #tName = t.Name
        #for ms in t.Measures:
            #mName = ms.Name
            #mDesc = promptValue

    #m.SaveChanges()

def generate_aggs(dataset, table_name, columns, workspace = None, lakehouse_workspace = None):

    from .HelperFunctions import get_direct_lake_sql_endpoint
    from .HelperFunctions import resolve_lakehouse_id
    from .GetSharedExpression import get_shared_expression

    #columns = {
    #'SalesAmount': 'Sum',
    #'ProductKey': 'GroupBy',
    #'OrderDateKey': 'GroupBy'
    #}

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)

    if lakehouse_workspace == None:
        lakehouse_workspace = workspace
        lakehouse_workspace_id = workspace_id
    else:
        lakehouse_workspace_id = fabric.resolve_workspace_id(lakehouse_workspace)

    if isinstance(columns, str):
        columns = [columns]

    columnValues = columns.keys()
    
    aggTypes = ['Sum', 'Count', 'Min', 'Max', 'GroupBy']
    aggTypesAggregate =  ['Sum', 'Count', 'Min', 'Max']
    numericTypes = ['Int64', 'Double', 'Decimal']

    if any(value not in aggTypes for value in columns.values()):
        print(f"Invalid aggregation type(s) have been specified in the 'columns' parameter. Valid aggregation types: {aggTypes}.")
        return

    dfP = fabric.list_partitions(dataset = dataset, workspace = workspace)
    if not any(r['Mode'] == 'DirectLake' for i, r in dfP.iterrows()):
        print(f"The '{dataset}' semantic model within the '{workspace}' workspace is not in Direct Lake mode. This function is only relevant for Direct Lake semantic models.")
        return
    
    dfC = fabric.list_columns(dataset = dataset, workspace = workspace)
    dfC_filtT = dfC[dfC['Table Name'] == table_name]

    if len(dfC_filtT) == 0:
        print(f"The '{table_name}' table does not exist in the '{dataset}' semantic model within the '{workspace}' workspace.")
        return
    
    dfC_filt = dfC[(dfC['Table Name'] == table_name) & (dfC['Column Name'].isin(columnValues))]

    if len(columns) != len(dfC_filt):
        print(f"Columns listed in '{columnValues}' do not exist in the '{table_name}' table in the '{dataset}' semantic model within the '{workspace}' workspace.")
        return
    
    # Check if doing sum/count/min/max etc. on a non-number column
    for col,agg in columns.items():
        dfC_col = dfC_filt[dfC_filt['Column Name'] == col]
        dataType = dfC_col['Data Type'].iloc[0]
        if agg in aggTypesAggregate and dataType not in numericTypes:
            print(f"The '{col}' column in the '{table_name}' table is of '{dataType}' data type. Only columns of '{numericTypes}' data types can be aggregated as '{aggTypesAggregate}' aggregation types.")
            return

    # Create/update lakehouse delta agg table
    aggTableName = f"{table_name}_agg"
    delta_table_name = aggTableName.lower().replace(' ','_')
    dfP = fabric.list_partitions(dataset = dataset, workspace = workspace)
    dfP_filt = dfP[dfP['Table Name'] == table_name]
    lakeTName = dfP_filt['Query'].iloc[0]

    sqlEndpointId = get_direct_lake_sql_endpoint(dataset = dataset, workspace = workspace)

    dfI = fabric.list_items(workspace = lakehouse_workspace)
    dfI_filt = dfI[(dfI['Id'] == sqlEndpointId) & (dfI['Type'] == 'SQLEndpoint')]

    if len(dfI_filt) == 0:
        print(f"The lakehouse (SQL Endpoint) used by the '{dataset}' semantic model does not reside in the '{lakehouse_workspace}' workspace. Please update the lakehouse_workspace parameter.")
        return
    
    lakehouseName = dfI_filt['Display Name'].iloc[0]
    lakehouse_id = resolve_lakehouse_id(lakehouse = lakehouseName, workspace = lakehouse_workspace)

    spark = SparkSession.builder.getOrCreate()

    filePath = f"abfss://{lakehouse_workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}/Tables/{delta_table_name}"

    # Generate SQL query
    sql = 'SELECT \n'
    for col, agg in columns:
        colFilt = dfP_filt[dfP_filt['Column Name'] == col]
        sourceCol = colFilt['Source'].iloc[0]
        if agg == 'GroupBy':
            sql = f"{sql}{sourceCol},\n"
        else:
            sql = f"{sql}{agg}({sourceCol}),\n"
    
    sql = sql[:-2]
    sql = sql + f" FROM {lakehouseName}.{lakeTName}"
    print(sql)

    # Run SQL query to create/overwrite delta table
    #spark_df = spark.createDataFrame(df)
    #spark_df.write.mode('overwrite').format('delta').save(filePath)


    

    # Create/update semantic model agg table
    tom_server = fabric.create_tom_server(readonly=False, workspace=workspace)
    m = tom_server.Databases.GetByName(dataset).Model

    dfC_agg = dfC[dfC['Table Name'] == aggTableName]

    if len(dfC_agg) == 0:
        # Create agg table
        exp = m.Expressions['DatabaseQuery'].Expression
        tbl = TOM.Table()        
        tbl.Name = aggTableName
        tbl.IsHidden = True

        ep = TOM.EntityPartitionSource()
        ep.Name = aggTableName
        ep.EntityName = delta_table_name
        ep.ExpressionSource = exp

        part = TOM.Partition()
        part.Name = aggTableName
        part.Source = ep
        part.Mode = TOM.ModeType.DirectLake

        tbl.Partitions.Add(part)

        for i, r in dfC_filt.iterrows():
            scName = r['Source']
            cName = r['Column Name']
            dType = r['Data Type']

            col = TOM.DataColumn()
            col.Name = cName
            col.IsHidden = True
            col.SourceColumn = scName
            col.DataType = System.Enum.Parse(TOM.DataType, dType)

            tbl.Columns.Add(col)
            print(f"The '{aggTableName}'[{cName}] column has been added.")

        m.Tables.Add(tbl)
        print(f"The '{aggTableName}' table has been added.")
    else:
        # Remove existing columns
        for t in m.Tables:
            tName = t.Name
            for c in t.Columns:
                cName = c.Name
                if t.Name == aggTableName:
                    m.Tables[tName].Columns.Remove(cName)
        # Add columns
        for i, r in dfC_filt.iterrows():
            scName = r['Source']
            cName = r['Column Name']
            dType = r['Data Type']

            col = TOM.DataColumn()
            col.Name = cName
            col.IsHidden = True
            col.SourceColumn = scName
            col.DataType = System.Enum.Parse(TOM.DataType, dType)

            m.Tables[aggTableName].Columns.Add(col)
            print(f"The '{aggTableName}'[{cName}] column has been added.")

    # Update DAX measure(s)
    
    
    #m.SaveChanges()
    

    
