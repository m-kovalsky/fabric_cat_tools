import sempy
import sempy.fabric as fabric
import time

def refresh_semantic_model(dataset, refresh_type = 'full', workspace = None):

    """
    
    This function runs a full refresh of a given semantic model.
    
    Parameters:

        dataset: The semantic model name.
        refresh_type: The refresh type of the semantic model. Valid options: 'full', 'automatic', 'dataOnly', 'calculate', 'clearValues', 'defragment'. Default value: 'full'
        workspace: An optional parameter to set the workspace where the semantic model resides. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of this operation.

    """

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)

    refreshTypes = ['full', 'automatic', 'dataOnly', 'calculate', 'clearValues', 'defragment']

    if refresh_type not in refreshTypes:
        print(f"ERROR: Invalid refresh type. Refresh type must be one of these values: {refreshTypes}.")
        return
        
    requestID = fabric.refresh_dataset(dataset = dataset, workspace = workspace, refresh_type = refresh_type)
    print(f"Refresh of the '{dataset}' semantic model within the '{workspace}' workspace is in progress...")

    while True:
        requestDetails = fabric.get_refresh_execution_details(dataset = dataset,refresh_request_id = requestID, workspace = workspace)
        status = requestDetails.status

        # Check if the refresh has completed
        if status == 'Completed':
            break
        elif status == 'Failed':
            print(f"The refresh of the '{dataset}' semantic model within the '{workspace}' workspace has failed.")
            return
        elif status == 'Cancelled':
            print(f"The refresh of the '{dataset}' semantic model within the '{workspace}' workspace has been cancelled.")
            return

        time.sleep(3)

    print(f"Refresh of the '{dataset}' semantic model within the '{workspace}' workspace is complete.")

def cancel_dataset_refresh(dataset, request_id = None, workspace = None):

    """
    
    This function cancels a semantic model refresh which was executed via the Enhanced Refresh API.
    
    Parameters:

        dataset: The semantic model name.
        request_id: An optional parameter for specifying the request_id of the refresh event to cancel. If no request_id is entered, the latest active refresh will be cancelled.
        workspace: An optional parameter to set the workspace where the semantic model resides. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of this operation.

    """

    from .HelperFunctions import resolve_dataset_id

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)
    else:
        workspace_id = fabric.resolve_workspace_id(workspace)
    
    rr = fabric.list_refresh_requests(dataset = dataset, workspace = workspace)
    rr_filt = rr[rr['Status'] == 'Unknown']

    if request_id == None:
        if len(rr_filt) == 0:
            print(f"There are no active Enhanced API refreshes of the '{dataset}' semantic model within the '{workspace}' workspace.")
            return
        request_id = rr_filt['Request Id'].iloc[0]
    
    dataset_id = resolve_dataset_id(dataset = dataset, workspace = workspace)

    client = fabric.PowerBIRestClient()

    response = client.delete(f"/v1.0/myorg/groups/{workspace_id}/datasets/{dataset_id}/refreshes/{request_id}")    
    if response.status_code == 200:
        print(f"The '{request_id}' refresh request for the '{dataset}' semantic model within the '{workspace}' workspace has been cancelled.")
    else:
        print(response.status_code)

