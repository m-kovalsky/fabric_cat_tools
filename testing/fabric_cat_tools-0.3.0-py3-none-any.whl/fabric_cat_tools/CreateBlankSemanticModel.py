import sempy
import sempy.fabric as fabric

def create_blank_semantic_model(dataset, compatibility_level = 1605, workspace = None):

  """
  
    This function generates a new blank semantic model (no tables or anything) within a given workspace.
    
    Parameters:
        
        dataset: This is name of the new semantic model.
        compatibility_level: An optional parameter to set the compatibility level of the semantic model. This defaults to 1605.
        workspace: An optional parameter to set the workspace where the semantic model will be created. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a printout of the success/failure of the operation.

    """

  if workspace == None:
    workspace_id = fabric.get_workspace_id()
    workspace = fabric.resolve_workspace_name(workspace_id)

  tmsl = f'''
  {{
    "createOrReplace": {{
      "object": {{
        "database": '{dataset}'
      }},
      "database": {{
        "name": '{dataset}',
        "compatibilityLevel": {compatibility_level},
        "model": {{
          "culture": "en-US",
          "defaultPowerBIDataSourceVersion": "powerBI_V3"
        }}
      }}
    }}
  }}
  '''

  return fabric.execute_tmsl(script = tmsl, workspace = workspace)