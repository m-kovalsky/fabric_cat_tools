import sempy
import sempy.fabric as fabric

def clear_cache(dataset: str, workspace: str | None = None):

    """
    
    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#clear_cache

    """

    from .HelperFunctions import resolve_dataset_id

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)

    datasetID = resolve_dataset_id(dataset = dataset, workspace = workspace)

    xmla = f"""
            <ClearCache xmlns="http://schemas.microsoft.com/analysisservices/2003/engine">  
                <Object>  
                    <DatabaseID>{datasetID}</DatabaseID>  
                </Object>  
            </ClearCache>
            """
    fabric.execute_xmla(dataset = dataset,xmla_command=xmla, workspace = workspace)

    outputtext = f"Cache cleared for the '{dataset}' semantic model within the '{workspace}' workspace."
    
    return outputtext