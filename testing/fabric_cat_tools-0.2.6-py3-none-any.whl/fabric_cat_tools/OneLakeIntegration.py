import sempy
import sempy.fabric as fabric
import pandas as pd

def export_model_to_onelake(datasetName, workspaceName = None, destinationLakehouseName = None, destinationWorkspaceName = None):

    """
    
    This function uses the OneLake Integration feature to export a semantic model's tables as delta tables. The XMLA Read/Write endpoint must be enabled for the capcity and the semantic model must have the OneLake Integration feature enabled.

    See here for documentation: https://learn.microsoft.com/en-us/power-bi/enterprise/onelake-integration-overview

    Parameters:

        datasetName: This is name of the semantic model.
        workspaceName: An optional parameter to set the workspace where the semantic model resides. This defaults to the
          workspace in which the notebook resides.
        destinationLakehouseName: An optional parameter to set the lakehouse where the delta tables will be created as shortcuts. If it does not exist it will be created. If this parameter is not set, shortcuts will not be made.        
        destinationWorkspaceName: An optional parameter to set the workspace where the destination lakehouse exists. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of the operation.

    Examples:

        export_model_to_onelake(
            datasetName = ''
            ,workspaceName = None
            ,destinationLakehouseName = 'Lakehouse2'            
            ,destinationWorkspaceName = 'Workspace2'
            )
    """

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)

    if destinationWorkspaceName == None:
        destinationWorkspaceName = workspaceName
        destinationWorkspaceId = workspaceId
    else:
        destinationWorkspaceId = fabric.resolve_workspace_id(destinationWorkspaceName)

    dfD = fabric.list_datasets(workspace = workspaceName)
    dfD_filt = dfD[dfD['Dataset Name'] == datasetName]

    if len(dfD_filt) == 0:
        print(f"The '{datasetName}' semantic model does not exist in the '{workspaceName}' workspace.")
        return

    tmsl = f"""
    {{
    'export': {{
    'layout': 'delta',
    'type': 'full',  
    'objects': [  
        {{  
        'database': '{datasetName}'
        }}  
    ]  
    }}  
    }}
    """

    # Export model's tables as delta tables
    try:
        fabric.execute_tmsl(script = tmsl, workspace = workspaceName)
        print(f"The '{datasetName}' semantic model's tables have been exported as delta tables to the '{workspaceName}' workspace.\n")
    except:
        print(f"ERROR: The '{datasetName}' semantic model's tables have not been exported as delta tables to the '{workspaceName}' workspace.")
        print(f"Make sure you enable OneLake integration for the '{datasetName}' semantic model. Follow the instructions here: https://learn.microsoft.com/power-bi/enterprise/onelake-integration-overview#enable-onelake-integration")
        return
    
    # Create shortcuts if destination lakehouse is specified
    if destinationLakehouseName is not None:
        # Destination...
        dfI_Dest = fabric.list_items(workspace = destinationWorkspaceName)
        dfI_filt = dfI_Dest[(dfI_Dest['Type'] == 'Lakehouse') & (dfI_Dest['Display Name'] == destinationLakehouseName)]

        if len(dfI_filt) == 0:
            print(f"The '{destinationLakehouseName}' lakehouse does not exist within the '{destinationWorkspaceName}' workspace.")
            # Create lakehouse
            destinationLakehouseId = fabric.create_lakehouse(display_name = destinationLakehouseName, workspace = destinationWorkspaceName)
            print(f"The '{destinationLakehouseName}' lakehouse has been created within the '{destinationWorkspaceName}' workspace.\n")        
        else:
            destinationLakehouseId = dfI_filt['Id'].iloc[0]

        # Source...
        dfI_Source = fabric.list_items(workspace = workspaceName)
        dfI_filtSource = dfI_Source[(dfI_Source['Type'] == 'SemanticModel') & (dfI_Source['Display Name'] == datasetName)]
        sourceLakehouseId = dfI_filtSource['Id'].iloc[0]

        # Valid tables
        dfP = fabric.list_partitions(dataset = datasetName, workspace = workspaceName, additional_xmla_properties=['Parent.SystemManaged'])
        dfP_filt = dfP[(dfP['Mode'] == 'Import') & (dfP['Source Type'] != 'CalculationGroup') & (dfP['Parent System Managed'] == False)]
        dfC = fabric.list_columns(dataset = datasetName, workspace = workspaceName)
        tmc = pd.DataFrame(dfP.groupby('Table Name')['Mode'].nunique()).reset_index()
        oneMode = tmc[tmc['Mode'] == 1]
        tableAll = dfP_filt[dfP_filt['Table Name'].isin(dfC['Table Name'].values) & (dfP_filt['Table Name'].isin(oneMode['Table Name'].values))]
        tables = tableAll['Table Name'].unique()

        client = fabric.FabricRestClient()

        print("Creating shortcuts...\n")
        for tableName in tables:      
            tablePath = 'Tables/' + tableName
            shortcutName = tableName.replace(' ','')
            request_body = {
            "path": 'Tables',
            "name": shortcutName,
            "target": {
                "oneLake": {
                "workspaceId": workspaceId,
                "itemId": sourceLakehouseId,
                "path": tablePath}
                }
            }

            try:
                response = client.post(f"/v1/workspaces/{destinationWorkspaceId}/items/{destinationLakehouseId}/shortcuts",json=request_body)
                if response.status_code == 201:                
                    print(f"\u2022 The shortcut '{shortcutName}' was created in the '{destinationLakehouseName}' lakehouse within the '{destinationWorkspaceName}' workspace. It is based on the '{tableName}' table in the '{datasetName}' semantic model within the '{workspaceName}' workspace.\n")
                else:
                    print(response.status_code)
            except:
                print(f"ERROR: Failed to create a shortcut for the '{tableName}' table.")