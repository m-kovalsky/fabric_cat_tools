import sempy
import sempy.fabric as fabric
import time

def refresh_semantic_model(dataset, refresh_type = 'full', workspace = None):

    """
    
    This function runs a full refresh of a given semantic model.
    
    Parameters:

        dataset: The semantic model name.
        refresh_type: The refresh type of the semantic model. Valid options: 'full', 'automatic', 'dataOnly', 'calculate', 'clearValues', 'defragment'. Default value: 'full'
        workspace: An optional parameter to set the workspace where the semantic model resides. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of this operation.
    """

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)

    refreshTypes = ['full', 'automatic', 'dataOnly', 'calculate', 'clearValues', 'defragment']

    if refresh_type not in refreshTypes:
        print(f"ERROR: Invalid refresh type. Refresh type must be one of these values: {refreshTypes}.")
        return
        
    requestID = fabric.refresh_dataset(dataset = dataset, workspace = workspace, refresh_type = refresh_type)
    print(f"Refresh of the '{dataset}' semantic model is in progress...")

    while True:
        requestDetails = fabric.get_refresh_execution_details(dataset = dataset,refresh_request_id = requestID, workspace = workspace)
        status = requestDetails.status

        # Check if the refresh has completed
        if status == 'Completed':
            break

        time.sleep(3)

    print(f"Refresh of the '{dataset}' semantic model within the '{workspace}' workspace is complete.")