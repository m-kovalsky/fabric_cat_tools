import sempy
import sempy.fabric as fabric
import pandas as pd

def create_shortcut_onelake(tableName, sourceLakehouseName, sourceWorkspaceName, destinationLakehouseName, destinationWorkspaceName = None, shortcutName = None):

    """
    
    This function creates a shortcut based on a table in OneLake (Fabric lakehouse).

    Parameters:

        tableName: The table name for which a shortcut will be created.
        sourceLakehouseName: The lakehouse in which the table resides.
        sourceWorkspaceName: The workspace in which the source lakehouse resides.        
        destinationLakehouseName: The lakehouse where the shortcut will be created.
        destinationWorkspaceName: An optional parameter to se the workspace in which the shortcut will be created. Defaults to the sourceWorkspaceName.
        shortcutName: An optional parameter to set the name of the shortcut 'table' to be created. This defaults to the tableName.

    Returns:

        This function returns a printout stating the success/failure of this operation.

    Examples:

        create_shortcut_onelake(
            tableName = 'DimCalendar'
            ,sourceLakehouseName = 'Lakehouse1'
            ,sourceWorkspaceName = 'Workspace1'
            ,destinationLakehouseName = 'Lakehouse2'
            ,destinationWorkspaceName = 'Workspace2'
            #,shortcutName = ''
            )

        create_shortcut_onelake(
            tableName = 'DimCalendar'
            ,sourceLakehouseName = 'Lakehouse1'
            ,sourceWorkspaceName = 'Workspace1'
            ,destinationLakehouseName = 'Lakehouse2'
            #,destinationWorkspaceName = ''
            ,shortcutName = 'Calendar'
            )

    """

    from .HelperFunctions import resolve_lakehouse_id

    sourceWorkspaceId = fabric.resolve_workspace_id(sourceWorkspaceName)
    sourceLakehouseId = resolve_lakehouse_id(sourceLakehouseName, sourceWorkspaceName)

    if destinationWorkspaceName == None:
        destinationWorkspaceName = sourceWorkspaceName
    
    destinationWorkspaceId = fabric.resolve_workspace_id(destinationWorkspaceName)
    destinationLakehouseId = resolve_lakehouse_id(destinationLakehouseName, destinationWorkspaceName)

    if shortcutName == None:
        shortcutName = tableName
    
    client = fabric.FabricRestClient()
    tablePath = 'Tables/' + tableName

    request_body = {
    "path": 'Tables',
    "name": shortcutName.replace(' ',''),
    "target": {
        "oneLake": {
        "workspaceId": sourceWorkspaceId,
        "itemId": sourceLakehouseId,
        "path": tablePath}
        }
    }

    try:
        response = client.post(f"/v1/workspaces/{destinationWorkspaceId}/items/{destinationLakehouseId}/shortcuts",json=request_body)
        if response.status_code == 201:
            print(f"The shortcut '{shortcutName}' was created in the '{destinationLakehouseName}' lakehouse within the '{destinationWorkspaceName} workspace. It is based on the '{tableName}' table in the '{sourceLakehouseName}' lakehouse within the '{sourceWorkspaceName}' workspace.")
        else:
            print(response.status_code)
    except:
        print(f"ERROR: Failed to create a shortcut for the '{tableName}' table.")

def list_shortcuts(lakehouseName = None, workspaceName = None):

    """
    
    This function shows all the shortcuts for a given lakehouse.

    Parameters:

        lakehouseName: The lakehouse name.
        workspaceName: The workspace in which the lakehouse resides.

    Returns:

        This function returns a pandas dataframe showing all the shortcuts in the lakehouse and their details.

    Example:

        list_shortcuts(
            ,lakehouseName = 'MyLakehouse'
            #,workspaceName = 'Workspace1'
            )

    """

    from .HelperFunctions import resolve_lakehouse_name
    from .HelperFunctions import resolve_lakehouse_id    

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)
    
    if lakehouseName == None:
        lakehouseId = fabric.get_lakehouse_id()
        lakehouseName = resolve_lakehouse_name(lakehouseId, workspaceName)
    else:
        lakehouseId = resolve_lakehouse_id(lakehouseName, workspaceName)

    df = pd.DataFrame(columns=['Shortcut Name', 'Shortcut Path', 'Source', 'Source Lakehouse Name', 'Source Workspace Name', 'Source Path', 'Source Connection ID', 'Source Location', 'Source SubPath'])

    client = fabric.FabricRestClient()
    response = client.get(f"/v1/workspaces/{workspaceId}/items/{lakehouseId}/shortcuts")
    if response.status_code == 200:
        for s in response.json()['value']:
            shortcutName = s['name']
            shortcutPath = s['path']
            source = list(s['target'].keys())[0]
            sourceLakehouseName, sourceWorkspaceName, sourcePath, connectionId, location, subpath = None, None, None, None, None, None
            if source == 'oneLake':
                sourceLakehouseId = s['target'][source]['itemId']
                sourcePath = s['target'][source]['path']
                sourceWorkspaceId = s['target'][source]['workspaceId']
                sourceWorkspaceName = fabric.resolve_workspace_name(sourceWorkspaceId)
                sourceLakehouseName = resolve_lakehouse_name(sourceLakehouseId, sourceWorkspaceName)
            else:
                connectionId = s['target'][source]['connectionId']
                location = s['target'][source]['location']
                subpath = s['target'][source]['subpath']

            new_data = {'Shortcut Name': shortcutName, 'Shortcut Path': shortcutPath, 'Source': source, 'Source Lakehouse Name': sourceLakehouseName, 'Source Workspace Name': sourceWorkspaceName, 'Source Path': sourcePath, 'Source Connection ID': connectionId, 'Source Location': location, 'Source SubPath': subpath}
            df = pd.concat([df, pd.DataFrame(new_data, index=[0])], ignore_index=True) 
    
    return df

def delete_shortcut(shortcutName, lakehouseName = None, workspaceName = None):

    """
    
    This function deletes a shortcut in OneLake.

    Parameters:

        shortcutName: The name of the shortcut to delete.
        lakehouseName: The lakehouse in which the shortcut resides.
        workspaceName: The workspace in which the lakehouse resides.

    Returns:

        This function returns a printout stating the success/failure of this operation.

    Example:

        delete_shortcut(
            shortcutName = 'DimCalendar'
            ,lakehouseName = 'Lakehouse1'
            ,workspaceName = 'Workspace1'
            )

    """

    from .HelperFunctions import resolve_lakehouse_name
    from .HelperFunctions import resolve_lakehouse_id

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)
    
    if lakehouseName == None:
        lakehouseId = fabric.get_lakehouse_id()
        lakehouseName = resolve_lakehouse_name(lakehouseId, workspaceName)
    else:
        lakehouseId = resolve_lakehouse_id(lakehouseName, workspaceName)

    client = fabric.FabricRestClient()
    response = client.delete(f"/v1/workspaces/{workspaceId}/items/{lakehouseId}/shortcuts/Tables/{shortcutName}")
    
    if response.status_code == 200:
        print(f"The '{shortcutName}' shortcut in the '{lakehouseName}' within the '{workspaceName}' workspace has been deleted.")
    else:
        print(f"ERROR: The '{shortcutName}' has not been deleted.")