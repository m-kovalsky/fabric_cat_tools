import sempy
import sempy.fabric as fabric
import json, os
import time
import base64
import pandas as pd

def get_semantic_model_bim(datasetName, workspaceName = None, saveToFileName = None):

    """

    This script gets the model.bim file for a given dataset (semantic model).

    Parameters:

        datasetName: This is name of the semantic model.
        workspaceName: An optional parameter to set the workspace where the semantic model resides. This defaults to the
          workspace in which the notebook resides.
        saveToFileName: Specifying this optional parameter will save the .bim file with the name of this parameter in the lakehouse attached to the notebook.

    Returns:

        This function returns the .bim file of a given semantic model.

    """

    from .HelperFunctions import resolve_lakehouse_name

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)

    lakehouseId = fabric.get_lakehouse_id()
    lakehouseName = resolve_lakehouse_name(lakehouseId, workspaceName)
    
    objType = 'SemanticModel'
    client = fabric.FabricRestClient()
    itemList = fabric.list_items(workspace = workspaceName)
    itemListFilt = itemList[(itemList['Display Name'] == datasetName) & (itemList['Type'] == objType)]
    itemId = itemListFilt['Id'].iloc[0]
    response = client.post(f"/v1/workspaces/{workspaceId}/items/{itemId}/getDefinition")
        
    if response.status_code == 200:
        res = response.json()
    elif response.status_code == 202:
        operationId = response.headers['x-ms-operation-id']
        response = client.get(f"/v1/operations/{operationId}")
        response_body = json.loads(response.content) 
        while response_body['status'] != 'Succeeded':
            time.sleep(3)
            response = client.get(f"/v1/operations/{operationId}")
            response_body = json.loads(response.content)
        response = client.get(f"/v1/operations/{operationId}/result")
        res = response.json()
    df_items = pd.json_normalize(res['definition']['parts'])
    df_items_filt = df_items[df_items['path'] == 'model.bim']
    payload = df_items_filt['payload'].iloc[0]
    bimFile = base64.b64decode(payload).decode('utf-8')
    bimJson = json.loads(bimFile)

    if saveToFileName is not None:
        folderPath = '/lakehouse/default/Files'
        fileExt = '.bim'
        if not saveToFileName.endswith(fileExt):
            saveToFileName = saveToFileName + fileExt
        filePath = os.path.join(folderPath, saveToFileName)
        with open(filePath, "w") as json_file:
            json.dump(bimJson, json_file, indent=4)
        print(f"The .bim file for the '{datasetName}' semantic model has been saved to the '{lakehouseName}' in this location: '{filePath}'.\n\n")

    return bimJson