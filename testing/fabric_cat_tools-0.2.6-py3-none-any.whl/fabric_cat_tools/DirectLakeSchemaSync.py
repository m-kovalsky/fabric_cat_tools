import sempy
import sempy.fabric as fabric
import fabric_cat_tools as fct
import pandas as pd
import re
sempy.fabric._client._utils._init_analysis_services()
import Microsoft.AnalysisServices.Tabular as TOM
import System

def direct_lake_schema_sync(dataset, workspace = None, add_to_model = False, lakehouse = None, lakehouse_workspace = None):

    """
    
    This function shows/adds columns which exist in the lakehouse but do not exist in the semantic model (only for tables in the semantic model).

    Parameters:

        dataset: The semantic model name.
        workspace: An optional parameter to set the workspace where the semantic model resides. This defaults to the
          workspace in which the notebook resides.
        add_to_model: This optional boolean parameter adds columns which exist in the lakehouse but do not exist in the semantic model. No new tables are added. Default value: False.        
        lakehouse: An optional parameter to set the lakehouse. This defaults to the lakehouse attached to the notebook.
        lakehouse_workspace: An optional parameter to set the workspace in which the lakehouse exists.

    Returns:

        This function returns a printout stating the success/failure of the operation.

    Example:

    fct.direct_lake_schema_sync(
        dataset = 'AdvWorks'
        ,workspace = 'MK Demo 4'
        ,lakehouse = 'My_Lake'
        ,lakehouse_workspace = 'MK Demo 4'
        ,add_to_model=False)
    """

    from .GetLakehouseColumns import get_lakehouse_columns
    from .HelperFunctions import create_daxfullobjectname
    from .HelperFunctions import resolve_lakehouse_name
    from .HelperFunctions import get_direct_lake_sql_endpoint

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)

    if lakehouse_workspace is None:
        lakehouse_workspace = workspace

    if lakehouse == None:
        lakehouse_id = fabric.get_lakehouse_id()
        lakehouse = resolve_lakehouse_name(lakehouse_id, lakehouse_workspace)

    sqlEndpointId = get_direct_lake_sql_endpoint(dataset, workspace)

    dfI = fabric.list_items(workspace = lakehouse_workspace)
    dfI_filt = dfI[(dfI['Type'] == 'SQLEndpoint') & (dfI['Id'] == sqlEndpointId)]

    if len(dfI_filt) == 0:
        print(f"The SQL Endpoint in the '{dataset}' semantic model in the '{workspace} workspace does not point to the '{lakehouse}' lakehouse in the '{lakehouse_workspace}' workspace as specified.")
        return

    dfP = fabric.list_partitions(dataset = dataset, workspace = workspace)
    dfP_filt = dfP[dfP['Source Type'] == 'Entity']
    dfC = fabric.list_columns(dataset = dataset, workspace = workspace)
    dfC_filt = dfC[dfC['Table Name'].isin(dfP_filt['Table Name'].values)]
    dfC_filt = pd.merge(dfC_filt, dfP_filt[['Table Name', 'Query']], on = 'Table Name', how = 'left')
    dfC_filt['Column Object'] = create_daxfullobjectname(dfC_filt['Query'], dfC_filt['Source'])

    lc = get_lakehouse_columns(lakehouse, lakehouse_workspace)
    lc_filt = lc[lc['Table Name'].isin(dfP_filt['Query'].values)]

    mapping = {
        'string': 'String',
        'bigint': 'Int64',
        'int': 'Int64',
        'smallint': 'Int64',
        'boolean': 'Boolean',
        'timestamp': 'DateTime',
        'date': 'DateTime',
        'decimal(38,18)': 'Decimal',
        'double': 'Double'
    }

    tom_server = fabric.create_tom_server(readonly=False, workspace=workspace)
    m = tom_server.Databases.GetByName(dataset).Model
    for i, r in lc_filt.iterrows():
        lakeTName = r['Table Name']
        lakeCName = r['Column Name']
        fullColName = r['Full Column Name']
        dType = r['Data Type']

        if fullColName not in dfC_filt['Column Object'].values:
            dfL = dfP_filt[dfP_filt['Query'] == lakeTName]            
            tName = dfL['Table Name'].iloc[0]
            if add_to_model:
                col = TOM.DataColumn()
                col.Name = lakeCName
                col.SourceColumn = lakeCName
                dt = mapping.get(dType)
                try:
                    col.DataType = System.Enum.Parse(TOM.DataType, dt)
                except:
                    print(f"ERROR: '{dType}' data type is not mapped properly to the semantic model data types.")
                    return

                m.Tables[tName].Columns.Add(col)
                print(f"The '{lakeCName}' column has been added to the '{tName}' table as a '{dt}' data type within the '{dataset}' semantic model within the '{workspace}' workspace.")
            else:
                print(f"The {fullColName} column exists in the lakehouse but not in the '{tName}' table in the '{dataset}' semantic model within the '{workspace}' workspace.")
        m.SaveChanges()
