import sempy
import sempy.fabric as fabric
import json, requests, pandas as pd

def report_rebind(report, dataset, workspace = None):

    """
    
    This function rebinds a report to the specified semantic model.

    Parameters:

        report: The report to be rebinded.
        dataset: The semantic model to rebind to the report.
        workspace: An optional parameter to set the workspace in which the report and semantic model reside. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of this operation.
    """

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)
    else:
        workspace = fabric.resolve_workspace_id(workspace)

    client = fabric.PowerBIRestClient()
    itemList = fabric.list_items(workspace = workspace)

    # Get report ID
    itemListFilt = itemList[(itemList['Display Name'] == report) & (itemList['Type'] == 'Report')]
    reportId = itemListFilt['Id'].iloc[0]

    # Get dataset ID for rebinding
    itemListFilt = itemList[(itemList['Display Name'] == dataset) & (itemList['Type'] == 'SemanticModel')]
    datasetId = itemListFilt['Id'].iloc[0]

    # Prepare API
    request_body = {
        'datasetId': datasetId
    }

    response = client.post(f"/v1.0/myorg/groups/{workspace_id}/reports/{reportId}/Rebind",json=request_body)

    if response.status_code == 200:
        print('POST request successful')
        print(f"The '{report}' report has been successfully rebinded to the '{dataset}' semantic model.")
    else:
        print(f"POST request failed with status code: {response.status_code}")

def report_rebind_all(dataset, new_dataset, workspace = None, new_dataset_workpace = None):

    """
    
    This function rebinds all reports which are bound to a specific semantic model to a different semantic model.

    Parameters:

        dataset: The old semantic model name.
        new_dataset: The new semantic model name.
        workspace: An optional parameter to set the workspace in which the reports and semantic models reside. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of this operation.
    """

    from .HelperFunctions import resolve_dataset_id

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)
    else:
        workspace_id = fabric.resolve_workspace_id(workspace)

    if new_dataset_workpace == None:
        new_dataset_workpace = workspace
    
    datasetId = resolve_dataset_id(dataset, workspace)

    dfRep = fabric.list_reports(workspace = workspace)
    dfRep_filt = dfRep[dfRep['Dataset Id'] == datasetId]

    for i, r in dfRep_filt.iterrows():
        rptName = r['Name']
        report_rebind(rptName, new_dataset, new_dataset_workpace)