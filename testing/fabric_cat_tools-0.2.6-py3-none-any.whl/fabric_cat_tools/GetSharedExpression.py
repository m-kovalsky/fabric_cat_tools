import sempy
import sempy.fabric as fabric
import pandas as pd

def get_lakehouse_details(lakehouse = None, workspace = None):

    """
    
    This function retrieves details for a particular lakehouse within a workspace.

    Parameters:
        
        lakehouse: An optional parameter to set the lakehouse. This defaults to the lakehouse attached to the notebook.        
        workspace: An optional parameter to set the workspace in which the lakehouse resides. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns pandas dataframe with the following columns:

        Lakehouse Name
        Lakehouse ID
        Workspace Name
        Workspace ID
        OneLake Tables Path
        OneLake Files Path
        SQL Endpoint Connection String
        SQL Endpoint ID
        SQL Endpoint Provisioning Status
    """

    from .HelperFunctions import resolve_lakehouse_id

    df = pd.DataFrame(columns=['Lakehouse Name', 'Lakehouse ID', 'Workspace Name', 'Workspace ID', 'OneLake Tables Path', 'OneLake Files Path', 'SQL Endpoint Connection String', 'SQL Endpoint ID', 'SQL Endpoint Provisioning Status'])

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)
    else:
        workspace_id = fabric.resolve_workspace_id(workspace)
        
    if lakehouse == None:
        lakehouse_id = fabric.get_lakehouse_id()
    else:
        lakehouse_id = resolve_lakehouse_id(lakehouse, workspace)
    
    client = fabric.FabricRestClient()

    #https://learn.microsoft.com/rest/api/fabric/articles/item-management/properties/lakehouse-properties
    response = client.get(f"/v1/workspaces/{workspace_id}/lakehouses/{lakehouse_id}")
    responseJson = response.json()
    lakehouseName = responseJson['displayName']
    prop = responseJson['properties']
    oneLakeTP = prop['oneLakeTablesPath']
    oneLakeFP = prop['oneLakeFilesPath']
    sqlEPCS = prop['sqlEndpointProperties']['connectionString']
    sqlepid = prop['sqlEndpointProperties']['id']
    sqlepstatus = prop['sqlEndpointProperties']['provisioningStatus']

    new_data = {'Lakehouse Name': lakehouse, 'Lakehouse ID': lakehouse_id, 'Workspace Name': workspace, 'Workspace ID': workspace_id, 'OneLake Tables Path': oneLakeTP, 'OneLake Files Path': oneLakeFP, 'SQL Endpoint Connection String': sqlEPCS, 'SQL Endpoint ID': sqlepid, 'SQL Endpoint Provisioning Status': sqlepstatus}
    df = pd.concat([df, pd.DataFrame(new_data, index=[0])], ignore_index=True)

    return df

def get_shared_expression(lakehouse = None, workspace = None):

    """
    
    This function generates the shared expression statement for a given lakehouse and its SQL endpoint.

    Parameters:
        
        lakehouse: An optional parameter to set the lakehouse. This defaults to the lakehouse attached to the notebook.        
        workspace: An optional parameter to set the workspace in which the lakehouse resides. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns an M statement which can be used as the expression in the shared expression for a Direct Lake
        semantic model.

    """

    from .HelperFunctions import resolve_lakehouse_name

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)
    else:
        workspace_id = fabric.resolve_workspace_id(workspace)
    if lakehouse == None:
        lakehouse_id = fabric.get_lakehouse_id()
        lakehouse = resolve_lakehouse_name(lakehouse_id)

    lakeDetail = get_lakehouse_details(lakehouse,workspace)
    sqlEPCS = lakeDetail['SQL Endpoint Connection String'].iloc[0]
    sqlepid = lakeDetail['SQL Endpoint ID'].iloc[0]
    provStatus = lakeDetail['SQL Endpoint Provisioning Status'].iloc[0]

    if provStatus == 'InProgress':
        print(f"The SQL Endpoint for the '{lakehouse}' lakehouse within the '{workspace}' workspace has not yet been provisioned. Please wait until it has been provisioned.")
        return
    
    sh = 'let\n\tdatabase = Sql.Database("' + sqlEPCS + '", "' + sqlepid + '")\nin\n\tdatabase'

    return sh