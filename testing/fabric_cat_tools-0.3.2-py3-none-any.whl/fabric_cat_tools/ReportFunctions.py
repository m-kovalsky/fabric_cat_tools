import sempy
import sempy.fabric as fabric
import pandas as pd
import json, os, time, base64, copy, re
from anytree import Node, RenderTree
from powerbiclient import Report
from synapse.ml.services import Translate
from pyspark.sql.functions import col, flatten
from pyspark.sql import SparkSession

def get_report_json(report, workspace = None, save_to_file_name = None):

    """

    This function obtains the report.json file for a given Power BI report.

    Parameters:

        report: The report name.        
        workspace: An optional parameter to set the workspace in which report resides. This defaults to the
          workspace in which the notebook resides.
        save_to_file_name: Specifying this optional parameter will save the report.json file with the name of this parameter in the lakehouse attached to the notebook.

    Returns:

        The report.json file for a given Power BI report.
    """

    from .HelperFunctions import resolve_lakehouse_name
    from .Lakehouse import lakehouse_attached

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)
    else:
        workspace_id = fabric.resolve_workspace_id(workspace)    

    client = fabric.FabricRestClient()

    dfI = fabric.list_items(workspace = workspace)
    dfI_filt = dfI[(dfI['Display Name'] == report) & (dfI['Type'] == 'Report')]

    if len(dfI_filt) == 0:
        print(f"The '{report}' report does not exist in the '{workspace}' workspace.")
        return
    
    itemId = dfI_filt['Id'].iloc[0]
    response = client.post(f"/v1/workspaces/{workspace_id}/items/{itemId}/getDefinition")
    df_items = pd.json_normalize(response.json()['definition']['parts'])
    df_items_filt = df_items[df_items['path'] == 'report.json']
    payload = df_items_filt['payload'].iloc[0]

    reportFile = base64.b64decode(payload).decode('utf-8')
    reportJson = json.loads(reportFile)

    if save_to_file_name is not None:
        lakeAttach = lakehouse_attached()
        if lakeAttach == False:
            print(f"In order to save the report.json file, a lakehouse must be attached to the notebook. Please attach a lakehouse to this notebook.")
            return
        
        lakehouse_id = fabric.get_lakehouse_id()
        lakehouse = resolve_lakehouse_name(lakehouse_id, workspace)
        folderPath = '/lakehouse/default/Files'
        fileExt = '.json'
        if not save_to_file_name.endswith(fileExt):
            save_to_file_name = save_to_file_name + fileExt
        filePath = os.path.join(folderPath, save_to_file_name)
        with open(filePath, "w") as json_file:
            json.dump(reportJson, json_file, indent=4)
        print(f"The report.json file for the '{report}' report has been saved to the '{lakehouse}' in this location: '{filePath}'.\n\n")

    return reportJson

def report_dependency_tree(workspaceName = None):

    """

    This function shows the dependencies...

    Parameters:

        reportName: The report name.        
        workspaceName: An optional parameter to set the workspace in which report resides. This defaults to the
          workspace in which the notebook resides.

    Returns:

        The report.json file for a given Power BI report.

    """

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    
    dfR = fabric.list_reports(workspace = workspaceName)
    dfD = fabric.list_datasets(workspace = workspaceName)
    dfR = pd.merge(dfR, dfD[['Dataset ID', 'Dataset Name']], left_on = 'Dataset Id', right_on = 'Dataset ID', how = 'left')
    dfR.rename(columns={'Name': 'Report Name'}, inplace=True)
    dfR = dfR[['Report Name', 'Dataset Name']]

    report_icon = '\U0001F4F6'
    dataset_icon = '\U0001F9CA'
    workspace_icon = '\U0001F465'

    node_dict = {}
    rootNode = Node(workspaceName)
    node_dict[workspaceName] = rootNode
    rootNode.custom_property = workspace_icon + ' '

    for i, r in dfR.iterrows():
        datasetName = r['Dataset Name']
        reportName = r['Report Name']
        parentNode = node_dict.get(datasetName)
        if parentNode is None:
            parentNode = Node(datasetName, parent = rootNode)
            node_dict[datasetName] = parentNode
        parentNode.custom_property = dataset_icon + ' '

        child_node = Node(reportName, parent=parentNode)
        child_node.custom_property = report_icon + ' '

    # Print the tree structure
    for pre, _, node in RenderTree(node_dict[workspaceName]):
        print(f"{pre}{node.custom_property}'{node.name}'")

def export_report(report, export_format, file_name = None, bookmark_name = None, page_name = None, visual_name = None, report_filter = None, workspace = None):

    """

    This function exports a Power BI report to a file in a specified format and saves the file to the Fabric lakehouse.

    Parameters:

        report: The report name.     
        export_format: The format in which to export the report. See this link for valid formats: https://learn.microsoft.com/rest/api/power-bi/reports/export-to-file-in-group#fileformat. For image formats, enter the file extension in this parameter, not 'IMAGE'.
        file_name: An optional parameter to specify the file name of the export file (no need to include the file extension). Default value is the reportName parameter.        
        bookmark_name: An optional parameter to have the report export based on a bookmark from the report.
        page_name: An optional parameter to specify a report page (or pages).
        visual_name: An optional parameter to specify a visual.
        report_filter: An optional parameter to specify a report filter.
        workspace: An optional parameter to set the workspace in which report resides. This defaults to the workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of this operation.

    Examples:

        export_report(
            report = 'AdventureWorks'
            ,export_format = 'PDF'
            #,file_name = None
            #,bookmark_name = None
            #,page_name = None
            #,visual_name = None
            #,workspace = None
            )

        export_report(
            report = 'AdventureWorks'
            ,export_format = 'PDF'
            #,file_name = 'Exports\MyReport'
            #,bookmark_name = None
            #,page_name = 'ReportSection293847182375'
            #,visual_name = None
            #,workspace = None
            )

        export_report(
            report = 'AdventureWorks'
            ,export_format = 'PDF'
            #,page_name = 'ReportSection293847182375'
            #,report_filter = "'Product Category'[Color] = 'Blue'"
            #,workspace = None
            )

        export_report(
            report = 'AdventureWorks'
            ,export_format = 'PDF'
            #,page_name = 'ReportSection293847182375'
            #,report_filter = "'Product Category'[Color] in ('Blue', 'Orange') and 'Calendar'[CalendarYear] <= 2020"
            #,workspace = None
            )

    """

    #https://learn.microsoft.com/rest/api/power-bi/reports/export-to-file-in-group

    from .Lakehouse import lakehouse_attached

    lakeAttach = lakehouse_attached()

    if lakeAttach == False:
        print(f"In order to run the 'export_report' function, a lakehouse must be attached to the notebook. Please attach a lakehouse to this notebook.")
        return

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)
    else:
        workspace_id = fabric.resolve_workspace_id(workspace)

    if isinstance(page_name,str):
        page_name = [page_name]
    if isinstance(visual_name,str):
        visual_name = [visual_name]

    if bookmark_name is not None and (page_name is not None or visual_name is not None):
        print(f"If the 'bookmark_name' parameter is set, the 'page_name' and 'visual_name' parameters must not be set.")
        return
    if visual_name is not None and page_name is None:
        print(f"If the 'visual_name' parameter is set, the 'page_name' parameter must be set.")
        return

    validFormats = {
    'ACCESSIBLEPDF': '.pdf',
    'CSV': '.csv',
    'DOCX': '.docx',
    'MHTML': '.mhtml',
    'PDF': '.pdf',
    'PNG': '.png',
    'PPTX': '.pptx',
    'XLSX': '.xlsx',
    'XML': '.xml',
    'BMP': '.bmp',
    'EMF': '.emf',
    'GIF': '.gif',
    'JPEG': '.jpeg',
    'TIFF': '.tiff'
    }    
    
    export_format = export_format.upper()
    if export_format not in validFormats:
        print(f"The '{export_format}' format is not a valid format for exporting Power BI reports. Please enter a valid format. Options: {validFormats}")
        return

    fileExt = validFormats.get(export_format)

    if file_name == None:
        file_name = report + fileExt
    else:
        file_name = file_name + fileExt

    folderPath = '/lakehouse/default/Files'
    filePath = os.path.join(folderPath, file_name)

    dfI = fabric.list_items(workspace = workspace)
    dfI_filt = dfI[(dfI['Type'].isin(['Report', 'PaginatedReport'])) & (dfI['Display Name'] == report)]

    if len(dfI_filt) == 0:
        print(f"The '{report}' report does not exist in the '{workspace}' workspace.")
        return
    
    reportType = dfI_filt['Type'].iloc[0]

    # Limitations
    pbiOnly = ['PNG']
    paginatedOnly = ['ACCESSIBLEPDF','CSV','DOCX', 'BMP', 'EMF', 'GIF', 'JPEG', 'TIFF', 'MHTML', 'XLSX', 'XML']

    if reportType == 'Report' and export_format in paginatedOnly:
        print(f"The '{export_format}' format is only supported for paginated reports.")
        return
    if reportType == 'PaginatedReport' and export_format in pbiOnly:
        print(f"The '{export_format}' format is only supported for Power BI reports.")
        return
    
    if reportType == 'PaginatedReport' and (bookmark_name is not None or page_name is not None or visual_name is not None):
        print(f"Export for paginated reports does not support bookmarks/pages/visuals. Those parameters must not be set for paginated reports.")
        return
    
    reportId = dfI_filt['Id'].iloc[0]
    client = fabric.PowerBIRestClient()

    dfVisual = list_report_visuals(report = report, workspace = workspace)
    dfPage = list_report_pages(report = report, workspace = workspace)

    if export_format in ['BMP', 'EMF', 'GIF', 'JPEG', 'TIFF'] and reportType == 'PaginatedReport':
        request_body = {
                'format': 'IMAGE',
                'paginatedReportConfiguration': {
                    'formatSettings': {
                        'OutputFormat': export_format.lower()
                    }
                }
        }
    elif bookmark_name is None and page_name is None and visual_name is None:
        request_body = {
                'format': export_format
            }
    elif bookmark_name is not None:
        if reportType == 'Report':
            request_body = {
                    'format': export_format,
                    'powerBIReportConfiguration': {
                        'defaultBookmark': {
                            'name': bookmark_name
                        }
                    }
            }
    elif page_name is not None and visual_name is None:
        if reportType == 'Report':
            request_body = {
                    'format': export_format,
                    'powerBIReportConfiguration': {
                    }
            }

            request_body['powerBIReportConfiguration']['pages'] = []

            for page in page_name:
                dfPage_filt = dfPage[dfPage['Page ID'] == page]
                if len(dfPage_filt) == 0:
                    print(f"The '{page}' page does not exist in the '{report}' report within the '{workspace}' workspace.")
                    return
                page_dict = {'pageName': page}
                request_body['powerBIReportConfiguration']['pages'].append(page_dict)

    elif page_name is not None and visual_name is not None:
        if len(page_name) != len(visual_name):
            print(f"Each visual must map to a single page name.")
            return
        if reportType == 'Report':
            request_body = {
                    'format': export_format,
                    'powerBIReportConfiguration': {
                    }
            }

            request_body['powerBIReportConfiguration']['pages'] = []
            a=0
            for page in page_name:
                visual = visual_name[a]
                dfVisual_filt = dfVisual[(dfVisual['Page ID'] == page) & (dfVisual['Visual ID'] == visual)]
                if len(dfVisual_filt) == 0:
                    print(f"The '{visual}' visual does not exist on the '{page}' in the '{report}' report within the '{workspace}' workspace.")
                    return
                page_dict = {'pageName': page,'visualName': visual}
                request_body['powerBIReportConfiguration']['pages'].append(page_dict)
                a+=1

    # Transform and add report filter if it is specified
    if report_filter is not None and reportType == 'Report':
        pattern = r"'[^']+'\[[^\[]+\]"
        matches = re.findall(pattern, report_filter)
        for match in matches:
            matchReplace = match.replace("'",'').replace('[','/').replace(']','')\
            .replace(' ','_x0020_').replace('@','_00x40_').replace('+','_0x2B_').replace('{','_007B_').replace('}','_007D_')
            report_filter = report_filter.replace(match, matchReplace)
        
        pattern = r"\[[^\[]+\]"
        matches = re.findall(pattern, report_filter)
        for match in matches:
            matchReplace = match.replace("'",'').replace('[','/').replace(']','')\
            .replace(' ','_x0020_').replace('@','_00x40_').replace('+','_0x2B_').replace('{','_007B_').replace('}','_007D_')
            report_filter = report_filter.replace(match, matchReplace)

        reportFilter = report_filter.replace('<=','le').replace('>=','ge').replace('<>','ne').replace('!=','ne')\
            .replace('==','eq').replace('=','eq').replace('<','lt').replace('>','gt')\
            .replace(' && ',' and ').replace(' & ',' and ')\
            .replace(' || ',' or ').replace(' | ',' or ')\
            .replace('{','(').replace('}',')')
        report_level_filter = {'filter': reportFilter}

        if 'powerBIReportConfiguration' not in request_body:            
            request_body['powerBIReportConfiguration'] = {}
        request_body['powerBIReportConfiguration']['reportLevelFilters'] = [report_level_filter]
    print(request_body)
    response = client.post(f"/v1.0/myorg/groups/{workspace_id}/reports/{reportId}/ExportTo",json=request_body)
    if response.status_code == 202:
        response_body = json.loads(response.content)
        exportId = response_body['id']
        response = client.get(f"/v1.0/myorg/groups/{workspace_id}/reports/{reportId}/exports/{exportId}")
        response_body = json.loads(response.content)
        while response_body['status'] not in ['Succeeded', 'Failed']:
            time.sleep(3)
            response = client.get(f"/v1.0/myorg/groups/{workspace_id}/reports/{reportId}/exports/{exportId}")
            response_body = json.loads(response.content)
        if response_body['status'] == 'Failed':
            print(f"The export for the '{report}' report within the '{workspace}' workspace in the '{export_format}' format has failed.")
        else:
            response = client.get(f"/v1.0/myorg/groups/{workspace_id}/reports/{reportId}/exports/{exportId}/file")
            print(f"Saving the '{export_format}' export for the '{report}' report within the '{workspace}' workspace to the lakehouse...")
            with open(filePath, "wb") as export_file:
                export_file.write(response.content)
            print(f"The '{export_format}' export for the '{report}' report within the '{workspace}' workspace has been saved to the following location: '{filePath}'.")


def clone_report(report, cloned_report, workspace = None, target_workspace = None, target_dataset = None):

    """

    This function clones a Power BI report.

    Parameters:

        report: The name of the report to be cloned.
        cloned_report: The name of the new report.         
        workspace: An optional parameter to set the workspace in which report resides. This defaults to the workspace in which the notebook resides.
        target_workspace: An optional parameter to set the target workspace in which the cloned report will reside. This defaults to the workspace in which the notebook resides.
        target_dataset: An optional parameter to set the target dataset from which the cloned report will be fed. This defaults to the dataset used by the original report.

    Returns:

        This function returns a printout stating the success/failure of this operation.

    Examples:

        clone_report(
            report = 'MyReport'
            ,cloned_report = 'MyNewReport'
            #,workspace = None
            #,target_workspace = None
            #,target_dataset = None
            )

        clone_report(
            report = 'MyReport'
            ,cloned_report = 'MyNewReport'
            #,workspace = None
            #,target_workspace = 'Other workspace'
            #,target_dataset = 'AdventureWorks'
            )

    """

    #https://learn.microsoft.com/rest/api/power-bi/reports/clone-report-in-group

    from .HelperFunctions import resolve_dataset_name
    from .HelperFunctions import resolve_report_id

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)
    else:
        workspace_id = fabric.resolve_workspace_id(workspace)

    dfI = fabric.list_items(workspace = workspace)
    dfI_filt = dfI[(dfI['Type'] == 'Report') & (dfI['Display Name'] == report)]    

    if len(dfI_filt) == 0:
        print(f"The '{report}' report does not exist within the '{workspace}' workspace.")
        return
    
    reportId = resolve_report_id(report, workspace)

    if target_workspace is None:
        target_workspace = workspace
        target_workspace_id = workspace_id
    else:
        dfW = fabric.list_workspaces()
        dfW_filt = dfW[dfW['Name'] == target_workspace]

        if len(dfW_filt) == 0:
            print(f"The '{workspace}' is not a valid workspace.")
            return
        target_workspace_id = dfW_filt['Id'].iloc[0]
    
    if target_dataset == None:
        dfR = fabric.list_reports(workspace = target_workspace)
        dfR_filt = dfR[dfR['Name'] == report]
        target_dataset_id = dfR_filt['Dataset Id'].iloc[0]
        target_dataset = resolve_dataset_name(dataset_id = target_dataset_id, workspace = target_workspace)
    else:
        dfD = fabric.list_datasets(workspace = target_workspace)
        dfD_filt = dfD[dfD['Dataset Name'] == target_dataset]

        if len(dfD_filt) == 0:
            print(f"The '{target_dataset}' target dataset does not exist in the '{target_workspace}' workspace.")
            return        
        target_dataset_id = dfD_filt['Dataset Id'].iloc[0]

    client = fabric.PowerBIRestClient()

    if target_workspace is None and target_dataset is None:
        request_body = {
            "name": cloned_report
        }
    elif target_workspace is not None and target_dataset is None:
        request_body = {
            "name": cloned_report,
            "targetWorkspaceId": target_workspace_id
        }
    elif target_workspace is not None and target_dataset is not None:
        request_body = {
            "name": cloned_report,
            "targetModelId": target_dataset_id,
            "targetWorkspaceId": target_workspace_id
        }
    elif target_workspace is None and target_dataset is not None:
        request_body = {
            "name": cloned_report,
            "targetModelId": target_dataset_id
        }

    response = client.post(f"/v1.0/myorg/groups/{workspace_id}/reports/{reportId}/Clone",json=request_body)

    if response.status_code == 200:
        print(f"The '{report}' report has been successfully cloned as the '{cloned_report}' report within the '{target_workspace}' workspace using the '{target_dataset}' semantic model.")
    else:
        print(f"POST request failed with status code: {response.status_code}")

def launch_report(report, workspace = None):

    """

    This function displays a Power BI report within a notebook.

    Parameters:

        report: The name of the report.        
        workspace: An optional parameter to set the workspace in which report resides. This defaults to the workspace in which the notebook resides.

    Returns:

        This function returns a display of a Power BI report.

    Examples:

        launch_report(
            report = 'MyReport'
            #,workspace = ''
            )

    """

    from .HelperFunctions import resolve_report_id

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)
    else:
        workspace_id = fabric.resolve_workspace_id(workspace)

    reportId = resolve_report_id(report, workspace)

    report = Report(group_id=workspace_id, report_id=reportId)

    return report

def list_report_pages(report, workspace = None):

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)

    df = pd.DataFrame(columns=['Page ID', 'Page Name', 'Hidden', 'Width', 'Height', 'Visual Count'])

    reportJson = get_report_json(report = report, workspace = workspace)

    for section in reportJson['sections']:
        pageID = section['name']
        pageName = section['displayName']
        #pageFilters = section['filters']
        pageWidth = section['width']
        pageHeight = section['height']
        visualCount = len(section['visualContainers'])
        pageHidden = False
        pageConfig = section['config']
        pageConfigJson = json.loads(pageConfig)

        try:
            pageH = pageConfigJson['visibility']
            if pageH == 1:
                pageHidden = True
        except:
            pass

        new_data = {'Page ID': pageID, 'Page Name': pageName, 'Hidden': pageHidden, 'Width': pageWidth, 'Height': pageHeight, 'Visual Count': visualCount}
        df = pd.concat([df, pd.DataFrame(new_data, index=[0])], ignore_index=True)

    df['Hidden'] = df['Hidden'].astype(bool)
    intCol = ['Width', 'Height', 'Visual Count']
    df[intCol] = df[intCol].astype(int)

    return df

def list_report_visuals(report, workspace = None):

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)

    reportJson = get_report_json(report = report, workspace = workspace)

    df = pd.DataFrame(columns=['Page Name', 'Page ID', 'Visual ID', 'Title'])

    for section in reportJson['sections']:
        pageID = section['name']
        pageName = section['displayName']

        for visual in section['visualContainers']:
            visualConfig = visual['config']
            visualConfigJson = json.loads(visualConfig)
            visualID = visualConfigJson['name']            

            try:
                title = visualConfigJson["singleVisual"]["vcObjects"]["title"][0]["properties"]["text"]["expr"]["Literal"]["Value"]
                title = title[1:-1]
            except:
                title = ''

            new_data = {'Page Name': pageName, 'Page ID': pageID, 'Visual ID': visualID, 'Title': title}
            df = pd.concat([df, pd.DataFrame(new_data, index=[0])], ignore_index=True)
    
    return df

def translate_report_titles(report, languages, workspace = None):

    from .GenerateReport import update_report_from_reportjson
    from .Translations import language_validate

    if isinstance(languages, str):
        languages = [languages]

    for lang in languages:
        language_validate(lang)

    reportJson = get_report_json(report = report, workspace = workspace)
    dfV = list_report_visuals(report = report, workspace = workspace)
    spark = SparkSession.builder.getOrCreate()
    df = spark.createDataFrame(dfV)
    columnToTranslate = 'Title'

    translate = (
        Translate()
        .setTextCol(columnToTranslate)
        .setToLanguage(languages)
        .setOutputCol("translation")
        .setConcurrency(5)
    )

    transDF = (translate
      .transform(df)
      .withColumn("translation", flatten(col("translation.translations")))
      .withColumn("translation", col("translation.text"))
      .select('Visual ID', columnToTranslate, 'translation'))

    df_panda = transDF.toPandas()

    i=0
    for lang in languages:
        #Clone report
        language = language_validate(lang)
        clonedReportName = f"{report}_{language}"

        dfRep = fabric.list_reports(workspace = workspace)
        dfRep_filt = dfRep[(dfRep['Name'] == clonedReportName) & (dfRep['Report Type'] == 'PowerBIReport')]

        if len(dfRep_filt) > 0:
            print(f"The '{clonedReportName}' report already exists in the '{workspace} workspace.")
        else:
            clone_report(report = report, cloned_report = clonedReportName, workspace = workspace)
            print(f"The '{clonedReportName}' report has been created via clone in the '{workspace} workspace.")

        rptJsonTr = copy.deepcopy(reportJson)

        # Update report json file
        for section in rptJsonTr['sections']:
            for visual in section['visualContainers']:
                visualConfig = visual['config']
                visualConfigJson = json.loads(visualConfig)  
                visualID = visualConfigJson['name']

                df_filt = df_panda[(df_panda['Visual ID'] == visualID) & (df_panda['Title'] != '')]

                if len(df_filt) == 1:
                    tr = df_filt['translation'].str[i].iloc[0]
                    if len(tr) > 0:
                        prop = visualConfigJson["singleVisual"]["vcObjects"]["title"][0]["properties"]["text"]["expr"]["Literal"]
                        prop['Value'] = f"'{tr}'"

                visual['config'] = json.dumps(visualConfigJson)

        i+=1

        # Post updated report json file to cloned report
        update_report_from_reportjson(report = clonedReportName, report_json = rptJsonTr, workspace = workspace)
        print(f"The visual titles within the '{clonedReportName}' report within the '{workspace}' have been translated into '{language}' accordingly.")





  