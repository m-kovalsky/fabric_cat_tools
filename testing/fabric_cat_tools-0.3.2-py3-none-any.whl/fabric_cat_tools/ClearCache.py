import sempy
import sempy.fabric as fabric

def clear_cache(dataset, workspace = None):

    """
    
    This function clears the cache of a semantic model.

    Parameters:
        
        dataset: This is name of the semantic model.
        workspace: An optional parameter to set the workspace where the semantic model resides. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of the operation.
    """

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)

    dfD = fabric.list_datasets(workspace = workspace)
    dfD_filt = dfD[dfD['Dataset Name'] == dataset]

    if len(dfD_filt) == 0:
        print(f"The '{dataset}' semantic model does not exist in the '{workspace}' workspace.")
        return

    datasetID = dfD_filt["Dataset ID"].iloc[0]
    xmla = f"""
            <ClearCache xmlns="http://schemas.microsoft.com/analysisservices/2003/engine">  
                <Object>  
                    <DatabaseID>{datasetID}</DatabaseID>  
                </Object>  
            </ClearCache>
            """
    fabric.execute_xmla(dataset = dataset,xmla_command=xmla, workspace = workspace)

    outputtext = f"Cache cleared for the '{dataset}' semantic model within the '{workspace}' workspace."
    
    return outputtext