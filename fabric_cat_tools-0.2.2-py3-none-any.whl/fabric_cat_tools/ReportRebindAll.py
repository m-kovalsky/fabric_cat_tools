import sempy
import sempy.fabric as fabric

def report_rebind_all(datasetName, newDatasetName, workspaceName = None):

    """
    
    This function rebinds all reports which are bound to a specific semantic model to a different semantic model.

    Parameters:

        datasetName: The old semantic model name.
        newDatasetName: The new semantic model name.
        workspaceName: An optional parameter to set the workspace in which the reports and semantic models reside. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of this operation.
    """

    from .ReportRebind import report_rebind
    from .HelperFunctions import resolve_dataset_id

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)
    
    datasetId = resolve_dataset_id(datasetName, workspaceName)

    dfRep = fabric.list_reports(workspace = workspaceName)
    dfRep_filt = dfRep[dfRep['Dataset Id'] == datasetId]

    for i, r in dfRep_filt.iterrows():
        rptName = r['Name']
        report_rebind(rptName, newDatasetName, workspaceName)

