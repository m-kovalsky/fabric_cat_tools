import sempy
import sempy.fabric as fabric
import pandas as pd

def show_unsupported_direct_lake_objects(datasetName, workspaceName = None):

    """
    
    This function shows dataframes stating objects in the semantic model which are unsupported by Direct Lake mode.

    Learn more here: https://learn.microsoft.com/power-bi/enterprise/directlake-overview#known-issues-and-limitations")

    Parameters:

        datasetName: The semantic model name.
        workspaceName: An optional parameter to set the workspace where the semantic model resides. This defaults to the
          workspace in which the notebook resides.

    Returns:
    
        Calculated tables
        Calculated columns
        Columns of binary data type
        Relationships using columns with a data type of 'DateTime'
        Relationships using columns with different data types
    """

    from .ListFunctions import list_tables
    from .HelperFunctions import create_daxfullobjectname
    from .ListFunctions import list_tables

    pd.options.mode.chained_assignment = None

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)

    dfT = list_tables(datasetName, workspaceName)
    dfC = fabric.list_columns(dataset = datasetName, workspace = workspaceName)
    dfR = fabric.list_relationships(dataset = datasetName, workspace = workspaceName)

    # Calc tables
    dfT_filt = dfT[dfT['Type'] == 'Calculated Table']
    dfT_filt.rename(columns={'Name': 'Table Name'}, inplace=True)
    t = dfT_filt[['Table Name', 'Type']]

    # Calc columns
    dfC_filt = dfC[(dfC['Type'] == 'Calculated') | (dfC['Data Type'] == 'Binary')]
    c = dfC_filt[['Table Name', 'Column Name', 'Type', 'Data Type', 'Source']]

    # Relationships
    dfC['Column Object'] = create_daxfullobjectname(dfC['Table Name'], dfC['Column Name'])
    dfR['From Object'] = create_daxfullobjectname(dfR['From Table'], dfR['From Column'])
    dfR['To Object'] = create_daxfullobjectname(dfR['To Table'], dfR['To Column'])
    merged_from = pd.merge(dfR, dfC, left_on='From Object', right_on='Column Object', how='left')
    merged_to = pd.merge(dfR, dfC, left_on='To Object', right_on='Column Object', how='left')

    dfR['From Column Data Type'] = merged_from['Data Type']
    dfR['To Column Data Type'] = merged_to['Data Type']

    dfR_filt = dfR[((dfR['From Column Data Type'] == 'DateTime') | (dfR['To Column Data Type'] == 'DateTime')) | (dfR['From Column Data Type'] != dfR['To Column Data Type'])]
    r = dfR_filt[['From Table', 'From Column', 'To Table', 'To Column', 'From Column Data Type', 'To Column Data Type']]

    print('Calculated Tables are not supported...')
    display(t)
    print("Learn more about Direct Lake limitations here: https://learn.microsoft.com/power-bi/enterprise/directlake-overview#known-issues-and-limitations")
    print('Calculated columns are not supported. Columns of binary data type are not supported.')
    display(c)
    print('Columns used for relationship cannot be of data type datetime and they also must be of the same data type.')
    display(r)