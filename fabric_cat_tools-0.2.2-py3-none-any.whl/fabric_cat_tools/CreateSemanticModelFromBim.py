import sempy
import sempy.fabric as fabric
import json
import pandas as pd
import base64
import time

def create_semantic_model_from_bim(datasetName, bimFile, workspaceName = None):

    """

    This function deploys a Model.bim file to create a new semantic model in a workspace.

    Note: Make sure to set the data source credentials within the dataset settings in order for the data source credentials to populate properly

    Parameters:

        datasetName: The name of the semantic model to be created.
        bimFile: A model.bim file for a semantic model. Use the get_semantic_model_bim to obtain the Model.bim file for a semantic model in a Fabric workspace.
        workspaceName: An optional parameter to set the workspace in which the semantic model will be created. This defaults to the
          workspace in which the notebook resides.

    Returns:

        This function returns a printout stating the success/failure of the operation.

    """

    if workspaceName == None:
        workspaceId = fabric.get_workspace_id()
        workspaceName = fabric.resolve_workspace_name(workspaceId)
    else:
        workspaceId = fabric.resolve_workspace_id(workspaceName)

    objectType = 'SemanticModel'

    dfI = fabric.list_items(workspace = workspaceName)
    dfI_filt = dfI[(dfI['Display Name'] == datasetName) & (dfI['Type'] == objectType)]

    if len(dfI_filt) > 0:
        print(f"WARNING: '{datasetName}' already exists as a semantic model in the '{workspaceName}' workspace.")
        return

    client = fabric.FabricRestClient()
    defPBIDataset = {
    "version": "1.0",
    "settings": {}
    }

    def conv_b64(file):
        
        loadJson = json.dumps(file)
        f = base64.b64encode(loadJson.encode('utf-8')).decode('utf-8')
        
        return f

    payloadPBIDefinition = conv_b64(defPBIDataset)
    payloadBim = conv_b64(bimFile)

    request_body = {
            'displayName': datasetName,
            'type': objectType,
            'definition': {
        "parts": [
            {
                "path": "model.bim",
                "payload": payloadBim,
                "payloadType": "InlineBase64"
            },
            {
                "path": "definition.pbidataset",
                "payload": payloadPBIDefinition,
                "payloadType": "InlineBase64"
            }
        ]

            }
        }

    response = client.post(f"/v1/workspaces/{workspaceId}/items",json=request_body)

    if response.status_code == 201:
        print('Model creation succeeded')
        print(response.json())
    elif response.status_code == 202:
        location_url = response.headers['Location']
        operationId = response.headers['x-ms-operation-id']
        response = client.get(f"/v1/operations/{operationId}")
        response_body = json.loads(response.content) 
        while response_body['status'] != 'Succeeded':
            time.sleep(3)
            response = client.get(f"/v1/operations/{operationId}")
            response_body = json.loads(response.content)
        response = client.get(f"/v1/operations/{operationId}/result")
        print('Model creation succeeded')
        print(response.json())