import sempy
import sempy.fabric as fabric
import re

def create_abfss_path(lakehouse_id, lakehouse_workspace_id, delta_table_name):

    """
    
    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#create_abfss_path

    """

    return f"abfss://{lakehouse_workspace_id}@onelake.dfs.fabric.microsoft.com/{lakehouse_id}/Tables/{delta_table_name}"

def format_dax_object_name(a,b):
    
    return "'" + a + "'[" + b + "]"

def create_relationship_name(from_table, from_column, to_table, to_column):

    return format_dax_object_name(from_table, from_column) + ' -> ' + format_dax_object_name(to_table, to_column)

def resolve_report_id(report, workspace = None):

    """
    
    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#resolve_report_id

    """
    
    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)

    objectType = 'Report'
    dfI = fabric.list_items(workspace = workspace)
    dfI_filt = dfI[(dfI['Display Name'] == report) & (dfI['Type'] == objectType)]
    obj = dfI_filt['Id'].iloc[0]

    return obj

def resolve_report_name(report_id, workspace = None):

    """
    
    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#resolve_report_name

    """
    
    
    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)

    objectType = 'Report'
    dfI = fabric.list_items(workspace = workspace)
    dfI_filt = dfI[(dfI['Id'] == report_id) & (dfI['Type'] == objectType)]
    obj = dfI_filt['Display Name'].iloc[0]

    return obj

def resolve_dataset_id(dataset, workspace = None):

    """
    
    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#resolve_dataset_id

    """
    
    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)

    objectType = 'SemanticModel'
    dfI = fabric.list_items(workspace = workspace)
    dfI_filt = dfI[(dfI['Display Name'] == dataset) & (dfI['Type'] == objectType)]
    obj = dfI_filt['Id'].iloc[0]

    return obj

def resolve_dataset_name(dataset_id, workspace = None):

    """
    
    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#resolve_dataset_name

    """
    
    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)

    objectType = 'SemanticModel'
    dfI = fabric.list_items(workspace = workspace)
    dfI_filt = dfI[(dfI['Id'] == dataset_id) & (dfI['Type'] == objectType)]
    obj = dfI_filt['Display Name'].iloc[0]

    return obj

def resolve_lakehouse_name(lakehouse_id, workspace = None):

    """
    
    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#resolve_lakehouse_name

    """
    
    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)

    objectType = 'Lakehouse'
    dfI = fabric.list_items(workspace = workspace)
    dfI_filt = dfI[(dfI['Id'] == lakehouse_id) & (dfI['Type'] == objectType)]

    if len(dfI_filt) == 0:
        print(f"The '{lakehouse_id}' Lakehouse Id does not exist within the '{workspace}' workspace.")
        return
    
    obj = dfI_filt['Display Name'].iloc[0]

    return obj

def resolve_lakehouse_id(lakehouse, workspace = None):

    """
    
    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#resolve_lakehouse_id

    """
    
    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)

    objectType = 'Lakehouse'    
    dfI = fabric.list_items(workspace = workspace)
    dfI_filt = dfI[(dfI['Display Name'] == lakehouse) & (dfI['Type'] == objectType)]

    if len(dfI_filt) == 0:
        print(f"The '{lakehouse}' lakehouse does not exist within the '{workspace}' workspace.")
        return
    
    obj = dfI_filt['Id'].iloc[0]

    return obj

def get_direct_lake_sql_endpoint(dataset, workspace = None):

    """
    
    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#get_direct_lake_sql_endpoint

    """

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)

    dfP = fabric.list_partitions(dataset = dataset, workspace = workspace)
    dfP_filt = dfP[dfP['Mode'] == 'DirectLake']

    if len(dfP_filt) == 0:
        print(f"The '{dataset}' semantic model in the '{workspace}' workspace is not in Direct Lake mode.")
        return
    
    dfE = fabric.list_expressions(dataset = dataset, workspace = workspace)
    dfE_filt = dfE[dfE['Name']== 'DatabaseQuery']
    expr = dfE_filt['Expression'].iloc[0]

    matches = re.findall(r'"([^"]*)"', expr)
    sqlEndpointId = matches[1]
    
    return sqlEndpointId

def generate_embedded_filter(filter):

    """
    
    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#generate_embedded_filter

    """

    pattern = r"'[^']+'\[[^\[]+\]"
    matches = re.findall(pattern, filter)
    for match in matches:
        matchReplace = match.replace("'",'').replace('[','/').replace(']','')\
        .replace(' ','_x0020_').replace('@','_00x40_').replace('+','_0x2B_').replace('{','_007B_').replace('}','_007D_')
        filter = filter.replace(match, matchReplace)
    
    pattern = r"\[[^\[]+\]"
    matches = re.findall(pattern, filter)
    for match in matches:
        matchReplace = match.replace("'",'').replace('[','/').replace(']','')\
        .replace(' ','_x0020_').replace('@','_00x40_').replace('+','_0x2B_').replace('{','_007B_').replace('}','_007D_')
        filter = filter.replace(match, matchReplace)

    revised_filter = filter.replace('<=','le').replace('>=','ge').replace('<>','ne').replace('!=','ne')\
            .replace('==','eq').replace('=','eq').replace('<','lt').replace('>','gt')\
            .replace(' && ',' and ').replace(' & ',' and ')\
            .replace(' || ',' or ').replace(' | ',' or ')\
            .replace('{','(').replace('}',')')
    
    return revised_filter