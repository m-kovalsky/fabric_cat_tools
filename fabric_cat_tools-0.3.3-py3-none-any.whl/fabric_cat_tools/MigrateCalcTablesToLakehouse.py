import sempy
import sempy.fabric as fabric
import pandas as pd
import re
sempy.fabric._client._utils._init_analysis_services()
import Microsoft.AnalysisServices.Tabular as TOM
from pyspark.sql import SparkSession

def migrate_calc_tables_to_lakehouse(dataset, new_dataset, workspace = None, new_dataset_workspace = None, lakehouse = None, lakehouse_workspace = None):

    """
    
    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#migrate_calc_tables_to_lakehouse

    """

    from .GetLakehouseTables import get_lakehouse_tables
    from .HelperFunctions import resolve_lakehouse_name
    from .HelperFunctions import resolve_lakehouse_id
    from .HelperFunctions import create_abfss_path

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)
    else:
        workspace_id = fabric.resolve_workspace_id(workspace)

    if new_dataset_workspace == None:
        new_dataset_workspace = workspace

    if lakehouse_workspace == None:
        lakehouse_workspace = new_dataset_workspace
        lakehouse_workspace_id = fabric.resolve_workspace_id(lakehouse_workspace)
    else:
        lakehouse_workspace_id = fabric.resolve_workspace_id(lakehouse_workspace)

    if lakehouse == None:
        lakehouse_id = fabric.get_lakehouse_id()
        lakehouse = resolve_lakehouse_name(lakehouse_id, lakehouse_workspace)
    else:
        lakehouse_id = resolve_lakehouse_id(lakehouse, lakehouse_workspace)    

    dfC = fabric.list_columns(dataset = dataset, workspace = workspace)
    #dfC['Column Object'] = "'" + dfC['Table Name'] + "'[" + dfC['Column Name'] + "]"
    dfP = fabric.list_partitions(dataset = dataset, workspace = workspace)
    dfP_filt = dfP[(dfP['Source Type'] == 'Calculated')]
    dfP_filt = dfP_filt[~dfP_filt['Query'].str.contains('NAMEOF')] #Remove field parameters
    #dfC_CalcColumn = dfC[dfC['Type'] == 'Calculated']
    lakeTables = get_lakehouse_tables(lakehouse, lakehouse_workspace)

    # Do not execute the function if lakehouse tables already exist with the same name
    killFunction = False
    for i, r in dfP_filt.iterrows():
        tName = r['Table Name']
        dtName = tName.replace(' ', '_')        

        if dtName in lakeTables['Table Name'].values:
            print(f"ERROR: The '{tName}' table already exists as '{dtName}' in the '{lakehouse}' lakehouse in the '{workspace}' workspace.")
            killFunction = True
        
    if killFunction:
        return

    spark = SparkSession.builder.getOrCreate()

    if len(dfP_filt) == 0:
        print(f"The '{dataset}' semantic model in the '{workspace}' workspace has no calculated tables.")
        return

    tom_server = fabric.create_tom_server(readonly=False, workspace=new_dataset_workspace)    

    for i,r in dfP_filt.iterrows():
        tName = r['Table Name']
        query = r['Query']

        daxquery = 'EVALUATE \nTOPN(1,\n' + query + '\n)' # Only take 1 row to establish the table structure

        try:
            df = fabric.evaluate_dax(dataset = dataset, dax_string = daxquery, workspace = workspace)

            for old_column_name in df.columns:
                pattern = r"\[([^\]]+)\]"
                
                matches = re.findall(pattern, old_column_name) 
                new_column_name = matches[0]
                new_column_name = new_column_name.replace(' ','')
            
                df.rename(columns={old_column_name: new_column_name}, inplace=True)

                # Update data types for lakehouse columns
                dfC_type = dfC[(dfC['Table Name'] == tName) & (dfC['Source'] == old_column_name)]
                dataType = dfC_type['Data Type'].iloc[0]
                                    
                if dataType == 'Int64':
                    df[new_column_name] = df[new_column_name].astype(int)
                elif dataType in ['Decimal', 'Double']:
                    df[new_column_name] = df[new_column_name].astype(float)
                elif dataType == 'Boolean':
                    df[new_column_name] = df[new_column_name].astype(bool)
                elif dataType == 'DateTime':
                    df[new_column_name] = pd.to_datetime(df[new_column_name])

            delta_table_name = tName.replace(' ','_')

            spark_df = spark.createDataFrame(df)
            #spark_df.write.mode('overwrite').format('delta').saveAsTable(delta_table_name)
            filePath = create_abfss_path(lakehouse_id = lakehouse_id, lakehouse_workspace_id = lakehouse_workspace_id, delta_table_name = delta_table_name)
            spark_df.write.mode('overwrite').format('delta').save(filePath)

            # Set annotations on the model for each calc table with their source expression
            m = tom_server.Databases.GetByName(new_dataset).Model

            ann = TOM.Annotation()
            ann.Name = tName
            ann.Value = query

            try:
                if not any(existing_ann.Name == tName for existing_ann in m.Annotations):
                    m.Annotations.Add(ann)
                    print(f"Model annotation for the '{tName}' table and its expression has been added.")
                else:
                    m.Annotations[tName].Value = query
                    print(f"Model annotation for the '{tName}' table and its expression has been updated.")
            except:
                print(f"ERROR: Model annotation for the '{tName}' table was not added.")
            m.SaveChanges()

            print(f"Calculated table '{tName}' has been created as delta table '{delta_table_name.lower()}' in the '{lakehouse}' lakehouse within the '{lakehouse_workspace}' workspace.")
        except:
            print(f"Failed to create calculated table '{tName}' as a delta table in the lakehouse.")

def migrate_field_parameters(dataset, new_dataset, workspace = None, new_dataset_workspace = None):

    """
    
    This function migrates field parameters from one semantic model to another.

    Parameters:

        dataset: The original semantic model name.
        new_dataset: The new semantic model name.
        workspace: An optional parameter to set the workspace where the original semantic model exists. This defaults to the
          workspace in which the notebook resides.
        new_dataset_workspace: An optional parameter to set the workspace where the new semantic model resides. This defaults to thes same workspace as the original semantic model.

    Returns:

        This function returns a printout stating the success/failure of this operation.
    """

    from .HelperFunctions import format_dax_object_name

    if workspace == None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)

    if new_dataset_workspace == None:
        new_dataset_workspace = workspace

    dfC = fabric.list_columns(dataset = dataset, workspace = workspace)
    dfC['Column Object'] = format_dax_object_name(dfC['Table Name'], dfC['Column Name'])
    dfP = fabric.list_partitions(dataset = dataset, workspace = workspace)
    dfP_filt = dfP[(dfP['Source Type'] == 'Calculated')]
    dfP_filt = dfP_filt[dfP_filt['Query'].str.contains('NAMEOF')] # Only field parameters
    dfC_CalcColumn = dfC[dfC['Type'] == 'Calculated']

    if len(dfP_filt) == 0:
        print(f"The '{dataset}' semantic model in the '{workspace}' workspace has no field parameters.")
        return
    
    tom_server = fabric.create_tom_server(readonly=False, workspace=new_dataset_workspace)
    m = tom_server.Databases.GetByName(new_dataset).Model
    
    for i,r in dfP_filt.iterrows():
        tName = r['Table Name']
        query = r['Query']

        # For field parameters, remove calc columns from the query
        rows = query.strip().split('\n')
        filtered_rows = [row for row in rows if not any(value in row for value in dfC_CalcColumn['Column Object'].values)]
        updated_query_string = '\n'.join(filtered_rows)

        # Remove extra comma
        lines = updated_query_string.strip().split('\n')
        lines[-2] = lines[-2].rstrip(',')
        expr = '\n'.join(lines)

        try:
            par = TOM.Partition()
            par.Name = tName

            parSource = TOM.CalculatedPartitionSource()
            par.Source = parSource
            parSource.Expression = expr

            tbl = TOM.Table()
            tbl.Name = tName
            tbl.Partitions.Add(par)            

            columns = ['Value1', 'Value2', 'Value3']

            for colName in columns:
                col = TOM.CalculatedTableColumn()
                col.Name = colName
                col.SourceColumn = '[' + colName + ']'
                col.DataType = TOM.DataType.String

                tbl.Columns.Add(col)

            m.Tables.Add(tbl)

            m.SaveChanges()

            ep = TOM.JsonExtendedProperty()
            ep.Name = 'ParameterMetadata'
            ep.Value = '{"version":3,"kind":2}'

            rcd = TOM.RelatedColumnDetails()
            gpc = TOM.GroupByColumn()
            gpc.GroupingColumn = m.Tables[tName].Columns['Value2']
            rcd.GroupByColumns.Add(gpc)
            
            # Update column properties
            m.Tables[tName].Columns['Value2'].IsHidden = True
            m.Tables[tName].Columns['Value3'].IsHidden = True
            m.Tables[tName].Columns['Value3'].DataType = TOM.DataType.Int64
            m.Tables[tName].Columns['Value1'].SortByColumn = m.Tables[tName].Columns['Value3']
            m.Tables[tName].Columns['Value2'].SortByColumn = m.Tables[tName].Columns['Value3']
            m.Tables[tName].Columns['Value2'].ExtendedProperties.Add(ep)
            m.Tables[tName].Columns['Value1'].RelatedColumnDetails = rcd
            
            m.SaveChanges()
            
            dfC_filt1 = dfC[(dfC['Table Name'] == tName) & (dfC['Source'] == '[Value1]')]
            col1 = dfC_filt1['Column Name'].iloc[0]
            dfC_filt2 = dfC[(dfC['Table Name'] == tName) & (dfC['Source'] == '[Value2]')]
            col2 = dfC_filt2['Column Name'].iloc[0]
            dfC_filt3 = dfC[(dfC['Table Name'] == tName) & (dfC['Source'] == '[Value3]')]
            col3 = dfC_filt3['Column Name'].iloc[0]            

            m.Tables[tName].Columns['Value1'].Name = col1
            m.Tables[tName].Columns['Value2'].Name = col2
            m.Tables[tName].Columns['Value3'].Name = col3

            m.SaveChanges()
            print(f"The '{tName}' table has been added as a field parameter to the '{new_dataset}' semantic model in the '{new_dataset_workspace}' workspace.")
        except:
            print(f"ERROR: The '{tName}' table has not been added as a field parameter.")