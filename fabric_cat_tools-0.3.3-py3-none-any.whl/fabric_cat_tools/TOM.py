import sempy
import sempy.fabric as fabric
import pandas as pd
from contextlib import contextmanager
sempy.fabric._client._utils._init_analysis_services()
import Microsoft.AnalysisServices.Tabular as TOM
import System

@contextmanager
def connect_semantic_model(dataset, readonly=True, workspace=None):   

    if workspace is None:
        workspace_id = fabric.get_workspace_id()
        workspace = fabric.resolve_workspace_name(workspace_id)

    class TOMWrapper:
        def __init__(self, dataset, workspace, readonly):
            tom_server = fabric.create_tom_server(readonly=readonly, workspace=workspace)
            m = tom_server.Databases.GetByName(dataset).Model
            self.model = m

        def all_columns(self):
            for t in self.model.Tables:
                for c in t.Columns:
                    if not c.Name.startswith('RowNumber-'):
                        yield c

        def all_measures(self):
            for t in self.model.Tables:
                for m in t.Measures:
                    yield m

        def all_partitions(self):
            for t in self.model.Tables:
                for p in t.Partitions:
                    yield p

        def all_hierarchies(self):
            for t in self.model.Tables:
                for h in t.Hierarchies:
                    yield h

        def all_levels(self):
            for t in self.model.Tables:
                for h in t.Hierarchies:
                    for l in h.Levels:
                        yield l

        def all_calculation_items(self):
            for t in self.model.Tables:
                if t.CalculationGroup is not None:
                    for ci in t.CalculationGroup.CalculationItems:
                        yield ci

        def all_rls(self):
            for r in self.model.Roles:
                for tp in r.TablePermissions:
                    yield tp

        def close(self):
            if not readonly:
                self.model.SaveChanges()
    try:
        tw = TOMWrapper(dataset = dataset, workspace = workspace, readonly = readonly)
        yield tw 
    finally:
        tw.close()

def add_measure(table, measure_name, expression, format_string = None, description = None, display_folder = None):

    """
    
    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#add_measure

    import sempy
    import sempy.fabric as fabric
    import fabric_cat_tools as fct
    workspace = '' #Enter workspace name
    dataset = '' #Enter dataset name

    tom_server = fabric.create_tom_server(readonly=False, workspace=workspace)
    m = tom_server.Databases.GetByName(dataset).Model

    for t in m.Tables:    
        if t.Name == 'Internet Sales':
            # Add measure(s) to table
            fct.add_measure(table = t, measure_name='Sales Amount', expr="SUM('Internet Sales'[SalesAmount])")
            fct.add_measure(table = t, measure_name='Order Qty', expr="SUM('Internet Sales'[OrderQty]")
    m.SaveChanges()
    """

    obj = TOM.Measure()
    obj.Name = measure_name
    obj.Expression = expression
    if format_string is not None:
        obj.FormatString = format_string
    if description is not None:
        obj.Description = description
    if display_folder is not None:
        obj.DisplayFolder = display_folder
    table.Measures.Add(obj)

def add_data_column(table, column_name, source_column, data_type, format_string = None, hidden = False, description = None, display_folder = None, data_category = None):

    """
    
    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#add_measure

    add_data_column(
        ,table_name = 'Internet Sales'
        ,column_name = 'SalesAmount'
        ,source_column = 'SalesAmount'
        ,data_type =  'Int64'
        #,format_string = ''
        #,display_folder = ''
        )
    """

    obj = TOM.DataColumn()
    obj.Name = column_name
    obj.SourceColumn = source_column
    obj.DataType = System.Enum.Parse(TOM.DataType, data_type)
    obj.IsHidden = hidden
    if format_string is not None:
        obj.FormatString = format_string
    if description is not None:
        obj.Description = description
    if display_folder is not None:
        obj.DisplayFolder = display_folder
    if data_category is not None:
        obj.DataCategory = data_category
    table.Columns.Add(obj)

def add_calculated_column(table, column_name, expression, data_type, format_string = None, description = None, display_folder = None, data_category = None):

    """
    
    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#add_calculated_column

    add_calculated_column(
        table = m.Tables['Internet Sales'], 
        name = 'MyCalcColumn', 
        expression = 'DISTINCT...', 
        data_type = 'String'
    )

    """

    obj = TOM.CalculatedColumn()
    obj.Name = column_name
    obj.Expression = expression
    obj.DataType = System.Enum.Parse(TOM.DataType, data_type)
    if format_string is not None:
        obj.FormatString = format_string
    if description is not None:
        obj.Description = description
    if display_folder is not None:
        obj.DisplayFolder = display_folder
    if data_category is not None:
        obj.DataCategory = data_category

    table.Columns.Add(obj)

def add_calculation_item(table, calculation_item_name, expression, ordinal = None, format_string_expression = None, description = None):

    """
    
    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#add_calculation_item

    add_calculation_item(
        table = m.Tables['Internet Sales'], 
        name = 'MyCalcColumn', 
        expression = 'SELECTEDMEASURE()', 
        ordinal = 1
    )

    """

    obj = TOM.CalculationItem()
    fsd = TOM.FormatStringDefinition()
    obj.Name = calculation_item_name
    obj.Expression = expression
    if ordinal is not None:
        obj.Ordinal = ordinal
    if description is not None:
        obj.Description = description
    if format_string_expression is not None:
        obj.FormatStringDefinition = fsd.Expression = format_string_expression

    table.CalculationGroup.CalculationItems.Add(obj)

def add_role(model, role_name, model_permission = None, description = None):

    """
    
    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#add_role

    Example:

        add_role(
            ,role_name = 'Reader'
            ,role_description = 'This role is for...'
            )
    """

    if model_permission is None:
        model_permission = 'Read'

    obj = TOM.ModelRole()
    obj.Name = role_name
    obj.ModelPermission = System.Enum.Parse(TOM.ModelPermission, model_permission)
    if description is not None:
        obj.Description = description
    model.Roles.Add(obj)

def add_rls(role, table, filter_expression):

    """
    
    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#add_rls

    Example:

        add_rls(
            role = m.Roles['Reader']
            ,table = m.Tables['Product']
            ,filter_expression = "'Product'[Color] = \"Blue\"")
    """

    tp = TOM.TablePermission()
    tp.Table = table
    tp.FilterExpression = filter_expression
    role.TablePermissions.Add(tp)

def add_hierarchy(table, hierarchy_name, levels, hierarchy_description = None):

    """

    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#add_hierarchy

    add_hierarchy(
        table = m.Tables['Product'], 
        hierarchy_name='Prod Hierarchy', 
        levels = ['Class', 'Color'], 
        hierarchy_description='my hierarchy'
    )

    """

    obj = TOM.Hierarchy()
    obj.Name = hierarchy_name
    if hierarchy_description is not None:
        obj.Description = hierarchy_description
    table.Hierarchies.Add(obj)

    for level in levels:
        lvl = TOM.Level()
        lvl.Column = table.Columns[level]
        lvl.Name = level
        lvl.Ordinal = levels.index(level)
        table.Hierarchies[hierarchy_name].Levels.Add(lvl)

def add_relationship(from_column, to_column, from_cardinality, to_cardinality, cross_filtering_behavior = None, is_active = True, security_filtering_behavior = None, rely_on_referential_integrity = False):

    """

    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#add_relationship

    add_relationship(
        from_column = m.Tables['Internet Sales'].Columns['ProductKey'],
        to_column = m.Tables['Product'].Columns['ProductKey],
        from_cardinality='Many',
        to_cardinality='One'
        )

    """

    if cross_filtering_behavior is None:
        cross_filtering_behavior = 'Automatic'
    if security_filtering_behavior is None:
        security_filtering_behavior = 'OneDirection'

    from_cardinality = from_cardinality.capitalize()
    to_cardinality = to_cardinality.capitalize()
    cross_filtering_behavior = cross_filtering_behavior.capitalize()
    security_filtering_behavior = security_filtering_behavior.capitalize()
    security_filtering_behavior = security_filtering_behavior.replace('direct', 'Direct')
    cross_filtering_behavior = cross_filtering_behavior.replace('direct', 'Direct')

    rel = TOM.SingleColumnRelationship()
    rel.FromColumn = from_column
    rel.FromCardinality = System.Enum.Parse(TOM.RelationshipEndCardinality, from_cardinality)
    rel.ToColumn = to_column
    rel.ToCardinality = System.Enum.Parse(TOM.RelationshipEndCardinality, to_cardinality)
    rel.IsActive = is_active
    rel.CrossFilteringBehavior = System.Enum.Parse(TOM.CrossFilteringBehavior, cross_filtering_behavior)
    rel.SecurityFilteringBehavior = System.Enum.Parse(TOM.SecurityFilteringBehavior, security_filtering_behavior)
    rel.RelyOnReferentialIntegrity = rely_on_referential_integrity

    from_column.Model.Relationships.Add(rel)

def add_calculation_group(model, name, description = None):

    """

    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#add_calculation_group
    
    add_calculation_group(
        model = m, 
        name = 'MyNewCalcGroup'
    )
    
    """

    tbl = TOM.Table()
    tbl.Name = name
    tbl.CalculationGroup = TOM.CalculationGroup()
    if description is not None:
        tbl.Description = description

    part = TOM.Partition()
    part.Name = name
    part.Source = TOM.CalculationGroupSource()
    tbl.Partitions.Add(part)

    sortCol = 'Ordinal'

    col1 = TOM.DataColumn()
    col1.Name = sortCol
    col1.SourceColumn = sortCol
    col1.IsHidden = True
    col1.DataType = System.Enum.Parse(TOM.DataType, 'Int64')

    tbl.Columns.Add(col1)
    
    col2 = TOM.DataColumn()
    col2.Name = 'Name'
    col2.SourceColumn = 'Name'
    col2.DataType = System.Enum.Parse(TOM.DataType, 'String')
    #col.SortByColumn = m.Tables[name].Columns[sortCol]
    tbl.Columns.Add(col2)

    model.DiscourageImplicitMeasures = True
    model.Tables.Add(tbl)

def add_expression(model, name, expression, description = None):

    """

    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#add_expression
    
    add_expression(
        model = m, 
        name = 'MyExpression',
        expression = 'let....'
    )
    
    """

    exp = TOM.NamedExpression()
    exp.Name = name
    if description is not None:
        exp.Description = description
    exp.Kind = TOM.ExpressionKind.M
    exp.Expression = expression

    model.Expressions.Add(exp)

# Annotations
def get_annotations(object):

    """

    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#get_annotations
    
    get_annotations(
        object = m.Tables['Product']
    )
    
    """

    df = pd.DataFrame(columns=['Name', 'Value'])

    for a in object.Annotations:
        new_data = {'Name': a.Name, 'Value': a.Value}
        df = pd.concat([df, pd.DataFrame(new_data, index=[0])], ignore_index=True)

    return df

def set_annotation(object, name, value):

    """
    
    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#set_annotation

    set_annotation(
        object = m.Tables['Product'],
        name = 'Hello',
        value = '1'
    )
    
    """

    ann = TOM.Annotation()
    ann.Name = name
    ann.Value = value

    try:
        object.Annotations[name].Value = value
    except:
        object.Annotations.Add(ann)

def get_annotation_value(object, name):

    """

    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#get_annotation_value
    
    get_annotation_value(
        object = m.Tables['Product'],
        name = 'Hello'
    )
    
    """

    return object.Annotations[name].Value

def remove_annotation(object, name):

    """

    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#remove_annotation
    
    remove_annotation(
        object = m.Tables['Product'],
        name = 'Hello'
    )
    
    """

    object.Annotations.Remove(name)

def clear_annotations(object):

    """

    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#clear_annotations
    
    clear_annotations(
        object = m.Tables['Product']
    )
    
    """

    object.Annotations.Clear()

# Extended Properties
def get_extended_properties(object):

    """

    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#get_extended_properties
    
    get_extended_properties(
        object = m.Tables['Product']
    )
    
    """

    df = pd.DataFrame(columns=['Name', 'Value', 'Type'])

    for a in object.ExtendedProperties:
        new_data = {'Name': a.Name, 'Value': a.Value, 'Type': a.Type}
        df = pd.concat([df, pd.DataFrame(new_data, index=[0])], ignore_index=True)

    return df

def set_extended_property(object, extended_property_type, name, value):

    """

    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#set_extended_property
    
    get_extended_properties(
        object = m.Tables['Product'],
        extended_property_type = 'Json',
        name = 'hello',
        value = '1'
    )
    
    """

    extended_property_type = extended_property_type.title()

    if extended_property_type == 'Json':
        ep = TOM.JsonExtendedProperty()
    else:
        ep = TOM.StringExtendedProperty()

    ep.Name = name
    ep.Value = value

    try:
        object.ExtendedProperties[name].Value = value
    except:
        object.ExtendedProperties.Add(ep)

def get_extended_property_value(object, name):

    """

    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#get_extended_property_value
    
    get_extended_property_value(
        object = m.Tables['Product'],
        name = 'hello'
    )
    
    """

    return object.ExtendedProperties[name].Value

def remove_extended_property(object, name):

    """

    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#remove_extended_property
    
    remove_extended_property(
        object = m.Tables['Product'],
        name = 'hello'
    )
    
    """

    object.ExtendedProperties.Remove(name)

def clear_extended_properties(object):

    """
    
    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#clear_extended_properties

    clear_extended_properties(
        object = m.Tables['Product']
    )
    
    """

    object.ExtendedProperties.Clear()

# Perspective
def add_perspective(model, perspective_name):
    
    """
    
    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#add_perspective

    add_perspective(
        model = m, 
        perspective_name = 'newpersp'
    )

    """

    persp = TOM.Perspective()
    persp.Name = perspective_name
    model.Perspectives.Add(persp)

def in_perspective(object, perspective_name):
    
    """
    
    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#in_perspective

    in_perspective(
        object = m.Tables['Product'], 
        perspective_name='test'
    )
    
    """
    validObjects = ['Table', 'Column', 'Measure', 'Hierarchy']
    objectType = str(object.ObjectType)

    if objectType not in validObjects:
        print(f"Only the following object types are valid for perspectives: {validObjects}.")
        return
    
    object.Model.Perspectives[perspective_name]

    try:        
        if objectType == 'Table':
            object.Model.Perspectives[perspective_name].PerspectiveTables[object.Name]
        elif objectType == 'Column':
            object.Model.Perspectives[perspective_name].PerspectiveTables[object.Parent.Name].PerspectiveColumns[object.Name]
        elif objectType == 'Measure':
            object.Model.Perspectives[perspective_name].PerspectiveTables[object.Parent.Name].PerspectiveMeasures[object.Name]
        elif objectType == 'Hierarchy':
            object.Model.Perspectives[perspective_name].PerspectiveTables[object.Parent.Name].PerspectiveHierarchies[object.Name]
        return True
    except:
        return False

def add_to_perspective(object, perspective_name):

    """
    
    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#add_to_perspective

    add_to_perspective(
        object = m.Tables['Product'].Columns['Color'], 
        perspective_name = 'Business'
    
    """

    validObjects = ['Table', 'Column', 'Measure', 'Hierarchy']
    objectType = str(object.ObjectType)

    if objectType not in validObjects:
        print(f"Only the following object types are valid for perspectives: {validObjects}.")
        return
    object.Model.Perspectives[perspective_name]

    try:    
        if objectType == 'Table':
            pt = TOM.PerspectiveTable()
            pt.Table = object
            object.Model.Perspectives[perspective_name].PerspectiveTables.Add(pt)
        elif objectType == 'Column':
            pc = TOM.PerspectiveColumn()
            pc.Column = object
            object.Model.Perspectives[perspective_name].PerspectiveTables[object.Parent.Name].PerspectiveColumns.Add(pc)
        elif objectType == 'Measure':
            pm = TOM.PerspectiveMeasure()
            pm.Measure = object
            object.Model.Perspectives[perspective_name].PerspectiveTables[object.Parent.Name].PerspectiveMeasures.Add(pm)
        elif objectType == 'Hierarchy':
            ph = TOM.PerspectiveHierarchy()
            ph.Hierarchy = object
            object.Model.Perspectives[perspective_name].PerspectiveTables[object.Parent.Name].PerspectiveHierarchies.Add(ph)
    except:
        pass

def remove_from_perspective(object, perspective_name):

    """

    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#remove_from_perspective
    
    remove_from_perspective(
        object = m.Tables['Product'].Columns['Color'], 
        perspective_name = 'Business'
    )
    
    """

    validObjects = ['Table', 'Column', 'Measure', 'Hierarchy']
    objectType = str(object.ObjectType)

    if objectType not in validObjects:
        print(f"Only the following object types are valid for perspectives: {validObjects}.")
        return
    object.Model.Perspectives[perspective_name]

    try:    
        if objectType == 'Table':
            pt = object.Model.Perspectives[perspective_name].PerspectiveTables[object.Name]
            object.Model.Perspectives[perspective_name].PerspectiveTables.Remove(pt)
        elif objectType == 'Column':
            pc = object.Model.Perspectives[perspective_name].PerspectiveTables[object.Parent.Name].PerspectiveColumns[object.Name]
            object.Model.Perspectives[perspective_name].PerspectiveTables[object.Parent.Name].PerspectiveColumns.Remove(pc)
        elif objectType == 'Measure':
            pm = object.Model.Perspectives[perspective_name].PerspectiveTables[object.Parent.Name].PerspectiveMeasures[object.Name]
            object.Model.Perspectives[perspective_name].PerspectiveTables[object.Parent.Name].PerspectiveMeasures.Remove(pm)
        elif objectType == 'Hierarchy':
            ph = object.Model.Perspectives[perspective_name].PerspectiveTables[object.Parent.Name].PerspectiveHierarchies[object.Name]
            object.Model.Perspectives[perspective_name].PerspectiveTables[object.Parent.Name].PerspectiveHierarchies.Remove(ph)
    except:
        pass

def add_translation(model, language):

    """

    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#add_translation
    
    add_translation(
        model = m, 
        language = 'it-IT'
    )
    
    """

    cul = TOM.Culture()
    cul.Name = language

    try:
        model.Cultures.Add(cul)
    except:
        pass

def set_translation(object, language, property, value):

    """

    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#set_translation
    
    set_translation(
        object = m.Tables['Product'], 
        language = 'it-IT', 
        property = 'Name', 
        value = 'Produtto'
    )
    
    """

    add_translation(model = object.Model, language = language)

    property = property.title()

    validObjects = ['Table', 'Column', 'Measure', 'Hierarchy']

    if str(object.ObjectType) not in validObjects:
        print(f"Translations can only be set to {validObjects}.")
        return

    mapping = {
        'Name': TOM.TranslatedProperty.Caption,
        'Description': TOM.TranslatedProperty.Description,
        'Display Folder': TOM.TranslatedProperty.DisplayFolder
    }

    prop = mapping.get(property)

    object.Model.Cultures[language].ObjectTranslations.SetTranslation(object, prop, value)

def add_alternate_of(column, base_table, base_column, summarization_type = None):

    """

    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#add_alternate_of
    
    add_alternate_of(
        column = m.Tables['Internet Sales'].Columns['SalesAmount], 
        base_table = 'Internet Sales_Agg', 
        base_column = 'SalesAmount', 
        summarization_type = 'Sum' 
    )
    
    """

    if str(column.ObjectType) != 'Column':
        print(f"ERROR: This function is only valid for 'column' objects.")
    
    if base_column is not None and base_table is None:
        print(f"ERROR: If you specify the base table you must also specify the base column")

    summarization_type = summarization_type.title()

    ao = TOM.AlternateOf()
    ao.Summarization = System.Enum.Parse(TOM.SummarizationType, summarization_type)
    if base_column is not None:
        ao.BaseColumn = column.Model.Tables[base_table].Columns[base_column]
    else:
        ao.BaseTable = column.Model.Tables[base_table]    

    column.AlternateOf.Add(ao)

def set_ols(role, column, permission):

    """

    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#set_ols
    
    set_ols(
        role = m.Roles['Reader'], 
        column = m.Tables['Product'].Columns['Color'], 
        permission = 'None'
    )
    
    """

    permission = permission.capitalize()

    if permission not in ['Read', 'None', 'Default']:
        print(f"ERROR! Invalid 'permission' value.")
        return

    cp = TOM.ColumnPermission()
    cp.Column = column
    cp.MetadataPermission = System.Enum.Parse(TOM.MetadataPermission, permission)
    try:
        role.TablePermissions[column.Parent.Name].ColumnPermissions[column.Name].MetadataPermission = System.Enum.Parse(TOM.MetadataPermission, permission)
    except:
        role.TablePermissions[column.Parent.Name].ColumnPermissions.Add(cp)

def remove_translation(object, language):

    """

    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#remove_translation

    remove_translation(
        object = m.Tables['Product'].Columns['Color'], 
        language = 'it-IT'
    )
    
    """

    o = object.Model.Cultures[language].ObjectTranslations[object, TOM.TranslatedProperty.Caption]
    object.Model.Cultures[language].ObjectTranslations.Remove(o)

def remove_object(object):

    """

    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#remove_object

    remove_object(
        object = m.Tables['Product'].Columns['Color']
    )
    
    """

    objType = str(object.ObjectType)

    # Have to remove translations and perspectives on the object before removing it.
    if objType in ['Table', 'Column', 'Measure', 'Hierarchy', 'Level']:
        for lang in object.Model.Cultures:
            remove_translation(object = object, language = lang.Name)
    if objType in ['Table', 'Column', 'Measure', 'Hierarchy']:
        for persp in object.Model.Perspectives:
            remove_from_perspective(object = object, perspective_name = persp.Name)

    if objType == 'Column':
        object.Parent.Columns.Remove(object.Name)
    elif objType == 'Measure':
        object.Parent.Measures.Remove(object.Name)
    elif objType == 'Hierarchy':
        object.Parent.Hierarchies.Remove(object.Name)
    elif objType == 'Level':
        object.Parent.Levels.Remove(object.Name)
    elif objType == 'Partition':
        object.Parent.Partitions.Remove(object.Name)
    elif objType == 'Expression':
        object.Parent.Expressions.Remove(object.Name)
    elif objType == 'DataSource':
        object.Parent.DataSources.Remove(object.Name)
    elif objType == 'Role':
        object.Parent.Roles.Remove(object.Name)
    elif objType == 'Relationship':
        object.Parent.Relationships.Remove(object.Name)
    elif objType == 'Culture':
        object.Parent.Cultures.Remove(object.Name)
    elif objType == 'Perspective':
        object.Parent.Perspectives.Remove(object.Name)

def add_m_partition(table, partition_name, expression, mode = None, description = None):

    """

    Documentation is available here: https://github.com/m-kovalsky/fabric_cat_tools?tab=readme-ov-file#add_m_partition

    add_m_partition(
        table = m.Tables['Internet Sales'],
        partition_name = 'Internet Sales - 2024',
        expression = 'let...',
        mode = 'Import'
    )
    
    """

    mode = mode.title().replace('query', 'Query').replace(' ','').replace('lake', 'Lake')

    mp = TOM.MPartitionSource()
    mp.Expression = expression
    p = TOM.Partition()
    p.Name = partition_name
    p.Source = mp
    if description is not None:
        p.Description = description
    if mode is None:
        mode = 'Default'
    p.Mode = System.Enum.Parse(TOM.ModeType, mode)

    table.Partitions.Add(p)

def add_entity_partition(table, expression = None, description = None):

    """
    
    """

    ep = TOM.EntityPartitionSource()
    ep.Name = table.Name
    if expression is None:
        ep.ExpressionSource = table.Model.Expressions['DatabaseQuery']
    else:
        ep.ExpressionSource = expression
    p = TOM.Partition()
    p.Name = table.Name
    p.Source = ep
    p.Mode = TOM.ModeType.DirectLake
    if description is not None:
        p.Description = description
    
    table.Partitions.Add(p)

#all_columns = [col for table in m.Tables for col in table.Columns]
#all_measures = [meas for table in m.Tables for meas in table.Measures]
#all_partitions = [par for table in m.Tables for par in table.Partitions]
#all_hierarchies = [hier for table in m.Tables for hier in table.Hierarchies]
#all_partitions = [par for table in m.Tables for par in table.Partitions]
#all_calculationitems = [cg for table in m.Tables if table.CalculationGroup is not None for cg in table.CalculationGroup.CalculationItems]
#all_levels = [level for table in m.Tables for hier in table.Hierarchies for level in hier.Levels]
#all_rls = [tp for role in m.Roles for tp in role.TablePermissions]

